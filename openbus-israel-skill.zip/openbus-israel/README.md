# OpenBus Israel Scripting Skill

A Scripting skill for rendering Israeli public-transport data from OpenBus in rich inline chat UI.

Install by copying the `openbus-israel` folder into:

```text
Scripting Documents/scripting-skills/
```

The main renderer is:

```text
openbus-israel/scripts/openbus-renderer.tsx
```

Use it from the Assistant with a `scripting-file` block as described in `SKILL.md`.
