---
name: openbus-israel
metadata:
  display_name: "OpenBus Israel"
  intent_patterns: "bus, buses, public transport, transit, israel, stop arrivals, bus stop, route, timetable, vehicle location, תחבורה ציבורית, אוטובוס, קו, תחנה, זמני הגעה, איפה האוטובוס"
description: Show Israeli public-transport data from the open Open Bus Stride API in rich inline Scripting UIs. Use proactively when the user asks about buses, stops, routes, arrival times, route schedules, live vehicle positions, transit agencies, or ride performance in Israel. Prefer rendering an interactive visual card/map via ```scripting-file``` instead of only plain text.
---

# Purpose

Use this skill when the user asks about Israeli public transportation: buses, stops, route numbers, arrivals, schedules, vehicle locations, transit agencies, or planned vs actual ride performance.

The skill renders compact native Scripting UI in chat using a `scripting-file` fenced block. The renderer fetches live/public data directly from the Open Bus Stride API:

`https://open-bus-stride-api.hasadna.org.il`

No API key is required.

# How to Render

Output a `scripting-file` block pointing to the renderer:

````markdown
```scripting-file
{
  "path": "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-skills/openbus-israel/scripts/openbus-renderer.tsx",
  "props": {
    "config": {
      "type": "stop-search",
      "city": "ירושלים",
      "limit": 20
    }
  }
}
```
````

# Supported Views

| Type | Use Case |
|---|---|
| `stop-search` | Find stops by stop code or city and show them as map markers + horizontal cards |
| `stop-arrivals` | Show real-time arrivals for a specific `gtfs_stop_id` |
| `route-search` | Search planned GTFS routes by line number, agency, direction, or long-name text |
| `vehicle-locations` | Show live vehicle positions on a map, optionally filtered by bounding box, line, or operator |
| `route-timetable` | Show planned departures / timetables for route line refs and date filters |
| `ride-performance` | Compare planned vs actual rides for operator + line over a date range |
| `agencies` | List Israeli transit agencies/operators |
| `dashboard` | A combined view with several sections in segmented tabs |

# Decision Rules

- If the user gives a **city/street/place name** but not a stop id, first render `stop-search`.
- If the user gives a **GTFS stop id**, render `stop-arrivals`.
- If the user asks “where are buses now?” or wants a visual map, render `vehicle-locations`.
- If the user gives a **line number** like 480, render `route-search` unless they specifically asked for a timetable.
- If the user asks about delays, reliability, or how a line performed, render `ride-performance`.
- If the user asks for operators like Egged/Dan/Metropoline, render `agencies` or use `agency_name` in `route-search`.
- Prefer Hebrew labels in user-facing titles when the conversation is Hebrew.
- Keep views compact for chat: default map height is 220pt; keep horizontal cards short.

# Config Examples

## Find Stops by City

```json
{
  "type": "stop-search",
  "title": "תחנות בירושלים",
  "city": "ירושלים",
  "limit": 30,
  "height": 220
}
```

## Find a Stop by Code

```json
{
  "type": "stop-search",
  "title": "חיפוש תחנה",
  "code": 12345,
  "limit": 10
}
```

## Stop Arrivals

```json
{
  "type": "stop-arrivals",
  "title": "זמני הגעה לתחנה",
  "gtfs_stop_id": 12345,
  "limit": 30
}
```

## Route Search

```json
{
  "type": "route-search",
  "title": "חיפוש קו 480",
  "route_short_name": "480",
  "limit": 30
}
```

You can also use:

```json
{
  "type": "route-search",
  "agency_name": "אגד",
  "route_long_name_contains": "ירושלים",
  "limit": 30
}
```

## Vehicle Locations on a Map

```json
{
  "type": "vehicle-locations",
  "title": "אוטובוסים באזור ירושלים",
  "lat_min": 31.72,
  "lat_max": 31.84,
  "lon_min": 35.14,
  "lon_max": 35.26,
  "limit": 50,
  "height": 240
}
```

## Route Timetable

```json
{
  "type": "route-timetable",
  "title": "לו״ז מתוכנן",
  "line_refs": "480",
  "planned_start_time_date_from": "2026-07-08",
  "planned_start_time_date_to": "2026-07-08",
  "limit": 40
}
```

## Ride Performance

```json
{
  "type": "ride-performance",
  "title": "ביצועי קו",
  "date_from": "2026-07-01",
  "date_to": "2026-07-08",
  "operator_ref": 3,
  "line_ref": 480,
  "limit": 30
}
```

## Agencies

```json
{
  "type": "agencies",
  "title": "מפעילי תחבורה בישראל",
  "limit": 50
}
```

## Dashboard

```json
{
  "type": "dashboard",
  "title": "תחבורה ציבורית בישראל",
  "sections": [
    { "type": "stop-search", "city": "ירושלים", "limit": 20 },
    { "type": "route-search", "route_short_name": "480", "limit": 20 },
    { "type": "vehicle-locations", "lat_min": 31.72, "lat_max": 31.84, "lon_min": 35.14, "lon_max": 35.26, "limit": 30 }
  ]
}
```

# Data and API Notes

This skill is adapted from the `openbus-mcp` project, which wraps these Open Bus Stride API endpoints:

- `/stop_arrivals/list`
- `/rides_execution/list`
- `/gtfs_routes/list`
- `/gtfs_stops/list`
- `/route_timetable/list`
- `/siri_vehicle_locations/list`
- `/gtfs_agencies/list`

The API field names may vary by endpoint and date. The renderer uses defensive field extraction and shows raw fallback fields when a preferred label is missing.

# Output Notes

- Always include only one primary `scripting-file` block unless the user explicitly asks for multiple separate views.
- After the block, optionally add a one-sentence text explanation.
- Do not dump large raw JSON in chat; let the UI display the compact results.
- For questions requiring exact current data, let the renderer fetch live data at display time.
