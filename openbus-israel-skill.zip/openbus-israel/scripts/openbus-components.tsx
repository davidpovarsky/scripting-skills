import { Map, Marker, Annotation, useObservable, useState, VStack, HStack, Text, Image, ScrollView, Spacer } from "scripting"
import { Coordinate, TransitItem } from "./types"

export function LoadingView({ title }: { title?: string }) {
  return (
    <VStack spacing={10} padding={20} frame={{ maxWidth: "infinity" }} alignment="center">
      <Image systemName="bus.fill" font="largeTitle" foregroundStyle="systemBlue" />
      <Text font="headline" foregroundStyle="label">{title || "טוען נתוני תחבורה..."}</Text>
      <Text font="caption" foregroundStyle="secondaryLabel">OpenBus · Israel public transport</Text>
    </VStack>
  )
}

export function ErrorView({ title, message }: { title?: string; message: string }) {
  return (
    <VStack spacing={8} padding={16} frame={{ maxWidth: "infinity" }} alignment="leading">
      <HStack spacing={6} alignment="center">
        <Image systemName="exclamationmark.triangle.fill" foregroundStyle="systemOrange" />
        <Text font="headline" fontWeight="semibold">{title || "שגיאה בקבלת נתונים"}</Text>
      </HStack>
      <Text font="caption" foregroundStyle="secondaryLabel">{message}</Text>
    </VStack>
  )
}

export function EmptyView({ title, message }: { title?: string; message?: string }) {
  return (
    <VStack spacing={8} padding={20} frame={{ maxWidth: "infinity" }} alignment="center">
      <Image systemName="tray" font="largeTitle" foregroundStyle="secondaryLabel" />
      <Text font="headline" foregroundStyle="secondaryLabel">{title || "לא נמצאו תוצאות"}</Text>
      {message ? <Text font="caption" foregroundStyle="tertiaryLabel">{message}</Text> : null}
    </VStack>
  )
}

export function SectionHeader({ title, subtitle, count, systemImage = "bus.fill" }: {
  title: string
  subtitle?: string
  count?: number
  systemImage?: string
}) {
  return (
    <HStack padding={{ horizontal: 16, top: 10, bottom: 8 }} spacing={7} alignment="center">
      <Image systemName={systemImage} font="subheadline" foregroundStyle="systemBlue" />
      <Text font="subheadline" fontWeight="semibold" foregroundStyle="label" lineLimit={1}>{title}</Text>
      {count != null ? <Text font="caption" foregroundStyle="secondaryLabel">{count}</Text> : null}
      <Spacer />
      {subtitle ? <Text font="caption2" foregroundStyle="secondaryLabel" lineLimit={1}>{subtitle}</Text> : null}
    </HStack>
  )
}

export function ItemsMap({ items, height = 220, title = "תוצאות על המפה" }: {
  items: TransitItem[]
  height?: number
  title?: string
}) {
  const mapped = items.filter(item => item.coordinate)
  const [selected, setSelected] = useState<number | null>(null)
  const region = regionForItems(mapped)
  const cameraPosition = useObservable(MapCameraPosition.region(region))

  const focus = (index: number) => {
    const item = mapped[index]
    if (!item?.coordinate) return
    if (selected === index) {
      setSelected(null)
      cameraPosition.setValue(MapCameraPosition.region(region))
    } else {
      setSelected(index)
      cameraPosition.setValue(MapCameraPosition.region({
        center: item.coordinate,
        span: { latitudeDelta: 0.008, longitudeDelta: 0.008 },
      }))
    }
  }

  if (mapped.length === 0) return null

  return (
    <VStack spacing={0} alignment="leading">
      <Map
        cameraPosition={cameraPosition}
        mapStyle={{ style: "standard", showsTraffic: true }}
        frame={{ height }}
        clipShape={{ type: "rect", cornerRadius: 12 }}
      >
        {mapped.map((item, index) => (
          <Annotation
            key={item.id || index}
            coordinate={item.coordinate!}
            title={item.title}
            anchor="bottom"
          >
            <VStack
              frame={{ width: 28, height: 28 }}
              background={selected === index ? "systemOrange" : (item.color || "systemBlue")}
              clipShape="circle"
              alignment="center"
            >
              <Image systemName={item.systemImage || "bus.fill"} font="caption2" foregroundStyle="white" />
            </VStack>
          </Annotation>
        ))}
      </Map>
      <ScrollView axes="horizontal" padding={{ horizontal: 16, top: 10, bottom: 12 }}>
        <HStack spacing={8}>
          {mapped.map((item, index) => (
            <TransitCard
              key={item.id || index}
              item={item}
              selected={selected === index}
              width={145}
              onTap={() => focus(index)}
            />
          ))}
        </HStack>
      </ScrollView>
    </VStack>
  )
}

export function TransitCards({ items, title, subtitle, systemImage = "list.bullet.rectangle" }: {
  items: TransitItem[]
  title: string
  subtitle?: string
  systemImage?: string
}) {
  return (
    <VStack spacing={0} alignment="leading">
      <SectionHeader title={title} subtitle={subtitle} count={items.length} systemImage={systemImage} />
      <ScrollView axes="horizontal" padding={{ horizontal: 16, top: 2, bottom: 12 }}>
        <HStack spacing={8}>
          {items.map((item, index) => (
            <TransitCard key={item.id || index} item={item} width={150} />
          ))}
        </HStack>
      </ScrollView>
    </VStack>
  )
}

export function TransitCard({ item, selected = false, width = 150, onTap }: {
  item: TransitItem
  selected?: boolean
  width?: number
  onTap?: () => void
  key?: any
}) {
  return (
    <VStack
      spacing={5}
      padding={10}
      frame={{ width, alignment: "leading" }}
      background={selected ? "systemBlue" : "systemGray6"}
      clipShape={{ type: "rect", cornerRadius: 12 }}
      alignment="leading"
      onTapGesture={onTap}
    >
      <HStack spacing={6} alignment="center">
        <Image systemName={item.systemImage || "bus.fill"} font="caption" foregroundStyle={selected ? "white" : (item.color || "systemBlue")} />
        <Text font="subheadline" fontWeight="semibold" foregroundStyle={selected ? "white" : "label"} lineLimit={1}>{item.title}</Text>
      </HStack>
      {item.subtitle ? (
        <Text font="caption" foregroundStyle={selected ? "white" : "secondaryLabel"} lineLimit={2}>{item.subtitle}</Text>
      ) : null}
      {item.detail ? (
        <Text font="caption2" foregroundStyle={selected ? "white" : "tertiaryLabel"} lineLimit={2}>{item.detail}</Text>
      ) : null}
      {item.meta ? (
        <Text font="caption2" foregroundStyle={selected ? "white" : "secondaryLabel"} lineLimit={1}>{item.meta}</Text>
      ) : null}
    </VStack>
  )
}

export function RawDetails({ item }: { item: TransitItem }) {
  const pairs = Object.entries(item.raw || {})
    .filter(([, value]) => value !== null && value !== undefined && typeof value !== "object")
    .slice(0, 10)

  if (pairs.length === 0) return null

  return (
    <ScrollView axes="horizontal" padding={{ horizontal: 16, bottom: 12 }}>
      <HStack spacing={6}>
        {pairs.map(([key, value]) => (
          <HStack key={key} spacing={4} padding={{ horizontal: 8, vertical: 5 }} background="systemGray6" clipShape={{ type: "rect", cornerRadius: 10 }}>
            <Text font="caption2" foregroundStyle="secondaryLabel">{key}</Text>
            <Text font="caption2" fontWeight="medium" foregroundStyle="label" lineLimit={1}>{String(value)}</Text>
          </HStack>
        ))}
      </HStack>
    </ScrollView>
  )
}

export function regionForItems(items: TransitItem[]) {
  const coords = items.map(i => i.coordinate).filter(Boolean) as Coordinate[]
  if (coords.length === 0) {
    return {
      center: { latitude: 31.778, longitude: 35.235 },
      span: { latitudeDelta: 0.08, longitudeDelta: 0.08 },
    }
  }
  const lats = coords.map(c => c.latitude)
  const lons = coords.map(c => c.longitude)
  const minLat = Math.min(...lats)
  const maxLat = Math.max(...lats)
  const minLon = Math.min(...lons)
  const maxLon = Math.max(...lons)
  return {
    center: {
      latitude: (minLat + maxLat) / 2,
      longitude: (minLon + maxLon) / 2,
    },
    span: {
      latitudeDelta: Math.max((maxLat - minLat) * 1.7, 0.01),
      longitudeDelta: Math.max((maxLon - minLon) * 1.7, 0.01),
    },
  }
}
