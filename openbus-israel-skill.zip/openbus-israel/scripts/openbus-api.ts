import { Coordinate, TransitItem, OpenBusConfig } from "./types"

export const BASE_URL = "https://open-bus-stride-api.hasadna.org.il"

let lastRequestTime = 0
const MIN_INTERVAL_MS = 1000

async function rateLimit() {
  const now = Date.now()
  const elapsed = now - lastRequestTime
  const waitMs = MIN_INTERVAL_MS - elapsed
  if (waitMs > 0) {
    await new Promise(resolve => setTimeout(resolve, waitMs))
  }
  lastRequestTime = Date.now()
}

export async function fetchOpenBus(path: string, params: Record<string, any>): Promise<any[]> {
  await rateLimit()

  const query = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null && value !== "")
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`)
    .join("&")

  const url = `${BASE_URL}${path}${query ? `?${query}` : ""}`
  const response = await fetch(url, {
    method: "GET",
    headers: { Accept: "application/json" },
  })

  if (!response.ok) {
    const body = await response.text().catch(() => "")
    throw new Error(`OpenBus API ${response.status}: ${body || response.statusText}`)
  }

  return normalizeRows(await response.json())
}

export function buildRequest(config: OpenBusConfig): { path: string; params: Record<string, any>; entity: string } {
  const limit = config.limit ?? 30
  const offset = config.offset ?? 0

  switch (config.type) {
    case "stop-search":
      return {
        path: "/gtfs_stops/list",
        entity: "stop",
        params: {
          date_from: config.date_from,
          date_to: config.date_to,
          code: config.code,
          city: config.city,
          limit,
          offset,
        },
      }

    case "stop-arrivals":
      return {
        path: "/stop_arrivals/list",
        entity: "arrival",
        params: {
          gtfs_stop_id: config.gtfs_stop_id,
          limit,
          offset,
        },
      }

    case "route-search":
      return {
        path: "/gtfs_routes/list",
        entity: "route",
        params: {
          date_from: config.date_from,
          date_to: config.date_to,
          line_refs: config.line_refs,
          operator_refs: config.operator_refs,
          route_short_name: config.route_short_name,
          route_long_name_contains: config.route_long_name_contains,
          agency_name: config.agency_name,
          route_type: config.route_type,
          route_direction: config.route_direction,
          order_by: config.order_by,
          limit,
          offset,
        },
      }

    case "vehicle-locations":
      return {
        path: "/siri_vehicle_locations/list",
        entity: "vehicle",
        params: {
          lat_min: config.lat_min,
          lat_max: config.lat_max,
          lon_min: config.lon_min,
          lon_max: config.lon_max,
          recorded_at_time_from: config.recorded_at_time_from,
          recorded_at_time_to: config.recorded_at_time_to,
          siri_routes__line_ref: config.siri_routes__line_ref,
          siri_routes__operator_ref: config.siri_routes__operator_ref,
          limit,
          offset,
        },
      }

    case "route-timetable":
      return {
        path: "/route_timetable/list",
        entity: "timetable",
        params: {
          planned_start_time_date_from: config.planned_start_time_date_from,
          planned_start_time_date_to: config.planned_start_time_date_to,
          line_refs: config.line_refs,
          limit,
          offset,
        },
      }

    case "ride-performance":
      return {
        path: "/rides_execution/list",
        entity: "ride",
        params: {
          date_from: config.date_from,
          date_to: config.date_to,
          operator_ref: config.operator_ref,
          line_ref: config.line_ref,
          limit,
          offset,
        },
      }

    case "agencies":
      return {
        path: "/gtfs_agencies/list",
        entity: "agency",
        params: {
          date_from: config.date_from,
          date_to: config.date_to,
          limit,
          offset,
        },
      }

    default:
      return { path: "/gtfs_routes/list", entity: "item", params: { limit, offset } }
  }
}

export function normalizeRows(data: any): any[] {
  if (Array.isArray(data)) return data
  if (!data || typeof data !== "object") return []
  if (Array.isArray(data.results)) return data.results
  if (Array.isArray(data.data)) return data.data
  if (Array.isArray(data.items)) return data.items
  if (Array.isArray(data.rows)) return data.rows
  return [data]
}

export function mapItems(rows: any[], type: OpenBusConfig["type"]): TransitItem[] {
  return rows.map((row, index) => mapRow(row, type, index))
}

function mapRow(row: any, type: OpenBusConfig["type"], index: number): TransitItem {
  const coordinate = coordinateFromRecord(row)

  switch (type) {
    case "stop-search":
      return {
        id: idFrom(row, index),
        title: textFrom(row, ["name", "stop_name", "gtfs_stop_name", "city"], `תחנה ${index + 1}`),
        subtitle: compact([label("קוד", valueFrom(row, ["code", "stop_code", "gtfs_stop_code"])), valueFrom(row, ["city", "stop_city"])]),
        detail: textFrom(row, ["street", "address", "stop_desc"], ""),
        meta: label("GTFS", valueFrom(row, ["gtfs_stop_id", "id"])),
        coordinate,
        systemImage: "bus.fill",
        color: "systemBlue",
        raw: row,
      }

    case "stop-arrivals":
      return {
        id: idFrom(row, index),
        title: compact(["קו", valueFrom(row, ["route_short_name", "line_ref", "siri_route__route_short_name", "siri_routes__route_short_name"])]),
        subtitle: timeSummary(row),
        detail: textFrom(row, ["destination", "headsign", "route_long_name", "siri_route__route_long_name"], ""),
        meta: compact([label("רציף", valueFrom(row, ["platform", "stop_sequence"])), label("רכב", valueFrom(row, ["vehicle_ref", "siri_vehicle_ref"]))]),
        coordinate,
        systemImage: "clock.fill",
        color: "systemGreen",
        raw: row,
      }

    case "route-search":
      return {
        id: idFrom(row, index),
        title: compact(["קו", valueFrom(row, ["route_short_name", "short_name", "line_ref"])]),
        subtitle: textFrom(row, ["route_long_name", "long_name"], ""),
        detail: compact([valueFrom(row, ["agency_name"]), label("כיוון", valueFrom(row, ["route_direction", "direction_id"]))]),
        meta: compact([label("operator", valueFrom(row, ["operator_ref"])), label("line", valueFrom(row, ["line_ref"]))]),
        coordinate,
        systemImage: "arrow.triangle.branch",
        color: "systemPurple",
        raw: row,
      }

    case "vehicle-locations":
      return {
        id: idFrom(row, index),
        title: compact(["קו", valueFrom(row, ["route_short_name", "siri_routes__route_short_name", "line_ref", "siri_routes__line_ref"])]),
        subtitle: textFrom(row, ["vehicle_ref", "siri_vehicle_ref", "license_plate"], "רכב בזמן אמת"),
        detail: textFrom(row, ["recorded_at_time", "recorded_at", "timestamp"], ""),
        meta: compact([label("operator", valueFrom(row, ["operator_ref", "siri_routes__operator_ref"])), label("speed", valueFrom(row, ["velocity", "speed"]))]),
        coordinate,
        systemImage: "bus.doubledecker.fill",
        color: "systemOrange",
        raw: row,
      }

    case "route-timetable":
      return {
        id: idFrom(row, index),
        title: compact(["קו", valueFrom(row, ["route_short_name", "line_ref", "route_ref"])]),
        subtitle: textFrom(row, ["planned_start_time", "planned_start_time_date", "departure_time"], ""),
        detail: textFrom(row, ["route_long_name", "headsign", "destination"], ""),
        meta: compact([label("חלופה", valueFrom(row, ["route_alternative", "alternative"])), label("כיוון", valueFrom(row, ["route_direction", "direction_id"]))]),
        coordinate,
        systemImage: "calendar.badge.clock",
        color: "systemTeal",
        raw: row,
      }

    case "ride-performance":
      return {
        id: idFrom(row, index),
        title: compact(["נסיעה", valueFrom(row, ["ride_id", "gtfs_ride_id", "line_ref"])]),
        subtitle: compact([label("מתוכנן", valueFrom(row, ["planned_start_time", "scheduled_start_time"])), label("בפועל", valueFrom(row, ["actual_start_time", "actual_departure_time"] ))]),
        detail: compact([label("איחור", valueFrom(row, ["delay", "delay_seconds", "arrival_delay"])), label("סטטוס", valueFrom(row, ["status", "adherence"] ))]),
        meta: compact([label("operator", valueFrom(row, ["operator_ref"])), label("line", valueFrom(row, ["line_ref"]))]),
        coordinate,
        systemImage: "chart.line.uptrend.xyaxis",
        color: "systemRed",
        raw: row,
      }

    case "agencies":
      return {
        id: idFrom(row, index),
        title: textFrom(row, ["agency_name", "name"], `מפעיל ${index + 1}`),
        subtitle: textFrom(row, ["agency_url", "url", "agency_timezone"], ""),
        detail: textFrom(row, ["agency_phone", "phone", "agency_lang"], ""),
        meta: label("ref", valueFrom(row, ["agency_id", "operator_ref", "id"])),
        coordinate,
        systemImage: "building.2.fill",
        color: "systemIndigo",
        raw: row,
      }

    default:
      return {
        id: idFrom(row, index),
        title: `פריט ${index + 1}`,
        subtitle: firstUsefulValue(row),
        coordinate,
        systemImage: "circle.grid.2x2.fill",
        color: "systemGray",
        raw: row,
      }
  }
}

export function coordinateFromRecord(row: any): Coordinate | undefined {
  const lat = numberFrom(row, [
    "latitude", "lat", "stop_lat", "gtfs_stop_lat", "gtfs_stop__lat", "vehicle_latitude", "siri_vehicle_location_latitude",
    "siri_vehicle_locations__lat", "recorded_lat", "location_lat", "y",
  ])
  const lon = numberFrom(row, [
    "longitude", "lon", "lng", "stop_lon", "gtfs_stop_lon", "gtfs_stop__lon", "vehicle_longitude", "siri_vehicle_location_longitude",
    "siri_vehicle_locations__lon", "recorded_lon", "location_lon", "x",
  ])
  if (lat == null || lon == null) return undefined
  if (Math.abs(lat) > 90 || Math.abs(lon) > 180) return undefined
  return { latitude: lat, longitude: lon }
}

export function valueFrom(row: any, keys: string[]): any {
  for (const key of keys) {
    const direct = row?.[key]
    if (direct !== undefined && direct !== null && direct !== "") return direct
  }
  for (const key of keys) {
    const found = findDeep(row, key)
    if (found !== undefined && found !== null && found !== "") return found
  }
  return undefined
}

function findDeep(value: any, key: string): any {
  if (!value || typeof value !== "object") return undefined
  if (Object.prototype.hasOwnProperty.call(value, key)) return value[key]
  for (const child of Object.values(value)) {
    if (child && typeof child === "object") {
      const found = findDeep(child, key)
      if (found !== undefined) return found
    }
  }
  return undefined
}

function numberFrom(row: any, keys: string[]): number | undefined {
  const value = valueFrom(row, keys)
  if (value === undefined || value === null || value === "") return undefined
  const number = typeof value === "number" ? value : Number(String(value))
  return Number.isFinite(number) ? number : undefined
}

function textFrom(row: any, keys: string[], fallback: string): string {
  const value = valueFrom(row, keys)
  return value === undefined || value === null || value === "" ? fallback : String(value)
}

function idFrom(row: any, index: number): string {
  const value = valueFrom(row, ["id", "gtfs_stop_id", "gtfs_route_id", "route_id", "ride_id", "agency_id", "vehicle_ref"])
  return value != null ? String(value) : String(index)
}

function firstUsefulValue(row: any): string {
  if (!row || typeof row !== "object") return String(row ?? "")
  for (const value of Object.values(row)) {
    if (["string", "number", "boolean"].includes(typeof value)) return String(value)
  }
  return ""
}

function label(labelText: string, value: any): string {
  if (value === undefined || value === null || value === "") return ""
  return `${labelText}: ${value}`
}

function compact(parts: any[]): string {
  return parts.filter((part) => part !== undefined && part !== null && String(part).trim() !== "").join(" · ")
}

function timeSummary(row: any): string {
  const expected = valueFrom(row, ["expected_arrival_time", "arrival_time", "actual_arrival_time", "aimed_arrival_time"])
  const planned = valueFrom(row, ["scheduled_arrival_time", "planned_arrival_time"])
  const recorded = valueFrom(row, ["recorded_at_time", "updated_at"])
  return compact([
    expected ? `צפוי: ${expected}` : "",
    planned ? `מתוכנן: ${planned}` : "",
    recorded ? `עודכן: ${recorded}` : "",
  ]) || "זמן הגעה זמין"
}
