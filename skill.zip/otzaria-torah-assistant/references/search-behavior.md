# Search behavior reference

## Main search model

Use the SQLite FTS5 table `line_fts` for content search. It is defined with `tokenize='unicode61'` and uses external content from the `line` table.

The reliable base query is:

```sql
SELECT line.id AS lineId, line.bookId, book.title AS bookTitle,
       line.lineIndex, line.heRef, line.content, bm25(line_fts) AS rank
FROM line_fts
JOIN line ON line.id = line_fts.rowid
JOIN book ON book.id = line.bookId
WHERE line_fts MATCH ?
ORDER BY rank
LIMIT ?
```

## Query modes

Use these modes in the scripts:

- `text`: FTS5 text search over `line_fts`.
- `book`: `book.title LIKE ?` title search.
- `ref`: `line.heRef LIKE ?` plus exact `book.title` lookup.
- `auto`: run title/reference checks when the query looks like a book or reference, and otherwise run FTS.

## FTS examples verified against the database

Useful query forms:

- `בראשית`
- `בראשית ברא`
- `"בראשית ברא"`
- `ברא*`
- `שבת`
- `שבת חולה`
- `שבת AND חולה`
- `שבת OR חולה`
- `"חולה בשבת"`
- `אמר רב`
- `"אמר רב"`

## Escaping rules

Prefer passing the FTS string as a bound parameter, never concatenate user input into SQL.

When generating a fallback query:

1. Trim whitespace.
2. Collapse repeated whitespace to a single space.
3. Remove ASCII double quotes unless the user explicitly asked for exact phrase search.
4. If the query contains only Hebrew words and spaces, keep it as-is.
5. For exact phrase search, wrap the normalized phrase in double quotes.

## Ranking and result display

- Use `bm25(line_fts)` as `rank` when available.
- Lower rank is better.
- UI should show `bookTitle`, `heRef` or `lineIndex`, and a short stripped-text snippet.
- Strip HTML tags from `line.content` for preview, but keep the original content available in script internals when needed.

## Practical limits

- Default UI limit: 20 results.
- Recommended max without explicit user request: 50 results.
- Context window: 3 lines before and 3 lines after by default.

## Fallback order

If FTS throws or returns no rows:

1. Try normalized plain query.
2. Try exact phrase if the query has 2-5 words.
3. Try prefix on the last word only if the user appears to be searching a partial word.
4. Fall back to `book.title LIKE ?` and `line.heRef LIKE ?`.
