# Otzaria workflow

## When the user asks to search

1. Use `scripts/search.tsx`.
2. Choose `mode: "auto"` unless the user explicitly says title/book/reference.
3. Pass `query` and `limit`.
4. If the user asks to open a result, use its `bookId`, `lineId`, and `lineIndex` with `scripts/read-context.tsx`.

## When the user asks for a source/reference

1. Use `scripts/read-ref.tsx`.
2. Pass either `ref`, or `bookTitle` with `startLineIndex` / `endLineIndex`.
3. If the result is too broad, ask for a narrower range only when necessary; otherwise show the first 50 lines and explain that more can be loaded.

## When the user asks for commentaries or linked material

1. Use `scripts/links.tsx` with `lineId` if known.
2. If only a reference is known, first run `read-ref.tsx` or `search.tsx` to get the `lineId`.
3. Group results by `connectionType`: COMMENTARY, SOURCE, TARGUM, REFERENCE, OTHER.

## When the user wants one compact interface

Use `scripts/otzaria-workflow-view.tsx` with optional defaults:

```json
{
  "query": "שבת חולה",
  "limit": 20,
  "contextRadius": 3
}
```

## Do not use AssistantTools

This Skill is intentionally implemented as Scripting files and instructions only. Do not generate AssistantTool manifests or registration code.
