# Otzaria / Seforim SQLite schema reference

This reference summarizes the local `seforim.db` shape used by the bundled scripts.

## Database scale

Known analyzed database:

- `book`: 7,030 rows
- `line`: 6,058,210 rows
- `line_fts`: 6,058,210 rows
- `tocEntry`: 1,291,514 rows
- `tocText`: 110,200 rows
- `link`: 7,752,211 rows

## Core tables

### `book`

```sql
CREATE TABLE book (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  categoryId INTEGER NOT NULL,
  sourceId INTEGER NOT NULL,
  title TEXT NOT NULL,
  heShortDesc TEXT,
  notesContent TEXT,
  orderIndex INTEGER NOT NULL DEFAULT 999,
  totalLines INTEGER NOT NULL DEFAULT 0,
  isBaseBook INTEGER NOT NULL DEFAULT 0,
  hasTargumConnection INTEGER NOT NULL DEFAULT 0,
  hasReferenceConnection INTEGER NOT NULL DEFAULT 0,
  hasSourceConnection INTEGER NOT NULL DEFAULT 0,
  hasCommentaryConnection INTEGER NOT NULL DEFAULT 0,
  hasOtherConnection INTEGER NOT NULL DEFAULT 0,
  hasAltStructures INTEGER NOT NULL DEFAULT 0,
  hasTeamim INTEGER NOT NULL DEFAULT 0,
  hasNekudot INTEGER NOT NULL DEFAULT 0,
  isPersonal INTEGER DEFAULT 0,
  filePath TEXT DEFAULT NULL,
  fileType TEXT DEFAULT 'txt',
  fileSize INTEGER DEFAULT NULL,
  lastModified INTEGER DEFAULT NULL,
  pages INTEGER DEFAULT NULL,
  volume TEXT DEFAULT NULL
)
```

Useful indexes include `idx_book_title`, `idx_book_category`, `idx_book_order`, and `idx_book_source`.

### `line`

```sql
CREATE TABLE line (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bookId INTEGER NOT NULL,
  lineIndex INTEGER NOT NULL,
  content TEXT NOT NULL,
  heRef TEXT,
  tocEntryId INTEGER,
  FOREIGN KEY (bookId) REFERENCES book(id) ON DELETE CASCADE,
  FOREIGN KEY (tocEntryId) REFERENCES tocEntry(id) ON DELETE SET NULL
)
```

Useful indexes:

- `idx_line_book_index(bookId, lineIndex)`
- `idx_line_heref(heRef)`
- `idx_line_toc(tocEntryId)`

### `line_fts`

```sql
CREATE VIRTUAL TABLE line_fts USING fts5(
  content,
  content='line',
  content_rowid='id',
  tokenize='unicode61'
)
```

Join by `line_fts.rowid = line.id`.

### `link`

```sql
CREATE TABLE link (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sourceBookId INTEGER NOT NULL,
  targetBookId INTEGER NOT NULL,
  sourceLineId INTEGER NOT NULL,
  targetLineId INTEGER NOT NULL,
  connectionTypeId INTEGER NOT NULL
)
```

Connection types:

| id | name |
| --- | --- |
| 1 | OTHER |
| 2 | COMMENTARY |
| 3 | SOURCE |
| 4 | TARGUM |
| 5 | REFERENCE |

Useful indexes include `idx_link_type_source_line`, `idx_link_source_line`, `idx_link_target_line`, `idx_link_source_book`, and `idx_link_target_book`.

### `tocEntry` and `tocText`

`tocEntry` stores the tree structure. `tocText` stores unique TOC labels.

```sql
CREATE TABLE tocEntry (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bookId INTEGER NOT NULL,
  parentId INTEGER,
  textId INTEGER NOT NULL,
  level INTEGER NOT NULL,
  lineId INTEGER,
  lineIndex INTEGER,
  isLastChild INTEGER NOT NULL DEFAULT 0,
  hasChildren INTEGER NOT NULL DEFAULT 0
)
```

```sql
CREATE TABLE tocText (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  text TEXT NOT NULL UNIQUE
)
```

## Useful SQL patterns

### FTS search

```sql
SELECT
  line.id AS lineId,
  line.bookId,
  book.title AS bookTitle,
  line.lineIndex,
  line.heRef,
  line.content,
  bm25(line_fts) AS rank
FROM line_fts
JOIN line ON line.id = line_fts.rowid
JOIN book ON book.id = line.bookId
WHERE line_fts MATCH ?
ORDER BY rank
LIMIT ?
```

### Book search

```sql
SELECT id, title, heShortDesc, totalLines, isBaseBook
FROM book
WHERE title LIKE ?
ORDER BY isBaseBook DESC, orderIndex ASC, title ASC
LIMIT ?
```

### Reference lookup

```sql
SELECT
  line.id AS lineId,
  line.bookId,
  book.title AS bookTitle,
  line.lineIndex,
  line.heRef,
  line.content
FROM line
JOIN book ON book.id = line.bookId
WHERE line.heRef LIKE ? OR book.title = ?
ORDER BY book.orderIndex, line.lineIndex
LIMIT ?
```

### Context around a line

```sql
SELECT line.id AS lineId, book.title AS bookTitle, line.lineIndex, line.heRef, line.content
FROM line
JOIN book ON book.id = line.bookId
WHERE line.bookId = ? AND line.lineIndex BETWEEN ? AND ?
ORDER BY line.lineIndex
```

### Links for a line

```sql
SELECT
  link.id,
  connection_type.name AS connectionType,
  sourceBook.title AS sourceBookTitle,
  targetBook.title AS targetBookTitle,
  sourceLine.heRef AS sourceHeRef,
  targetLine.heRef AS targetHeRef,
  sourceLine.content AS sourceContent,
  targetLine.content AS targetContent
FROM link
JOIN connection_type ON connection_type.id = link.connectionTypeId
JOIN book AS sourceBook ON sourceBook.id = link.sourceBookId
JOIN book AS targetBook ON targetBook.id = link.targetBookId
JOIN line AS sourceLine ON sourceLine.id = link.sourceLineId
JOIN line AS targetLine ON targetLine.id = link.targetLineId
WHERE link.sourceLineId = ? OR link.targetLineId = ?
ORDER BY link.connectionTypeId, link.id
LIMIT ?
```
