import { ScrollView, VStack, Text, Button, useEffect, useState } from "scripting"

declare const SQLite: any
declare const FileManager: any
declare const Path: any

type Props = {
  dbPath?: string
  ref?: string
  bookTitle?: string
  bookId?: number
  startLineIndex?: number
  endLineIndex?: number
  limit?: number
}

type LineRow = {
  lineId: number
  bookId: number
  bookTitle: string
  lineIndex: number
  heRef: string | null
  content: string
}

type State = {
  loading: boolean
  dbPath: string | null
  error: string | null
  lines: LineRow[]
  summary: string
}

const DEFAULT_DB_PATH = "/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/seforim.db"

function stripHtml(value: string | null | undefined): string {
  return String(value ?? "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim()
}

function safeLimit(value: unknown): number {
  const n = typeof value === "number" && Number.isFinite(value) ? Math.floor(value) : 50
  return Math.max(1, Math.min(120, n))
}

function candidatePaths(explicit?: string): string[] {
  const paths: string[] = []
  if (explicit) paths.push(explicit)
  try { if (FileManager?.appGroupDocumentsDirectory) paths.push(Path.join(FileManager.appGroupDocumentsDirectory, "seforim.db")) } catch {}
  try { if (FileManager?.documentsDirectory) paths.push(Path.join(FileManager.documentsDirectory, "seforim.db")) } catch {}
  paths.push(DEFAULT_DB_PATH)
  return Array.from(new Set(paths.filter(Boolean)))
}

async function pathExists(path: string): Promise<boolean> {
  try {
    const result = FileManager?.exists?.(path)
    return typeof result?.then === "function" ? await result : !!result
  } catch { return false }
}

async function openDatabase(explicit?: string): Promise<{ db: any; path: string }> {
  for (const path of candidatePaths(explicit)) {
    if (!(await pathExists(path))) continue
    try {
      return { db: SQLite.open(path, { readonly: true, busyMode: 5, label: "otzaria-read-ref" }), path }
    } catch {}
  }
  throw new Error("לא הצלחתי לפתוח seforim.db. העבר dbPath או העתק את הקובץ לתיקיית Documents של Scripting.")
}

async function readLines(props: Props): Promise<State> {
  const { db, path } = await openDatabase(props.dbPath)
  const limit = safeLimit(props.limit)

  if (typeof props.bookId === "number") {
    const start = Math.max(0, Math.floor(props.startLineIndex ?? 0))
    const end = Math.max(start, Math.floor(props.endLineIndex ?? start + limit - 1))
    const rows = await db.fetchAll<LineRow>(
      `SELECT line.id AS lineId, line.bookId AS bookId, book.title AS bookTitle,
              line.lineIndex AS lineIndex, line.heRef AS heRef, line.content AS content
       FROM line
       JOIN book ON book.id = line.bookId
       WHERE line.bookId = ? AND line.lineIndex BETWEEN ? AND ?
       ORDER BY line.lineIndex
       LIMIT ?`,
      [props.bookId, start, end, limit]
    )
    return { loading: false, dbPath: path, error: null, lines: rows, summary: `bookId ${props.bookId}, lines ${start}-${end}` }
  }

  if (props.bookTitle) {
    const start = Math.max(0, Math.floor(props.startLineIndex ?? 0))
    const end = Math.max(start, Math.floor(props.endLineIndex ?? start + limit - 1))
    const rows = await db.fetchAll<LineRow>(
      `SELECT line.id AS lineId, line.bookId AS bookId, book.title AS bookTitle,
              line.lineIndex AS lineIndex, line.heRef AS heRef, line.content AS content
       FROM line
       JOIN book ON book.id = line.bookId
       WHERE book.title = ? AND line.lineIndex BETWEEN ? AND ?
       ORDER BY line.lineIndex
       LIMIT ?`,
      [props.bookTitle, start, end, limit]
    )
    return { loading: false, dbPath: path, error: null, lines: rows, summary: `${props.bookTitle}, lines ${start}-${end}` }
  }

  if (props.ref) {
    const ref = props.ref.trim()
    const rows = await db.fetchAll<LineRow>(
      `SELECT line.id AS lineId, line.bookId AS bookId, book.title AS bookTitle,
              line.lineIndex AS lineIndex, line.heRef AS heRef, line.content AS content
       FROM line
       JOIN book ON book.id = line.bookId
       WHERE line.heRef LIKE ? OR book.title = ?
       ORDER BY book.orderIndex, line.lineIndex
       LIMIT ?`,
      [`%${ref}%`, ref, limit]
    )
    return { loading: false, dbPath: path, error: null, lines: rows, summary: `ref: ${ref}` }
  }

  return { loading: false, dbPath: path, error: "צריך להעביר ref, bookTitle, או bookId.", lines: [], summary: "" }
}

function LineCard({ row }: { row: LineRow }) {
  return (
    <VStack spacing={4} padding={10} background="secondarySystemBackground" clipShape={{ type: "rect", cornerRadius: 12 }}>
      <Text fontWeight="semibold">{row.bookTitle}</Text>
      <Text foregroundStyle="secondary" fontSize={12}>lineId {row.lineId} · line {row.lineIndex}{row.heRef ? ` · ${row.heRef}` : ""}</Text>
      <Text fontSize={15}>{stripHtml(row.content)}</Text>
      <Button title="Log line JSON" action={() => console.log(JSON.stringify(row, null, 2))} />
    </VStack>
  )
}

export default function ReadRef(props: Props) {
  const [state, setState] = useState<State>({ loading: true, dbPath: null, error: null, lines: [], summary: "" })

  useEffect(() => {
    let alive = true
    setState(prev => ({ ...prev, loading: true, error: null }))
    readLines(props)
      .then(next => { if (alive) setState(next) })
      .catch(error => { if (alive) setState({ loading: false, dbPath: null, error: String(error?.message ?? error), lines: [], summary: "" }) })
    return () => { alive = false }
  }, [props.dbPath, props.ref, props.bookTitle, props.bookId, props.startLineIndex, props.endLineIndex, props.limit])

  return (
    <ScrollView>
      <VStack spacing={12} padding={14}>
        <Text fontSize={20} fontWeight="bold">קריאת מקור</Text>
        {!!state.summary && <Text foregroundStyle="secondary" fontSize={12}>{state.summary}</Text>}
        {state.dbPath && <Text foregroundStyle="secondary" fontSize={11}>db: {state.dbPath}</Text>}
        {state.loading && <Text>טוען...</Text>}
        {state.error && <Text foregroundStyle="red">{state.error}</Text>}
        {!state.loading && !state.error && state.lines.length === 0 && <Text>לא נמצאו שורות.</Text>}
        {state.lines.map(row => <LineCard key={row.lineId} row={row} />)}
      </VStack>
    </ScrollView>
  )
}
