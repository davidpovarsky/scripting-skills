import { ScrollView, VStack, Text, Button, useEffect, useState } from "scripting"

declare const SQLite: any
declare const FileManager: any
declare const Path: any

type Props = {
  dbPath?: string
  lineId?: number
  bookId?: number
  lineIndex?: number
  connectionType?: "COMMENTARY" | "SOURCE" | "TARGUM" | "REFERENCE" | "OTHER"
  limit?: number
}

type LinkRow = {
  linkId: number
  connectionType: string
  sourceLineId: number
  targetLineId: number
  sourceBookTitle: string
  targetBookTitle: string
  sourceHeRef: string | null
  targetHeRef: string | null
  sourceContent: string
  targetContent: string
}

type State = {
  loading: boolean
  dbPath: string | null
  error: string | null
  resolvedLineId: number | null
  links: LinkRow[]
}

const DEFAULT_DB_PATH = "/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/seforim.db"

function stripHtml(value: string | null | undefined): string {
  return String(value ?? "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim()
}

function safeLimit(value: unknown): number {
  const n = typeof value === "number" && Number.isFinite(value) ? Math.floor(value) : 50
  return Math.max(1, Math.min(200, n))
}

function candidatePaths(explicit?: string): string[] {
  const paths: string[] = []
  if (explicit) paths.push(explicit)
  try { if (FileManager?.appGroupDocumentsDirectory) paths.push(Path.join(FileManager.appGroupDocumentsDirectory, "seforim.db")) } catch {}
  try { if (FileManager?.documentsDirectory) paths.push(Path.join(FileManager.documentsDirectory, "seforim.db")) } catch {}
  paths.push(DEFAULT_DB_PATH)
  return Array.from(new Set(paths.filter(Boolean)))
}

async function pathExists(path: string): Promise<boolean> {
  try {
    const result = FileManager?.exists?.(path)
    return typeof result?.then === "function" ? await result : !!result
  } catch { return false }
}

async function openDatabase(explicit?: string): Promise<{ db: any; path: string }> {
  for (const path of candidatePaths(explicit)) {
    if (!(await pathExists(path))) continue
    try { return { db: SQLite.open(path, { readonly: true, busyMode: 5, label: "otzaria-links" }), path } } catch {}
  }
  throw new Error("לא הצלחתי לפתוח seforim.db. העבר dbPath או העתק את הקובץ לתיקיית Documents של Scripting.")
}

async function resolveLineId(db: any, props: Props): Promise<number | null> {
  if (typeof props.lineId === "number") return props.lineId
  if (typeof props.bookId === "number" && typeof props.lineIndex === "number") {
    const rows = await db.fetchAll<{ lineId: number }>(
      `SELECT id AS lineId FROM line WHERE bookId = ? AND lineIndex = ? LIMIT 1`,
      [props.bookId, props.lineIndex]
    )
    return rows[0]?.lineId ?? null
  }
  return null
}

async function fetchLinks(props: Props): Promise<State> {
  const { db, path } = await openDatabase(props.dbPath)
  const lineId = await resolveLineId(db, props)
  if (!lineId) {
    return { loading: false, dbPath: path, error: "צריך lineId או bookId + lineIndex כדי למצוא קישורים.", resolvedLineId: null, links: [] }
  }

  const limit = safeLimit(props.limit)
  const args: any[] = [lineId, lineId]
  let typeFilter = ""
  if (props.connectionType) {
    typeFilter = " AND connection_type.name = ?"
    args.push(props.connectionType)
  }
  args.push(limit)

  const links = await db.fetchAll<LinkRow>(
    `SELECT
       link.id AS linkId,
       connection_type.name AS connectionType,
       link.sourceLineId AS sourceLineId,
       link.targetLineId AS targetLineId,
       sourceBook.title AS sourceBookTitle,
       targetBook.title AS targetBookTitle,
       sourceLine.heRef AS sourceHeRef,
       targetLine.heRef AS targetHeRef,
       sourceLine.content AS sourceContent,
       targetLine.content AS targetContent
     FROM link
     JOIN connection_type ON connection_type.id = link.connectionTypeId
     JOIN book AS sourceBook ON sourceBook.id = link.sourceBookId
     JOIN book AS targetBook ON targetBook.id = link.targetBookId
     JOIN line AS sourceLine ON sourceLine.id = link.sourceLineId
     JOIN line AS targetLine ON targetLine.id = link.targetLineId
     WHERE (link.sourceLineId = ? OR link.targetLineId = ?)
     ${typeFilter}
     ORDER BY link.connectionTypeId, link.id
     LIMIT ?`,
    args
  )

  return { loading: false, dbPath: path, error: null, resolvedLineId: lineId, links }
}

function LinkCard({ row, centerLineId }: { row: LinkRow; centerLineId: number | null }) {
  const relatedBook = row.sourceLineId === centerLineId ? row.targetBookTitle : row.sourceBookTitle
  const relatedRef = row.sourceLineId === centerLineId ? row.targetHeRef : row.sourceHeRef
  const relatedContent = row.sourceLineId === centerLineId ? row.targetContent : row.sourceContent

  return (
    <VStack spacing={6} padding={10} background="secondarySystemBackground" clipShape={{ type: "rect", cornerRadius: 12 }}>
      <Text fontWeight="bold">{row.connectionType}</Text>
      <Text fontSize={15} fontWeight="semibold">{relatedBook}</Text>
      {!!relatedRef && <Text foregroundStyle="secondary" fontSize={12}>{relatedRef}</Text>}
      <Text fontSize={14}>{stripHtml(relatedContent).slice(0, 520)}</Text>
      <Button title="Log link JSON" action={() => console.log(JSON.stringify(row, null, 2))} />
    </VStack>
  )
}

export default function LinksView(props: Props) {
  const [state, setState] = useState<State>({ loading: true, dbPath: null, error: null, resolvedLineId: null, links: [] })

  useEffect(() => {
    let alive = true
    setState(prev => ({ ...prev, loading: true, error: null }))
    fetchLinks(props)
      .then(next => { if (alive) setState(next) })
      .catch(error => { if (alive) setState({ loading: false, dbPath: null, error: String(error?.message ?? error), resolvedLineId: null, links: [] }) })
    return () => { alive = false }
  }, [props.dbPath, props.lineId, props.bookId, props.lineIndex, props.connectionType, props.limit])

  return (
    <ScrollView>
      <VStack spacing={12} padding={14}>
        <Text fontSize={20} fontWeight="bold">קישורים ומקורות</Text>
        {state.resolvedLineId && <Text foregroundStyle="secondary" fontSize={12}>lineId: {state.resolvedLineId}</Text>}
        {state.dbPath && <Text foregroundStyle="secondary" fontSize={11}>db: {state.dbPath}</Text>}
        {state.loading && <Text>טוען קישורים...</Text>}
        {state.error && <Text foregroundStyle="red">{state.error}</Text>}
        {!state.loading && !state.error && state.links.length === 0 && <Text>לא נמצאו קישורים.</Text>}
        {state.links.map(row => <LinkCard key={row.linkId} row={row} centerLineId={state.resolvedLineId} />)}
      </VStack>
    </ScrollView>
  )
}
