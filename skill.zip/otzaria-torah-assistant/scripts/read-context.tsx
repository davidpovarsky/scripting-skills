import { ScrollView, VStack, Text, Button, useEffect, useState } from "scripting"

declare const SQLite: any
declare const FileManager: any
declare const Path: any

type Props = {
  dbPath?: string
  lineId?: number
  bookId?: number
  lineIndex?: number
  radius?: number
  before?: number
  after?: number
}

type LineRow = {
  lineId: number
  bookId: number
  bookTitle: string
  lineIndex: number
  heRef: string | null
  content: string
}

type State = {
  loading: boolean
  dbPath: string | null
  error: string | null
  center: LineRow | null
  lines: LineRow[]
}

const DEFAULT_DB_PATH = "/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/seforim.db"

function stripHtml(value: string | null | undefined): string {
  return String(value ?? "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim()
}

function candidatePaths(explicit?: string): string[] {
  const paths: string[] = []
  if (explicit) paths.push(explicit)
  try { if (FileManager?.appGroupDocumentsDirectory) paths.push(Path.join(FileManager.appGroupDocumentsDirectory, "seforim.db")) } catch {}
  try { if (FileManager?.documentsDirectory) paths.push(Path.join(FileManager.documentsDirectory, "seforim.db")) } catch {}
  paths.push(DEFAULT_DB_PATH)
  return Array.from(new Set(paths.filter(Boolean)))
}

async function pathExists(path: string): Promise<boolean> {
  try {
    const result = FileManager?.exists?.(path)
    return typeof result?.then === "function" ? await result : !!result
  } catch { return false }
}

async function openDatabase(explicit?: string): Promise<{ db: any; path: string }> {
  for (const path of candidatePaths(explicit)) {
    if (!(await pathExists(path))) continue
    try { return { db: SQLite.open(path, { readonly: true, busyMode: 5, label: "otzaria-context" }), path } } catch {}
  }
  throw new Error("לא הצלחתי לפתוח seforim.db. העבר dbPath או העתק את הקובץ לתיקיית Documents של Scripting.")
}

async function fetchLineById(db: any, lineId: number): Promise<LineRow | null> {
  const rows = await db.fetchAll<LineRow>(
    `SELECT line.id AS lineId, line.bookId AS bookId, book.title AS bookTitle,
            line.lineIndex AS lineIndex, line.heRef AS heRef, line.content AS content
     FROM line
     JOIN book ON book.id = line.bookId
     WHERE line.id = ?
     LIMIT 1`,
    [lineId]
  )
  return rows[0] ?? null
}

async function fetchLineByBookIndex(db: any, bookId: number, lineIndex: number): Promise<LineRow | null> {
  const rows = await db.fetchAll<LineRow>(
    `SELECT line.id AS lineId, line.bookId AS bookId, book.title AS bookTitle,
            line.lineIndex AS lineIndex, line.heRef AS heRef, line.content AS content
     FROM line
     JOIN book ON book.id = line.bookId
     WHERE line.bookId = ? AND line.lineIndex = ?
     LIMIT 1`,
    [bookId, lineIndex]
  )
  return rows[0] ?? null
}

async function readContext(props: Props): Promise<State> {
  const { db, path } = await openDatabase(props.dbPath)
  const radius = Math.max(0, Math.min(20, Math.floor(props.radius ?? 3)))
  const before = Math.max(0, Math.min(30, Math.floor(props.before ?? radius)))
  const after = Math.max(0, Math.min(30, Math.floor(props.after ?? radius)))

  let center: LineRow | null = null
  if (typeof props.lineId === "number") {
    center = await fetchLineById(db, props.lineId)
  } else if (typeof props.bookId === "number" && typeof props.lineIndex === "number") {
    center = await fetchLineByBookIndex(db, props.bookId, props.lineIndex)
  }

  if (!center) {
    return { loading: false, dbPath: path, error: "לא נמצאה שורת מרכז. צריך lineId או bookId + lineIndex.", center: null, lines: [] }
  }

  const start = Math.max(0, center.lineIndex - before)
  const end = center.lineIndex + after
  const lines = await db.fetchAll<LineRow>(
    `SELECT line.id AS lineId, line.bookId AS bookId, book.title AS bookTitle,
            line.lineIndex AS lineIndex, line.heRef AS heRef, line.content AS content
     FROM line
     JOIN book ON book.id = line.bookId
     WHERE line.bookId = ? AND line.lineIndex BETWEEN ? AND ?
     ORDER BY line.lineIndex`,
    [center.bookId, start, end]
  )

  return { loading: false, dbPath: path, error: null, center, lines }
}

function LineCard({ row, centerId }: { row: LineRow; centerId: number | null }) {
  const isCenter = row.lineId === centerId
  return (
    <VStack spacing={4} padding={10} background={isCenter ? "systemYellow" : "secondarySystemBackground"} clipShape={{ type: "rect", cornerRadius: 12 }}>
      <Text fontWeight={isCenter ? "bold" : "semibold"}>{row.bookTitle}</Text>
      <Text foregroundStyle="secondary" fontSize={12}>lineId {row.lineId} · line {row.lineIndex}{row.heRef ? ` · ${row.heRef}` : ""}</Text>
      <Text fontSize={15}>{stripHtml(row.content)}</Text>
      {isCenter && <Text fontSize={12}>שורת המרכז</Text>}
    </VStack>
  )
}

export default function ReadContext(props: Props) {
  const [state, setState] = useState<State>({ loading: true, dbPath: null, error: null, center: null, lines: [] })

  useEffect(() => {
    let alive = true
    setState(prev => ({ ...prev, loading: true, error: null }))
    readContext(props)
      .then(next => { if (alive) setState(next) })
      .catch(error => { if (alive) setState({ loading: false, dbPath: null, error: String(error?.message ?? error), center: null, lines: [] }) })
    return () => { alive = false }
  }, [props.dbPath, props.lineId, props.bookId, props.lineIndex, props.radius, props.before, props.after])

  return (
    <ScrollView>
      <VStack spacing={12} padding={14}>
        <Text fontSize={20} fontWeight="bold">הקשר סביב מקור</Text>
        {state.dbPath && <Text foregroundStyle="secondary" fontSize={11}>db: {state.dbPath}</Text>}
        {state.loading && <Text>טוען הקשר...</Text>}
        {state.error && <Text foregroundStyle="red">{state.error}</Text>}
        {state.center && <Button title="Log center line JSON" action={() => console.log(JSON.stringify(state.center, null, 2))} />}
        {state.lines.map(row => <LineCard key={row.lineId} row={row} centerId={state.center?.lineId ?? null} />)}
      </VStack>
    </ScrollView>
  )
}
