import { ScrollView, VStack, Text, Button, useEffect, useState } from "scripting"

declare const SQLite: any
declare const FileManager: any
declare const Path: any

type Props = {
  dbPath?: string
  query?: string
  limit?: number
}

type State = {
  loading: boolean
  dbPath: string | null
  error: string | null
  meta: Record<string, string>
  counts: Record<string, number>
  results: Array<{ lineId: number; bookTitle: string; lineIndex: number; heRef: string | null; content: string }>
}

const DEFAULT_DB_PATH = "/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/seforim.db"

function stripHtml(value: string | null | undefined): string {
  return String(value ?? "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim()
}

function candidatePaths(explicit?: string): string[] {
  const paths: string[] = []
  if (explicit) paths.push(explicit)
  try { if (FileManager?.appGroupDocumentsDirectory) paths.push(Path.join(FileManager.appGroupDocumentsDirectory, "seforim.db")) } catch {}
  try { if (FileManager?.documentsDirectory) paths.push(Path.join(FileManager.documentsDirectory, "seforim.db")) } catch {}
  paths.push(DEFAULT_DB_PATH)
  return Array.from(new Set(paths.filter(Boolean)))
}

async function pathExists(path: string): Promise<boolean> {
  try {
    const result = FileManager?.exists?.(path)
    return typeof result?.then === "function" ? await result : !!result
  } catch { return false }
}

async function openDatabase(explicit?: string): Promise<{ db: any; path: string; tried: string[] }> {
  const tried: string[] = []
  for (const path of candidatePaths(explicit)) {
    tried.push(path)
    if (!(await pathExists(path))) continue
    try { return { db: SQLite.open(path, { readonly: true, busyMode: 5, label: "otzaria-test" }), path, tried } } catch {}
  }
  throw new Error(`לא הצלחתי לפתוח seforim.db. נוסו: ${tried.join(" | ")}`)
}

async function runTest(props: Props): Promise<State> {
  const { db, path } = await openDatabase(props.dbPath)
  const query = (props.query ?? "שבת").trim()
  const limit = Math.max(1, Math.min(20, Math.floor(props.limit ?? 5)))

  const metaRows = await db.fetchAll<{ key: string; value: string }>(
    `SELECT key, value FROM db_meta ORDER BY key`
  ).catch(() => [])
  const meta: Record<string, string> = {}
  for (const row of metaRows) meta[row.key] = row.value

  const countRows = await db.fetchAll<{ name: string; countValue: number }>(
    `SELECT 'book' AS name, COUNT(*) AS countValue FROM book
     UNION ALL SELECT 'line', COUNT(*) FROM line
     UNION ALL SELECT 'line_fts', COUNT(*) FROM line_fts
     UNION ALL SELECT 'link', COUNT(*) FROM link
     UNION ALL SELECT 'tocEntry', COUNT(*) FROM tocEntry`
  )
  const counts: Record<string, number> = {}
  for (const row of countRows) counts[row.name] = row.countValue

  const results = await db.fetchAll<any>(
    `SELECT line.id AS lineId, book.title AS bookTitle, line.lineIndex AS lineIndex,
            line.heRef AS heRef, line.content AS content
     FROM line_fts
     JOIN line ON line.id = line_fts.rowid
     JOIN book ON book.id = line.bookId
     WHERE line_fts MATCH ?
     ORDER BY bm25(line_fts)
     LIMIT ?`,
    [query, limit]
  )

  return { loading: false, dbPath: path, error: null, meta, counts, results }
}

export default function TestLocalSearch(props: Props) {
  const [state, setState] = useState<State>({ loading: true, dbPath: null, error: null, meta: {}, counts: {}, results: [] })

  useEffect(() => {
    let alive = true
    setState(prev => ({ ...prev, loading: true, error: null }))
    runTest(props)
      .then(next => { if (alive) setState(next) })
      .catch(error => { if (alive) setState({ loading: false, dbPath: null, error: String(error?.message ?? error), meta: {}, counts: {}, results: [] }) })
    return () => { alive = false }
  }, [props.dbPath, props.query, props.limit])

  return (
    <ScrollView>
      <VStack spacing={12} padding={14}>
        <Text fontSize={20} fontWeight="bold">בדיקת seforim.db מקומי</Text>
        {state.loading && <Text>בודק...</Text>}
        {state.error && <Text foregroundStyle="red">{state.error}</Text>}
        {state.dbPath && <Text foregroundStyle="secondary" fontSize={11}>db: {state.dbPath}</Text>}
        {!state.loading && !state.error && (
          <VStack spacing={8}>
            <Text fontWeight="semibold">Meta</Text>
            {Object.keys(state.meta).map(key => <Text key={key} fontSize={12}>{key}: {state.meta[key]}</Text>)}
            <Text fontWeight="semibold">Counts</Text>
            {Object.keys(state.counts).map(key => <Text key={key} fontSize={12}>{key}: {state.counts[key]}</Text>)}
            <Button title="Log full test state" action={() => console.log(JSON.stringify(state, null, 2))} />
            <Text fontWeight="semibold">Sample search: {props.query ?? "שבת"}</Text>
            {state.results.map(row => (
              <VStack key={row.lineId} spacing={4} padding={10} background="secondarySystemBackground" clipShape={{ type: "rect", cornerRadius: 12 }}>
                <Text fontWeight="semibold">{row.bookTitle}</Text>
                <Text foregroundStyle="secondary" fontSize={12}>lineId {row.lineId} · line {row.lineIndex}{row.heRef ? ` · ${row.heRef}` : ""}</Text>
                <Text>{stripHtml(row.content).slice(0, 420)}</Text>
              </VStack>
            ))}
          </VStack>
        )}
      </VStack>
    </ScrollView>
  )
}
