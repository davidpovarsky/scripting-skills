import { ScrollView, VStack, Text, TextField, Button, useEffect, useState } from "scripting"

declare const SQLite: any
declare const FileManager: any
declare const Path: any

type Props = {
  dbPath?: string
  query?: string
  limit?: number
  contextRadius?: number
}

type SearchRow = {
  lineId: number
  bookId: number
  bookTitle: string
  lineIndex: number
  heRef: string | null
  content: string
  rank?: number | null
}

type LinkRow = {
  linkId: number
  connectionType: string
  relatedBookTitle: string
  relatedHeRef: string | null
  relatedContent: string
}

type State = {
  dbPath: string | null
  loading: boolean
  error: string | null
  query: string
  results: SearchRow[]
  selected: SearchRow | null
  context: SearchRow[]
  links: LinkRow[]
}

const DEFAULT_DB_PATH = "/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/seforim.db"

function stripHtml(value: string | null | undefined): string {
  return String(value ?? "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim()
}

function normalizeQuery(value: string): string {
  return value.trim().replace(/\s+/g, " ")
}

function candidatePaths(explicit?: string): string[] {
  const paths: string[] = []
  if (explicit) paths.push(explicit)
  try { if (FileManager?.appGroupDocumentsDirectory) paths.push(Path.join(FileManager.appGroupDocumentsDirectory, "seforim.db")) } catch {}
  try { if (FileManager?.documentsDirectory) paths.push(Path.join(FileManager.documentsDirectory, "seforim.db")) } catch {}
  paths.push(DEFAULT_DB_PATH)
  return Array.from(new Set(paths.filter(Boolean)))
}

async function pathExists(path: string): Promise<boolean> {
  try {
    const result = FileManager?.exists?.(path)
    return typeof result?.then === "function" ? await result : !!result
  } catch { return false }
}

async function openDatabase(explicit?: string): Promise<{ db: any; path: string }> {
  for (const path of candidatePaths(explicit)) {
    if (!(await pathExists(path))) continue
    try { return { db: SQLite.open(path, { readonly: true, busyMode: 5, label: "otzaria-workflow" }), path } } catch {}
  }
  throw new Error("לא הצלחתי לפתוח seforim.db. העבר dbPath או העתק את הקובץ לתיקיית Documents של Scripting.")
}

function ftsCandidates(query: string): string[] {
  const q = normalizeQuery(query)
  const list: string[] = []
  if (!q) return list
  list.push(q)
  if (q.includes('"')) list.push(q.replace(/"/g, ""))
  const words = q.replace(/"/g, "").split(" ").filter(Boolean)
  if (words.length >= 2 && words.length <= 5) list.push(`"${words.join(" ")}"`)
  return Array.from(new Set(list))
}

async function searchRows(db: any, query: string, limit: number): Promise<SearchRow[]> {
  for (const candidate of ftsCandidates(query)) {
    try {
      const rows = await db.fetchAll<SearchRow>(
        `SELECT line.id AS lineId, line.bookId AS bookId, book.title AS bookTitle,
                line.lineIndex AS lineIndex, line.heRef AS heRef, line.content AS content,
                bm25(line_fts) AS rank
         FROM line_fts
         JOIN line ON line.id = line_fts.rowid
         JOIN book ON book.id = line.bookId
         WHERE line_fts MATCH ?
         ORDER BY rank
         LIMIT ?`,
        [candidate, limit]
      )
      if (rows.length > 0) return rows
    } catch (error) {
      console.log("FTS candidate failed", candidate, String(error))
    }
  }
  return []
}

async function fetchContext(db: any, row: SearchRow, radius: number): Promise<SearchRow[]> {
  const start = Math.max(0, row.lineIndex - radius)
  const end = row.lineIndex + radius
  return await db.fetchAll<SearchRow>(
    `SELECT line.id AS lineId, line.bookId AS bookId, book.title AS bookTitle,
            line.lineIndex AS lineIndex, line.heRef AS heRef, line.content AS content,
            NULL AS rank
     FROM line
     JOIN book ON book.id = line.bookId
     WHERE line.bookId = ? AND line.lineIndex BETWEEN ? AND ?
     ORDER BY line.lineIndex`,
    [row.bookId, start, end]
  )
}

async function fetchLinks(db: any, row: SearchRow, limit: number): Promise<LinkRow[]> {
  const raw = await db.fetchAll<any>(
    `SELECT
       link.id AS linkId,
       connection_type.name AS connectionType,
       link.sourceLineId AS sourceLineId,
       link.targetLineId AS targetLineId,
       sourceBook.title AS sourceBookTitle,
       targetBook.title AS targetBookTitle,
       sourceLine.heRef AS sourceHeRef,
       targetLine.heRef AS targetHeRef,
       sourceLine.content AS sourceContent,
       targetLine.content AS targetContent
     FROM link
     JOIN connection_type ON connection_type.id = link.connectionTypeId
     JOIN book AS sourceBook ON sourceBook.id = link.sourceBookId
     JOIN book AS targetBook ON targetBook.id = link.targetBookId
     JOIN line AS sourceLine ON sourceLine.id = link.sourceLineId
     JOIN line AS targetLine ON targetLine.id = link.targetLineId
     WHERE link.sourceLineId = ? OR link.targetLineId = ?
     ORDER BY link.connectionTypeId, link.id
     LIMIT ?`,
    [row.lineId, row.lineId, limit]
  )

  return raw.map((link: any) => {
    const targetSide = link.sourceLineId === row.lineId
    return {
      linkId: link.linkId,
      connectionType: link.connectionType,
      relatedBookTitle: targetSide ? link.targetBookTitle : link.sourceBookTitle,
      relatedHeRef: targetSide ? link.targetHeRef : link.sourceHeRef,
      relatedContent: targetSide ? link.targetContent : link.sourceContent,
    }
  })
}

function ResultCard({ row, selected, onOpen }: { row: SearchRow; selected: boolean; onOpen: () => void }) {
  return (
    <VStack spacing={4} padding={10} background={selected ? "systemYellow" : "secondarySystemBackground"} clipShape={{ type: "rect", cornerRadius: 12 }}>
      <Text fontWeight="bold">{row.bookTitle}</Text>
      <Text foregroundStyle="secondary" fontSize={12}>lineId {row.lineId} · line {row.lineIndex}{row.heRef ? ` · ${row.heRef}` : ""}</Text>
      <Text fontSize={14}>{stripHtml(row.content).slice(0, 360)}</Text>
      <Button title={selected ? "Selected" : "Open context and links"} action={onOpen} />
    </VStack>
  )
}

function ContextCard({ row, center }: { row: SearchRow; center: SearchRow | null }) {
  const isCenter = row.lineId === center?.lineId
  return (
    <VStack spacing={3} padding={8} background={isCenter ? "systemYellow" : "tertiarySystemBackground"} clipShape={{ type: "rect", cornerRadius: 10 }}>
      <Text foregroundStyle="secondary" fontSize={12}>{row.heRef ?? `${row.bookTitle} · line ${row.lineIndex}`}</Text>
      <Text fontSize={14}>{stripHtml(row.content)}</Text>
    </VStack>
  )
}

function LinkCard({ row }: { row: LinkRow }) {
  return (
    <VStack spacing={3} padding={8} background="tertiarySystemBackground" clipShape={{ type: "rect", cornerRadius: 10 }}>
      <Text fontSize={12} fontWeight="bold">{row.connectionType}</Text>
      <Text fontSize={14} fontWeight="semibold">{row.relatedBookTitle}</Text>
      {!!row.relatedHeRef && <Text foregroundStyle="secondary" fontSize={12}>{row.relatedHeRef}</Text>}
      <Text fontSize={13}>{stripHtml(row.relatedContent).slice(0, 420)}</Text>
    </VStack>
  )
}

export default function OtzariaWorkflowView(props: Props) {
  const [state, setState] = useState<State>({
    dbPath: null,
    loading: false,
    error: null,
    query: props.query ?? "שבת",
    results: [],
    selected: null,
    context: [],
    links: [],
  })

  const performSearch = async (queryValue: string) => {
    const query = normalizeQuery(queryValue)
    if (!query) {
      setState(prev => ({ ...prev, error: "הכנס מילות חיפוש.", results: [], selected: null, context: [], links: [] }))
      return
    }
    setState(prev => ({ ...prev, loading: true, error: null, query }))
    try {
      const { db, path } = await openDatabase(props.dbPath)
      const limit = Math.max(1, Math.min(50, Math.floor(props.limit ?? 20)))
      const rows = await searchRows(db, query, limit)
      setState(prev => ({ ...prev, loading: false, dbPath: path, results: rows, selected: null, context: [], links: [] }))
    } catch (error) {
      setState(prev => ({ ...prev, loading: false, error: String(error?.message ?? error), results: [], selected: null, context: [], links: [] }))
    }
  }

  const openRow = async (row: SearchRow) => {
    setState(prev => ({ ...prev, loading: true, error: null, selected: row }))
    try {
      const { db, path } = await openDatabase(props.dbPath)
      const radius = Math.max(0, Math.min(20, Math.floor(props.contextRadius ?? 3)))
      const context = await fetchContext(db, row, radius)
      const links = await fetchLinks(db, row, 40)
      setState(prev => ({ ...prev, loading: false, dbPath: path, selected: row, context, links }))
    } catch (error) {
      setState(prev => ({ ...prev, loading: false, error: String(error?.message ?? error) }))
    }
  }

  useEffect(() => {
    if (props.query) performSearch(props.query)
  }, [props.query, props.dbPath])

  return (
    <ScrollView>
      <VStack spacing={12} padding={14}>
        <Text fontSize={20} fontWeight="bold">אוצריא — חיפוש ופתיחה מהירה</Text>
        <TextField title="חיפוש" value={state.query} onChanged={value => setState(prev => ({ ...prev, query: value }))} />
        <Button title="Search" action={() => performSearch(state.query)} />
        {state.dbPath && <Text foregroundStyle="secondary" fontSize={11}>db: {state.dbPath}</Text>}
        {state.loading && <Text>טוען...</Text>}
        {state.error && <Text foregroundStyle="red">{state.error}</Text>}

        <Text fontWeight="semibold">תוצאות</Text>
        {state.results.length === 0 && !state.loading && <Text foregroundStyle="secondary">אין תוצאות עדיין.</Text>}
        {state.results.map(row => (
          <ResultCard
            key={row.lineId}
            row={row}
            selected={row.lineId === state.selected?.lineId}
            onOpen={() => openRow(row)}
          />
        ))}

        {state.context.length > 0 && <Text fontWeight="semibold">הקשר</Text>}
        {state.context.map(row => <ContextCard key={row.lineId} row={row} center={state.selected} />)}

        {state.links.length > 0 && <Text fontWeight="semibold">קישורים / מפרשים / מקורות</Text>}
        {state.links.map(row => <LinkCard key={row.linkId} row={row} />)}

        {state.selected && <Button title="Log selected JSON" action={() => console.log(JSON.stringify(state.selected, null, 2))} />}
      </VStack>
    </ScrollView>
  )
}
