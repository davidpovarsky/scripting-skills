import { ScrollView, VStack, Text, Button, useEffect, useState } from "scripting"

declare const SQLite: any
declare const FileManager: any
declare const Path: any

type SearchMode = "auto" | "text" | "book" | "ref"

type Props = {
  query?: string
  mode?: SearchMode
  limit?: number
  dbPath?: string
}

type TextResult = {
  kind: "text"
  lineId: number
  bookId: number
  bookTitle: string
  lineIndex: number
  heRef: string | null
  content: string
  rank?: number | null
}

type BookResult = {
  kind: "book"
  bookId: number
  bookTitle: string
  heShortDesc: string | null
  totalLines: number
  isBaseBook: number
}

type RefResult = TextResult & { kind: "ref" }

type Result = TextResult | BookResult | RefResult

type State = {
  loading: boolean
  dbPath: string | null
  error: string | null
  results: Result[]
  searchedAs: string[]
}

const DEFAULT_DB_PATH = "/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/seforim.db"

function safeLimit(value: unknown): number {
  const n = typeof value === "number" && Number.isFinite(value) ? Math.floor(value) : 20
  return Math.max(1, Math.min(50, n))
}

function stripHtml(value: string | null | undefined): string {
  return String(value ?? "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim()
}

function normalizeQuery(value: string): string {
  return value.trim().replace(/\s+/g, " ")
}

function looksLikeReference(query: string): boolean {
  return /\d|[:.,]/.test(query) || /\b(פרק|פסוק|דף|עמוד|סימן|סעיף)\b/.test(query)
}

function candidatePaths(explicit?: string): string[] {
  const paths: string[] = []
  if (explicit) paths.push(explicit)
  try {
    if (FileManager?.appGroupDocumentsDirectory) {
      paths.push(Path.join(FileManager.appGroupDocumentsDirectory, "seforim.db"))
    }
  } catch {}
  try {
    if (FileManager?.documentsDirectory) {
      paths.push(Path.join(FileManager.documentsDirectory, "seforim.db"))
    }
  } catch {}
  paths.push(DEFAULT_DB_PATH)
  return Array.from(new Set(paths.filter(Boolean)))
}

async function pathExists(path: string): Promise<boolean> {
  try {
    const result = FileManager?.exists?.(path)
    return typeof result?.then === "function" ? await result : !!result
  } catch {
    return false
  }
}

async function openDatabase(explicit?: string): Promise<{ db: any; path: string }> {
  const tried: string[] = []
  for (const path of candidatePaths(explicit)) {
    tried.push(path)
    if (!(await pathExists(path))) continue
    try {
      const db = SQLite.open(path, {
        readonly: true,
        foreignKeysEnabled: true,
        journalMode: "wal",
        busyMode: 5,
        maximumReaderCount: 3,
        label: "otzaria-search",
      })
      return { db, path }
    } catch {}
  }
  throw new Error(`לא נמצא או לא נפתח seforim.db. נוסו נתיבים: ${tried.join(" | ")}`)
}

function ftsCandidates(query: string): string[] {
  const q = normalizeQuery(query)
  const list: string[] = []
  if (!q) return list
  list.push(q)
  if (q.includes('"')) list.push(q.replace(/"/g, ""))
  const words = q.replace(/"/g, "").split(" ").filter(Boolean)
  if (words.length >= 2 && words.length <= 5) list.push(`"${words.join(" ")}"`)
  return Array.from(new Set(list))
}

async function textSearch(db: any, query: string, limit: number): Promise<TextResult[]> {
  let lastError: unknown = null
  for (const fts of ftsCandidates(query)) {
    try {
      const rows = await db.fetchAll<any>(
        `SELECT
           line.id AS lineId,
           line.bookId AS bookId,
           book.title AS bookTitle,
           line.lineIndex AS lineIndex,
           line.heRef AS heRef,
           line.content AS content,
           bm25(line_fts) AS rank
         FROM line_fts
         JOIN line ON line.id = line_fts.rowid
         JOIN book ON book.id = line.bookId
         WHERE line_fts MATCH ?
         ORDER BY rank
         LIMIT ?`,
        [fts, limit]
      )
      if (rows.length > 0) {
        return rows.map((row: any) => ({ kind: "text", ...row }))
      }
    } catch (error) {
      lastError = error
    }
  }
  if (lastError) console.log("FTS fallback exhausted:", String(lastError))
  return []
}

async function bookSearch(db: any, query: string, limit: number): Promise<BookResult[]> {
  const q = `%${normalizeQuery(query)}%`
  const rows = await db.fetchAll<any>(
    `SELECT
       id AS bookId,
       title AS bookTitle,
       heShortDesc AS heShortDesc,
       totalLines AS totalLines,
       isBaseBook AS isBaseBook
     FROM book
     WHERE title LIKE ?
     ORDER BY isBaseBook DESC, orderIndex ASC, title ASC
     LIMIT ?`,
    [q, limit]
  )
  return rows.map((row: any) => ({ kind: "book", ...row }))
}

async function refSearch(db: any, query: string, limit: number): Promise<RefResult[]> {
  const q = normalizeQuery(query)
  const rows = await db.fetchAll<any>(
    `SELECT
       line.id AS lineId,
       line.bookId AS bookId,
       book.title AS bookTitle,
       line.lineIndex AS lineIndex,
       line.heRef AS heRef,
       line.content AS content,
       NULL AS rank
     FROM line
     JOIN book ON book.id = line.bookId
     WHERE line.heRef LIKE ? OR book.title = ?
     ORDER BY book.orderIndex, line.lineIndex
     LIMIT ?`,
    [`%${q}%`, q, limit]
  )
  return rows.map((row: any) => ({ kind: "ref", ...row }))
}

async function runSearch(props: Props): Promise<State> {
  const query = normalizeQuery(props.query ?? "")
  if (!query) {
    return { loading: false, dbPath: null, error: "חסר query לחיפוש.", results: [], searchedAs: [] }
  }

  const { db, path } = await openDatabase(props.dbPath)
  const limit = safeLimit(props.limit)
  const mode: SearchMode = props.mode ?? "auto"
  const searchedAs: string[] = []
  const results: Result[] = []

  if (mode === "book" || (mode === "auto" && query.length <= 40)) {
    searchedAs.push("book")
    results.push(...await bookSearch(db, query, limit))
  }

  if (mode === "ref" || (mode === "auto" && looksLikeReference(query))) {
    searchedAs.push("ref")
    results.push(...await refSearch(db, query, limit))
  }

  if (mode === "text" || mode === "auto") {
    searchedAs.push("text")
    const remaining = Math.max(1, limit - results.length)
    results.push(...await textSearch(db, query, remaining))
  }

  const seen = new Set<string>()
  const unique = results.filter(result => {
    const key = result.kind === "book" ? `book:${result.bookId}` : `line:${result.lineId}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })

  return { loading: false, dbPath: path, error: null, results: unique.slice(0, limit), searchedAs }
}

function ResultCard({ result }: { result: Result }) {
  if (result.kind === "book") {
    return (
      <VStack spacing={4} padding={10} background="secondarySystemBackground" clipShape={{ type: "rect", cornerRadius: 12 }}>
        <Text fontSize={16} fontWeight="semibold">{result.bookTitle}</Text>
        <Text foregroundStyle="secondary" fontSize={12}>{result.totalLines} lines · base book: {result.isBaseBook ? "yes" : "no"}</Text>
        {!!result.heShortDesc && <Text fontSize={13}>{stripHtml(result.heShortDesc).slice(0, 280)}</Text>}
      </VStack>
    )
  }

  const preview = stripHtml(result.content)
  return (
    <VStack spacing={4} padding={10} background="secondarySystemBackground" clipShape={{ type: "rect", cornerRadius: 12 }}>
      <Text fontSize={16} fontWeight="semibold">{result.bookTitle}</Text>
      <Text foregroundStyle="secondary" fontSize={12}>lineId {result.lineId} · line {result.lineIndex}{result.heRef ? ` · ${result.heRef}` : ""}</Text>
      <Text fontSize={14}>{preview.slice(0, 420)}</Text>
      <Button title="Log result details" action={() => console.log(JSON.stringify(result, null, 2))} />
    </VStack>
  )
}

export default function OtzariaSearch(props: Props) {
  const [state, setState] = useState<State>({
    loading: true,
    dbPath: null,
    error: null,
    results: [],
    searchedAs: [],
  })

  useEffect(() => {
    let alive = true
    setState(prev => ({ ...prev, loading: true, error: null }))
    runSearch(props)
      .then(next => { if (alive) setState(next) })
      .catch(error => {
        if (alive) setState({ loading: false, dbPath: null, error: String(error?.message ?? error), results: [], searchedAs: [] })
      })
    return () => { alive = false }
  }, [props.query, props.mode, props.limit, props.dbPath])

  return (
    <ScrollView>
      <VStack spacing={12} padding={14}>
        <Text fontSize={20} fontWeight="bold">חיפוש באוצריא / Seforim</Text>
        <Text foregroundStyle="secondary" fontSize={12}>query: {props.query ?? ""}</Text>
        {state.dbPath && <Text foregroundStyle="secondary" fontSize={11}>db: {state.dbPath}</Text>}
        {state.loading && <Text>מחפש...</Text>}
        {state.error && <Text foregroundStyle="red">{state.error}</Text>}
        {!state.loading && !state.error && <Text foregroundStyle="secondary" fontSize={12}>searched as: {state.searchedAs.join(", ")} · results: {state.results.length}</Text>}
        {!state.loading && !state.error && state.results.length === 0 && <Text>לא נמצאו תוצאות.</Text>}
        {state.results.map((result, index) => <ResultCard key={index} result={result} />)}
      </VStack>
    </ScrollView>
  )
}
