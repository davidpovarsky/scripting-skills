# Assets

This skill does not require binary assets. This directory is intentionally kept so future UI templates, icons, or sample databases can be added without changing the skill structure.
