---
name: otzaria-torah-assistant
description: local torah library assistant for the scripting app and otzaria/seforim sqlite databases. use when the user asks to search hebrew torah texts, inspect a seforim.db/otzaria sqlite database, find sources, read a hebrew reference, retrieve surrounding context, show links/commentaries/targum/sources, or build scripting-file outputs that render local torah search and reading scripts. this skill is not an assistanttool; it provides skill instructions, references, and tsx scripts only.
---

# Otzaria Torah Assistant

## Core rule

Use this skill as a **Skill-only bundle**. Do not create or refer to `assistant_tool.json`, `assistant_tool.tsx`, AssistantTool registration APIs, approval flows, or tool manifests. The bundled files are ordinary Scripting TSX scripts that can be rendered or run from the Scripting app.

## What this skill provides

Use the scripts in `scripts/` to help the user work with a local Otzaria/Seforim SQLite database, usually named `seforim.db`.

Supported tasks:

- Search across Torah texts with FTS5.
- Search books by title.
- Read a precise Hebrew reference or book/line range.
- Read surrounding context for a line or result.
- Show linked sources, commentaries, targum, references, and other connections.
- Render a compact workflow UI for searching, opening context, and checking links.
- Test the user's local database path from Scripting.

## Default database assumptions

The expected database is the Seforim/Otzaria SQLite database analyzed in `references/database-schema.md`.

Default candidate paths used by scripts:

1. `props.dbPath`, when provided.
2. `FileManager.appGroupDocumentsDirectory/seforim.db`, when available.
3. `FileManager.documentsDirectory/seforim.db`.
4. `/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/seforim.db`.

If a script cannot open the database, tell the user to copy `seforim.db` into Scripting Documents or pass an explicit `dbPath` prop.

## How to render a script in chat

When the user wants an interactive Scripting view, output a `scripting-file` block pointing to the script under the installed skill folder.

Use this path pattern:

````markdown
```scripting-file
{
  "path": "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-skills/otzaria-torah-assistant/scripts/search.tsx",
  "props": {
    "query": "שבת חולה",
    "limit": 20
  }
}
```
````

Use the same base path for other scripts.

## Script selection

| User need | Use this script |
| --- | --- |
| quick local database smoke test | `scripts/test-local-search.tsx` |
| search text or books | `scripts/search.tsx` |
| read a reference, book, or line range | `scripts/read-ref.tsx` |
| read surrounding context around one result | `scripts/read-context.tsx` |
| show linked sources/commentaries/targum | `scripts/links.tsx` |
| show a compact all-in-one UI | `scripts/otzaria-workflow-view.tsx` |

## Output behavior

Prefer a useful rendered Scripting view over a plain SQL explanation when the user is trying to actually use the local database.

When the user asks for code files or a package, provide the Skill package or script contents directly. Keep it Skill-only.

When the user asks conceptually how it works, explain in Hebrew unless the user switches language.

## Query guidance

Read `references/search-behavior.md` before changing search behavior. Important defaults:

- Use `line_fts MATCH ?` joined to `line` and `book` for content search.
- Use `bm25(line_fts)` for rank when available.
- Use `book.title LIKE ?` for book/title search.
- Use `line.heRef LIKE ?` for reference lookup.
- Keep `limit` conservative: 20 for UI, 50 max unless the user explicitly asks for more.
- For Hebrew input with niqqud, try the exact query first; if it fails or returns nothing, also try a plain/unquoted fallback.

## Reference files

- `references/database-schema.md` — known table layout and useful SQL patterns.
- `references/search-behavior.md` — FTS behavior, escaping, ranking, and fallbacks.
- `references/workflow.md` — step-by-step workflow for using the bundled scripts.

