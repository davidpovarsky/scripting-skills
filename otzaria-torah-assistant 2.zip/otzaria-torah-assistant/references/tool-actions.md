# Tool actions

Use `otzaria_torah` AssistantTool.

## search

```json
{"action":"search","query":"חולה בשבת","limit":10}
```

## read_ref

```json
{"action":"read_ref","ref":"בראשית א, א","limit":5}
```

## read_context

```json
{"action":"read_context","lineId":12345,"radius":3}
```

## find_book

```json
{"action":"find_book","query":"רמבם","limit":10}
```

## get_links

Commentaries on a source:

```json
{"action":"get_links","lineId":12345,"direction":"incoming","connectionType":"COMMENTARY"}
```

Targum from a base verse:

```json
{"action":"get_links","lineId":12345,"direction":"outgoing","connectionType":"TARGUM"}
```

## get_toc

```json
{"action":"get_toc","bookId":1,"limit":80}
```

## db_status

```json
{"action":"db_status"}
```
