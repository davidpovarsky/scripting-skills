# Project architecture

The Skill must not duplicate implementation code. It points to the regular Scripting project:

```text
Documents/scripts/otzaria_torah/
```

The regular project owns:

- DB discovery and opening
- FTS search
- heRef lookup
- context reads
- links/commentary/targum/source/reference lookup
- TOC lookup
- AssistantTool entry point
- development scripts

The Skill owns:

- routing instructions
- tool call examples
- debugging workflow
- answer formatting rules
