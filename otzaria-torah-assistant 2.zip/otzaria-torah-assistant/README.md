# Otzaria Torah Assistant Skill

This Skill contains instructions only. It assumes the canonical code is installed as a regular Scripting project named `otzaria_torah`.

Use the AssistantTool `otzaria_torah` for normal source retrieval. Use project scripts only for debugging and maintenance.
