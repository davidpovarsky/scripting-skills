---
name: otzaria-torah-assistant
summary: Use the user's local Otzaria/Seforim Scripting project and AssistantTool to search, read, and analyze Torah sources from seforim.db.
description: Use this skill whenever the user asks to search Otzaria, query seforim.db, read Torah sources, inspect local Jewish library links/commentaries/targum, debug the Otzaria Scripting project, or operate the otzaria_torah AssistantTool. The skill is instructions only; the canonical implementation lives in the regular Scripting project at Documents/scripts/otzaria_torah. Prefer the AssistantTool for normal source retrieval and use file/shell/scripting-ts only for debugging, maintenance, or project edits.
---

# Otzaria Torah Assistant

## Canonical project

The code lives in a regular Scripting project, not inside this Skill:

```text
/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripts/otzaria_torah/
```

Expected structure:

```text
otzaria_torah/
  script.json
  index.tsx
  assistant_tool.json
  assistant_tool.tsx
  src/
    core/
    db/
    tool/
    ui/
  scripts/
```

The AssistantTool files are at the project root and import the real implementation from `src/`.

## Normal source workflow

For ordinary Torah/Otzaria questions, prefer the AssistantTool. Never call `otzaria_torah` with empty parameters. If a call returns a missing-parameters error, immediately retry with an explicit JSON argument such as `{"action":"search","query":"..."}`:

Tool name / id:

```text
otzaria_torah
```

Actions:

```text
search
read_ref
read_context
find_book
get_links
get_toc
db_status
```

Common valid AssistantTool argument objects:

```json
{"action":"search","query":"חולה בשבת","limit":10}
{"action":"read_ref","ref":"בראשית א, א","limit":5}
{"action":"read_context","lineId":12345,"radius":3}
{"action":"find_book","query":"רמבם","limit":10}
{"action":"get_links","lineId":12345,"direction":"incoming","connectionType":"COMMENTARY"}
{"action":"get_toc","bookId":1,"limit":80}
{"action":"db_status"}
```


Compatibility fallback: if the host only exposes a generic AssistantTool caller and direct structured fields are unreliable, pass the whole action object as a JSON string in `tool_arguments`, for example:

```json
{"tool_arguments":"{\"action\":\"search\",\"query\":\"חולה בשבת\",\"limit\":5}"}
```

Never treat `db_status` as a search result. `db_status` is only a health check. If the user asked to search and the result says `פעולה: db_status`, retry the tool with explicit `action=search` and `query`.

If the user provides an explicit reference, call `read_ref` before searching. If a search result looks relevant, call `read_context` around its `lineId`. For commentaries on a source, call `get_links` with `direction="incoming"` and `connectionType="COMMENTARY"`. For targum on a base verse, use `direction="outgoing"` and `connectionType="TARGUM"`.

## Search behavior notes

- `line_fts` does not normalize Hebrew niqqud/trop. Searching unvoweled Hebrew may miss voweled Tanach lines.
- Exact references should use `read_ref`, not FTS search.
- FTS phrase search uses quoted phrases.
- `rank` is ordered ascending; lower/negative rank is usually better.
- Strip HTML before showing source text.
- Prefer rows with `heRef` for citations.

## When to use project scripts instead of AssistantTool

Use the regular project files with `file_tool`, `run_shell_command`, or `scripting-ts` only when the user asks to:

- debug tool failures;
- inspect or edit project code;
- run smoke tests;
- inspect DB schema;
- render or preview UI;
- package or rebuild the project;
- update the Skill instructions.

Useful project scripts:

```text
scripts/smoke-test.ts
scripts/assistant-tool-param-test.ts
```

Normal answers to Torah questions should not be produced by shelling out unless the AssistantTool is unavailable or being debugged.

## Answer style

When answering from sources:

1. Show the sources consulted.
2. Quote or paraphrase only what was actually returned by the tool.
3. Do not rely on prior Torah knowledge when source support is missing.
4. If sources are weak or not found, say so clearly.
5. Use Hebrew source labels and keep citations readable.
