import { Script } from "scripting"

const FileManager = (globalThis as any).FileManager

function log(s: string) { console.log(s) }
function joinPath(base: string, name: string) { return String(base || "").replace(/\/+$/, "") + "/" + String(name || "").replace(/^\/+/, "") }

const files = [
  "assistant_tool.json",
  "assistant_tool.tsx"
]

async function run() {
  if (!FileManager) throw new Error("FileManager global is not available")

  const sourceDir = joinPath(Script.directory.replace(/\/scripts\/?$/, ""), "assistant-tool-otzaria")
  const scriptsDir = FileManager.scriptsDirectory || joinPath(FileManager.iCloudDocumentsDirectory || FileManager.documentsDirectory, "scripts")
  const destDir = joinPath(scriptsDir, "otzaria_torah")

  log("Source: " + sourceDir)
  log("Destination: " + destDir)

  await FileManager.createDirectory(destDir, true)

  for (const file of files) {
    const from = joinPath(sourceDir, file)
    const to = joinPath(destDir, file)
    const text = await FileManager.readAsString(from)
    await FileManager.writeAsString(to, text)
    log("Installed: " + to)
  }

  log("")
  log("Done. Restart/open a new Assistant conversation if the tool does not appear immediately.")
  log("Tool id: otzaria_torah")
  Script.exit()
}

run().catch(error => {
  log(String(error))
  Script.exit()
})
