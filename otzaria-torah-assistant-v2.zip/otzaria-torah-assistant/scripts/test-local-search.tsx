import { Script } from "scripting"

const SQLite = (globalThis as any).SQLite
const FileManager = (globalThis as any).FileManager

function log(msg: string) { console.log(msg) }
function joinPath(base: string, name: string) { return String(base || "").replace(/\/+$/, "") + "/" + String(name || "").replace(/^\/+/, "") }
function stripHtml(s: any) { return String(s ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim() }

async function exists(path: string) {
  try { return await FileManager.exists(path) } catch { return false }
}

async function findDb() {
  const candidates: string[] = []
  if (FileManager?.isiCloudEnabled && FileManager?.iCloudDocumentsDirectory) {
    candidates.push(joinPath(FileManager.iCloudDocumentsDirectory, "seforim.db"))
    candidates.push(joinPath(FileManager.iCloudDocumentsDirectory, "seforim.dp"))
  }
  if (FileManager?.documentsDirectory) {
    candidates.push(joinPath(FileManager.documentsDirectory, "seforim.db"))
    candidates.push(joinPath(FileManager.documentsDirectory, "seforim.dp"))
  }
  if (FileManager?.appGroupDocumentsDirectory) {
    candidates.push(joinPath(FileManager.appGroupDocumentsDirectory, "seforim.db"))
    candidates.push(joinPath(FileManager.appGroupDocumentsDirectory, "seforim.dp"))
  }
  for (const p of Array.from(new Set(candidates))) {
    if (await exists(p)) return p
  }
  throw new Error("seforim.db / seforim.dp not found in Scripting Documents")
}

async function run() {
  if (!SQLite) throw new Error("SQLite global is not available")
  if (!FileManager) throw new Error("FileManager global is not available")

  const dbPath = await findDb()
  log("DB found: " + dbPath)

  const db = SQLite.open(dbPath, {
    readonly: true,
    foreignKeysEnabled: false,
    journalMode: "default",
    busyMode: "immediateError",
    maximumReaderCount: 1,
    label: "otzaria-test"
  })

  const queries = ["בראשית", "שבת חולה", "אמר רב", "ואהבת"]
  for (const query of queries) {
    log("\n=== " + query + " ===")
    const rows = await db.fetchAll([
      "SELECT line.id AS lineId, line.heRef, line.content, line.lineIndex, book.title AS bookTitle, line_fts.rank AS rank",
      "FROM line_fts",
      "JOIN line ON line.id = line_fts.rowid",
      "JOIN book ON book.id = line.bookId",
      "WHERE line_fts MATCH ? AND line.heRef IS NOT NULL",
      "ORDER BY line_fts.rank",
      "LIMIT 5"
    ].join("\n"), [query])
    for (const row of rows) {
      log(row.bookTitle + " — " + row.heRef + " · lineId=" + row.lineId)
      log(stripHtml(row.content).slice(0, 280))
    }
  }

  try { if (typeof db.close === "function") await db.close() } catch {}
  Script.exit()
}

run().catch(e => {
  log(String(e))
  Script.exit()
})
