const AssistantTool = (globalThis as any).AssistantTool
const SQLite = (globalThis as any).SQLite
const FileManager = (globalThis as any).FileManager

type Row = Record<string, any>

type Params = {
  action: "search" | "read_ref" | "read_context" | "find_book" | "get_links" | "get_toc" | string
  query?: string
  ref?: string
  lineId?: number
  bookId?: number
  lineIndex?: number
  radius?: number
  limit?: number
  heRefOnly?: boolean
  direction?: "incoming" | "outgoing" | "both" | string
  connectionType?: "OTHER" | "COMMENTARY" | "SOURCE" | "TARGUM" | "REFERENCE" | string
  dbPath?: string
}

function safe(value: any): string {
  if (value == null) return ""
  try { return String(value) } catch { return "[unprintable]" }
}

function joinPath(base: string, name: string): string {
  return String(base || "").replace(/\/+$/, "") + "/" + String(name || "").replace(/^\/+/, "")
}

function clampInt(value: any, fallback: number, min: number, max: number): number {
  const n = Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.max(min, Math.min(max, Math.floor(n)))
}

function quoteIdent(name: string): string {
  return `"${String(name).replaceAll(`"`, `""`)}"`
}

function stripHtml(text: any): string {
  return safe(text)
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n")
    .replace(/<\/h[1-6]>/gi, "\n")
    .replace(/<[^>]*>/g, " ")
    .replaceAll("&nbsp;", " ")
    .replaceAll("&quot;", `"`)
    .replaceAll("&apos;", `'`)
    .replaceAll("&lt;", "<")
    .replaceAll("&gt;", ">")
    .replaceAll("&amp;", "&")
    .replace(/\s+/g, " ")
    .trim()
}

function stripHebrewMarks(text: any): string {
  return safe(text).replace(/[\u0591-\u05C7]/g, "")
}

function normalizeHebrewForSearch(text: any): string {
  return stripHebrewMarks(text)
    .replaceAll("־", " ")
    .replaceAll("״", "")
    .replaceAll("׳", "")
    .replace(/[ך]/g, "כ")
    .replace(/[ם]/g, "מ")
    .replace(/[ן]/g, "נ")
    .replace(/[ף]/g, "פ")
    .replace(/[ץ]/g, "צ")
    .replace(/\s+/g, " ")
    .trim()
}

function truncate(value: any, max = 650): string {
  const text = safe(value).replace(/\s+/g, " ").trim()
  return text.length > max ? text.slice(0, max) + "…" : text
}

function toLine(row: Row) {
  const cleanContent = stripHtml(row.content)
  return {
    lineId: Number(row.lineId ?? row.id ?? 0),
    bookId: Number(row.bookId ?? 0),
    bookTitle: safe(row.bookTitle ?? row.title),
    heRef: row.heRef == null ? null : safe(row.heRef),
    lineIndex: Number(row.lineIndex ?? 0),
    cleanContent: truncate(cleanContent, 750),
    noNikudPreview: truncate(stripHebrewMarks(cleanContent), 220),
    rank: row.rank == null ? undefined : Number(row.rank)
  }
}

async function exists(path: string): Promise<boolean> {
  try { return await FileManager.exists(path) } catch { return false }
}

async function findDb(explicitPath?: string): Promise<string> {
  if (!SQLite) throw new Error("SQLite global is not available")
  if (!FileManager) throw new Error("FileManager global is not available")

  const candidates: string[] = []
  if (explicitPath) candidates.push(explicitPath)
  if (FileManager.isiCloudEnabled && FileManager.iCloudDocumentsDirectory) {
    candidates.push(joinPath(FileManager.iCloudDocumentsDirectory, "seforim.db"))
    candidates.push(joinPath(FileManager.iCloudDocumentsDirectory, "seforim.dp"))
  }
  if (FileManager.documentsDirectory) {
    candidates.push(joinPath(FileManager.documentsDirectory, "seforim.db"))
    candidates.push(joinPath(FileManager.documentsDirectory, "seforim.dp"))
  }
  if (FileManager.appGroupDocumentsDirectory) {
    candidates.push(joinPath(FileManager.appGroupDocumentsDirectory, "seforim.db"))
    candidates.push(joinPath(FileManager.appGroupDocumentsDirectory, "seforim.dp"))
  }

  for (const path of Array.from(new Set(candidates.filter(Boolean)))) {
    if (await exists(path)) return path
  }

  throw new Error("לא נמצא seforim.db / seforim.dp בתיקיות המסמכים של Scripting. העבר dbPath מפורש או שים את הקובץ ב־Documents.")
}

async function openDb(params: Params) {
  const dbPath = await findDb(params.dbPath)
  const db = SQLite.open(dbPath, {
    readonly: true,
    foreignKeysEnabled: false,
    journalMode: "default",
    busyMode: "immediateError",
    maximumReaderCount: 1,
    label: "otzaria-torah-tool"
  })
  return { db, dbPath }
}

async function closeDb(db: any) {
  try { if (db && typeof db.close === "function") await db.close() } catch {}
}

function hasFtsSyntax(query: string): boolean {
  return /\bAND\b|\bOR\b|\bNOT\b|["*()+\-:^]/.test(query)
}

function quoteFtsPhrase(query: string): string {
  return `"${query.replaceAll(`"`, `""`)}"`
}

function tokenParts(query: string): string[] {
  return normalizeHebrewForSearch(query).split(/\s+/).map(t => t.trim()).filter(t => t.length > 1)
}

function buildAttempts(query: string) {
  const raw = safe(query).trim()
  const normalized = normalizeHebrewForSearch(raw)
  const tokens = tokenParts(raw)
  const attempts: { label: string; match: string }[] = []
  if (raw) attempts.push({ label: "raw", match: raw })
  if (normalized && normalized !== raw) attempts.push({ label: "normalized", match: normalized })
  if (!hasFtsSyntax(raw) && tokens.length > 1) {
    attempts.push({ label: "and", match: tokens.join(" AND ") })
    attempts.push({ label: "phrase", match: quoteFtsPhrase(tokens.join(" ")) })
  }
  if (!hasFtsSyntax(raw) && tokens.length === 1 && tokens[0].length >= 3) {
    attempts.push({ label: "prefix", match: `${tokens[0]}*` })
  }
  const seen = new Set<string>()
  return attempts.filter(a => a.match && !seen.has(a.match) && seen.add(a.match)).slice(0, 5)
}

async function searchAction(db: any, params: Params) {
  const query = safe(params.query).trim()
  if (!query) throw new Error("חסר query לפעולת search")
  const limit = clampInt(params.limit, 10, 1, 40)
  const heRefOnly = params.heRefOnly !== false
  const attempts = buildAttempts(query)
  const seen = new Set<number>()
  const results: any[] = []
  const attemptSummaries: any[] = []

  for (const attempt of attempts) {
    try {
      const rows = await db.fetchAll([
        "SELECT line.id AS lineId, line.heRef, line.content, line.lineIndex,",
        "       book.id AS bookId, book.title AS bookTitle, line_fts.rank AS rank",
        "FROM line_fts",
        "JOIN line ON line.id = line_fts.rowid",
        "JOIN book ON book.id = line.bookId",
        "WHERE line_fts MATCH ?",
        heRefOnly ? "  AND line.heRef IS NOT NULL" : "",
        "ORDER BY line_fts.rank",
        `LIMIT ${Math.max(limit * 2, limit)}`
      ].filter(Boolean).join("\n"), [attempt.match])

      attemptSummaries.push({ ...attempt, returned: rows.length })
      for (const row of rows) {
        const lineId = Number(row.lineId)
        if (seen.has(lineId)) continue
        seen.add(lineId)
        results.push(toLine(row))
        if (results.length >= limit) break
      }
      if (results.length >= limit) break
    } catch (error) {
      attemptSummaries.push({ ...attempt, returned: 0, error: safe(error) })
    }
  }
  return { query, limit, attempts: attemptSummaries, resultCount: results.length, results }
}

async function readRefAction(db: any, params: Params) {
  const ref = safe(params.ref || params.query).trim()
  if (!ref) throw new Error("חסר ref לפעולת read_ref")
  const limit = clampInt(params.limit, 20, 1, 80)
  const rows = await db.fetchAll([
    "SELECT line.id AS lineId, line.heRef, line.content, line.lineIndex,",
    "       book.id AS bookId, book.title AS bookTitle",
    "FROM line",
    "JOIN book ON book.id = line.bookId",
    "WHERE line.heRef = ? OR line.heRef LIKE ?",
    "ORDER BY book.title, line.lineIndex",
    `LIMIT ${limit}`
  ].join("\n"), [ref, ref + "%"])
  return { ref, resultCount: rows.length, results: rows.map(toLine) }
}

async function findLineById(db: any, lineId: number) {
  return await db.fetchOne([
    "SELECT line.id AS lineId, line.bookId, line.lineIndex, line.heRef, line.content, book.title AS bookTitle",
    "FROM line JOIN book ON book.id = line.bookId",
    "WHERE line.id = ?",
    "LIMIT 1"
  ].join("\n"), [lineId])
}

async function readContextAction(db: any, params: Params) {
  const radius = clampInt(params.radius, 3, 0, 20)
  let bookId = Number(params.bookId)
  let lineIndex = Number(params.lineIndex)
  let base: any = null

  if (params.lineId != null) {
    base = await findLineById(db, Number(params.lineId))
    if (!base) throw new Error(`לא נמצאה שורה lineId=${params.lineId}`)
    bookId = Number(base.bookId)
    lineIndex = Number(base.lineIndex)
  }
  if (!Number.isFinite(bookId) || !Number.isFinite(lineIndex)) {
    throw new Error("read_context דורש lineId או bookId + lineIndex")
  }
  const fromIndex = Math.max(0, lineIndex - radius)
  const toIndex = lineIndex + radius
  const rows = await db.fetchAll([
    "SELECT line.id AS lineId, line.heRef, line.content, line.lineIndex,",
    "       book.id AS bookId, book.title AS bookTitle",
    "FROM line",
    "JOIN book ON book.id = line.bookId",
    "WHERE line.bookId = ? AND line.lineIndex BETWEEN ? AND ?",
    "ORDER BY line.lineIndex"
  ].join("\n"), [bookId, fromIndex, toIndex])
  return { base: base ? toLine(base) : null, bookId, lineIndex, radius, resultCount: rows.length, results: rows.map(toLine) }
}

async function findBookAction(db: any, params: Params) {
  const query = safe(params.query).trim()
  if (!query) throw new Error("חסר query לפעולת find_book")
  const limit = clampInt(params.limit, 20, 1, 60)
  const rows = await db.fetchAll([
    "SELECT DISTINCT book.id, book.title, book.heShortDesc, book.totalLines,",
    "       category.title AS categoryTitle, source.name AS sourceName, book_acronym.term AS matchedAcronym",
    "FROM book",
    "JOIN category ON category.id = book.categoryId",
    "JOIN source ON source.id = book.sourceId",
    "LEFT JOIN book_acronym ON book_acronym.bookId = book.id",
    "WHERE book.title LIKE '%' || ? || '%' OR book_acronym.term LIKE '%' || ? || '%'",
    "ORDER BY book.title",
    `LIMIT ${limit}`
  ].join("\n"), [query, query])
  return {
    query,
    resultCount: rows.length,
    results: rows.map((r: Row) => ({
      bookId: Number(r.id), title: safe(r.title), categoryTitle: safe(r.categoryTitle), sourceName: safe(r.sourceName), totalLines: Number(r.totalLines || 0), matchedAcronym: safe(r.matchedAcronym), description: truncate(r.heShortDesc, 250)
    }))
  }
}

async function getLinksAction(db: any, params: Params) {
  const lineId = Number(params.lineId)
  if (!Number.isFinite(lineId) || lineId <= 0) throw new Error("get_links דורש lineId")
  const direction = safe(params.direction || "both")
  const connectionType = safe(params.connectionType).toUpperCase()
  const limit = clampInt(params.limit, 20, 1, 80)
  const allLinks: any[] = []

  async function queryLinks(dir: "incoming" | "outgoing") {
    const condition = dir === "incoming" ? "link.targetLineId = ?" : "link.sourceLineId = ?"
    const typeFilter = connectionType ? "AND ct.name = ?" : ""
    const args = connectionType ? [lineId, connectionType] : [lineId]
    const rows = await db.fetchAll([
      "SELECT link.id AS linkId, ct.name AS connectionType,",
      "       sourceBook.title AS sourceBookTitle, sourceLine.id AS sourceLineId, sourceLine.heRef AS sourceHeRef, sourceLine.content AS sourceContent,",
      "       targetBook.title AS targetBookTitle, targetLine.id AS targetLineId, targetLine.heRef AS targetHeRef, targetLine.content AS targetContent",
      "FROM link",
      "JOIN connection_type ct ON ct.id = link.connectionTypeId",
      "JOIN book sourceBook ON sourceBook.id = link.sourceBookId",
      "JOIN book targetBook ON targetBook.id = link.targetBookId",
      "JOIN line sourceLine ON sourceLine.id = link.sourceLineId",
      "JOIN line targetLine ON targetLine.id = link.targetLineId",
      `WHERE ${condition}`,
      typeFilter,
      "ORDER BY ct.name, sourceBook.title, targetBook.title",
      `LIMIT ${limit}`
    ].filter(Boolean).join("\n"), args)
    for (const r of rows) {
      allLinks.push({
        direction: dir,
        linkId: Number(r.linkId),
        connectionType: safe(r.connectionType),
        source: { lineId: Number(r.sourceLineId), bookTitle: safe(r.sourceBookTitle), heRef: r.sourceHeRef == null ? null : safe(r.sourceHeRef), text: truncate(stripHtml(r.sourceContent), 500) },
        target: { lineId: Number(r.targetLineId), bookTitle: safe(r.targetBookTitle), heRef: r.targetHeRef == null ? null : safe(r.targetHeRef), text: truncate(stripHtml(r.targetContent), 500) }
      })
    }
  }

  if (direction === "incoming" || direction === "both") await queryLinks("incoming")
  if (direction === "outgoing" || direction === "both") await queryLinks("outgoing")
  return { lineId, direction, connectionType: connectionType || null, resultCount: allLinks.length, results: allLinks.slice(0, limit * 2) }
}

async function getTocAction(db: any, params: Params) {
  let bookId = Number(params.bookId)
  const limit = clampInt(params.limit, 80, 1, 300)

  if ((!Number.isFinite(bookId) || bookId <= 0) && params.query) {
    const found = await db.fetchOne("SELECT id FROM book WHERE title LIKE '%' || ? || '%' ORDER BY title LIMIT 1", [params.query])
    if (found) bookId = Number(found.id)
  }
  if (!Number.isFinite(bookId) || bookId <= 0) throw new Error("get_toc דורש bookId או query של שם ספר")

  const rows = await db.fetchAll([
    "SELECT tocEntry.id, tocEntry.parentId, tocEntry.level, tocEntry.lineId, tocEntry.lineIndex, tocEntry.hasChildren, tocText.text, book.title AS bookTitle",
    "FROM tocEntry",
    "JOIN tocText ON tocText.id = tocEntry.textId",
    "JOIN book ON book.id = tocEntry.bookId",
    "WHERE tocEntry.bookId = ?",
    "ORDER BY COALESCE(tocEntry.lineIndex, 999999999), tocEntry.level, tocEntry.id",
    `LIMIT ${limit}`
  ].join("\n"), [bookId])
  return { bookId, bookTitle: rows[0] ? safe(rows[0].bookTitle) : "", resultCount: rows.length, results: rows.map((r: Row) => ({ id: Number(r.id), parentId: r.parentId == null ? null : Number(r.parentId), level: Number(r.level), lineId: r.lineId == null ? null : Number(r.lineId), lineIndex: r.lineIndex == null ? null : Number(r.lineIndex), hasChildren: Number(r.hasChildren) === 1, text: safe(r.text) })) }
}

async function execute(params: Params) {
  let db: any = null
  try {
    if (!params || !params.action) return { success: false, message: "חסר action. אפשרויות: search, read_ref, read_context, find_book, get_links, get_toc." }
    const { db: opened, dbPath } = await openDb(params)
    db = opened
    const action = safe(params.action)
    let result: any

    if (action === "search") result = await searchAction(db, params)
    else if (action === "read_ref") result = await readRefAction(db, params)
    else if (action === "read_context") result = await readContextAction(db, params)
    else if (action === "find_book") result = await findBookAction(db, params)
    else if (action === "get_links") result = await getLinksAction(db, params)
    else if (action === "get_toc") result = await getTocAction(db, params)
    else throw new Error(`Unknown action: ${action}`)

    return {
      success: true,
      message: "Otzaria Torah tool result\n\n" + JSON.stringify({ tool: "otzaria_torah", action, dbPath, result }, null, 2)
    }
  } catch (error) {
    return { success: false, message: "otzaria_torah failed: " + safe(error) }
  } finally {
    await closeDb(db)
  }
}

AssistantTool.registerExecuteTool(execute)
