---
name: otzaria-torah-assistant
description: Use this Scripting skill whenever the user asks Torah/Jewish-text questions, wants sources from a local Otzaria/Seforim SQLite database, asks to find seforim, read a reference, inspect commentaries/targum/sources/parallel references, or wants a source-grounded Hebrew answer. The skill uses a separately installed Scripting AssistantTool named `otzaria_torah` over `seforim.db` by default, while keeping a future plan for a remote Tantivy/MCP provider.
metadata:
  display_name: "Otzaria Torah Assistant"
  intent_patterns: "אוצריא, ספרים, מקור, מקורות, חיפוש תורני, מפרשים, תרגום, שאלה תורנית, פסוק, גמרא, הלכה, תנך, מדרש, שו״ע, רמב״ם, Seforim, Otzaria"
---

# Otzaria Torah Assistant

Use this skill to answer Torah/Jewish-text questions with sources from the user's local `seforim.db` database.

## Core rule

Do not answer substantive Torah questions from memory alone. First use the local Otzaria tool to find/read sources, then answer from the sources found. If no relevant source is found, say so and adjust the search terms.

## Important installation note

The Skill folder can teach the Assistant how to behave, but Scripting AssistantTools must be installed as separate script projects whose root contains `assistant_tool.json` and `assistant_tool.tsx`. This is why nested files under `scripting-skills/.../tools/...` are not callable directly.

Install the bundled standalone tool first:

```text
scripts/install-assistant-tool.tsx
```

After installation, use the AssistantTool id:

```text
otzaria_torah
```

If `call_assistant_tool` says `Unknown Assistant Tool`, the standalone tool is not installed or the Assistant conversation needs to be restarted.

## Main AssistantTool

Use `otzaria_torah` with an `action` parameter:

| Action | Purpose |
|---|---|
| `search` | Search text lines using local SQLite FTS5. |
| `read_ref` | Read exact Hebrew references such as `בראשית א, א`, `שמות כ, ב`, or prefix refs like `בראשית א`. |
| `read_context` | Read nearby lines around a selected line by `lineId` or `bookId + lineIndex`. |
| `find_book` | Find books by title or acronym (`book.title` + `book_acronym.term`). |
| `get_links` | Get COMMENTARY, SOURCE, TARGUM, REFERENCE, or OTHER links around a line. |
| `get_toc` | Get a book's table of contents from `tocEntry + tocText`. |

Example tool calls:

```json
{ "action": "search", "query": "שבת חולה", "limit": 8 }
```

```json
{ "action": "read_ref", "ref": "בראשית א, א", "limit": 20 }
```

```json
{ "action": "get_links", "lineId": 12345, "direction": "incoming", "connectionType": "COMMENTARY", "limit": 20 }
```

## Database assumptions

Default database path candidates:

1. `FileManager.iCloudDocumentsDirectory + "/seforim.db"`
2. `FileManager.iCloudDocumentsDirectory + "/seforim.dp"`
3. `FileManager.documentsDirectory + "/seforim.db"`
4. `FileManager.documentsDirectory + "/seforim.dp"`

The database schema is summarized in `references/database-schema.md`.

## Decision workflow

### If the user gives an exact reference

Examples: `בראשית א, א`, `שמות כ, ב`, `דברים ו, ה`, `שבת לא`, `ברכות ב`.

1. Call `otzaria_torah` with `{ "action": "read_ref", "ref": "..." }` first.
2. If the result is too narrow or too broad, call `read_context` around the selected line.
3. For commentaries, call `get_links` with `direction: "incoming"` and `connectionType: "COMMENTARY"`.
4. For targum, call `get_links` with `direction: "outgoing"` and `connectionType: "TARGUM"`.

### If the user asks a general Torah question

1. Reformulate the question into ancient Hebrew / rabbinic Hebrew / Aramaic terms.
2. Call `otzaria_torah` with `{ "action": "search", "query": "...", "limit": 5-12 }`.
3. If results are weak, retry with fewer words, phrase form, classical terms, Hebrew/Aramaic alternatives.
4. Read context around promising results.
5. Use `get_links` when commentaries, sources, targum, or parallels are needed.
6. Answer only from the sources actually found.

### If the user asks for a book

1. Call `otzaria_torah` with `{ "action": "find_book", "query": "..." }`.
2. If a book is found and the user wants structure, call `get_toc`.
3. For a section, use `lineId` / `lineIndex` from TOC and read context.

## Search behavior notes

SQLite FTS5 is the default local provider. It works fully offline, but it is not identical to Otzaria's Rust/Tantivy search engine. The local FTS index does not fully normalize Hebrew nikud/taamim. For exact Tanach verses, prefer `read_ref` by `heRef` over content search.

Prefer concise query terms:

- Good: `שבת חולה`
- Good: `אמר רב`
- Good: `ואהבת`
- Good: `בראשית ברא`
- Less ideal: long modern Hebrew sentence

## Source-answer format

When answering, use this pattern:

1. Short conclusion.
2. Sources section with each source as `ספר — מראה מקום`.
3. Explanation based on the sources.
4. If evidence is partial, say it is partial.

Never invent a `heRef`, book title, commentary, or connection type.

## UI workflow display

For substantial answers, render a workflow card using `scripts/otzaria-workflow-view.tsx`. Keep UI data compact: source text snippets should usually be under 500 characters.

## Future Tantivy/MCP provider

Search can later be routed to a remote Tantivy/MCP HTTP endpoint while reading/context/links still use local SQLite. See `references/tantivy-provider-plan.md`.
