type Row = Record<string, any>

const FileManagerAPI = (globalThis as any).FileManager

function joinPath(base: string, name: string): string {
  return String(base || "").replace(/\/+$/, "") + "/" + String(name || "").replace(/^\/+/, "")
}

const SQLiteAPI = (globalThis as any).SQLite
const AssistantToolAPI = (globalThis as any).AssistantTool

export type DbParams = {
  dbPath?: string
}

export type SearchProvider = "sqlite" | "tantivy"

export type SearchParams = DbParams & {
  query: string
  limit?: number
  heRefOnly?: boolean
  searchProvider?: SearchProvider
  tantivyEndpoint?: string
}

export type SourceLine = {
  lineId: number
  bookId: number
  bookTitle: string
  heRef: string | null
  lineIndex: number
  content: string
  cleanContent: string
  noNikudContent: string
  rank?: number
}

export type LinkDirection = "incoming" | "outgoing" | "both"
export type ConnectionType = "OTHER" | "COMMENTARY" | "SOURCE" | "TARGUM" | "REFERENCE"

export function report(message: string, id?: string) {
  try {
    if (AssistantToolAPI && typeof AssistantToolAPI.report === "function") {
      AssistantToolAPI.report(message, id)
    }
  } catch {}
}

export function clampInt(value: any, fallback: number, min: number, max: number): number {
  const n = Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.max(min, Math.min(max, Math.floor(n)))
}

export function safe(value: any): string {
  if (value == null) return ""
  try { return String(value) } catch { return "[unprintable]" }
}

export function truncate(value: any, max = 700): string {
  const text = safe(value).replaceAll("\r", " ").replaceAll("\n", " ").replaceAll("\t", " ").replace(/\s+/g, " ").trim()
  return text.length > max ? text.slice(0, max) + "…" : text
}

export function decodeHtmlEntities(text: string): string {
  return safe(text)
    .replaceAll("&nbsp;", " ")
    .replaceAll("&quot;", `"`)
    .replaceAll("&apos;", `'`)
    .replaceAll("&lt;", "<")
    .replaceAll("&gt;", ">")
    .replaceAll("&amp;", "&")
}

export function stripHtml(text: any): string {
  return decodeHtmlEntities(safe(text)
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n")
    .replace(/<\/h[1-6]>/gi, "\n")
    .replace(/<[^>]*>/g, " ")
  ).replace(/\s+/g, " ").trim()
}

export function stripHebrewMarks(text: any): string {
  return safe(text).replace(/[\u0591-\u05C7]/g, "")
}

export function normalizeHebrewForSearch(text: any): string {
  return stripHebrewMarks(text)
    .replaceAll("־", " ")
    .replaceAll("״", "")
    .replaceAll("׳", "")
    .replace(/[\u05DA]/g, "כ")
    .replace(/[\u05DD]/g, "מ")
    .replace(/[\u05DF]/g, "נ")
    .replace(/[\u05E3]/g, "פ")
    .replace(/[\u05E5]/g, "צ")
    .replace(/\s+/g, " ")
    .trim()
}

export function toLine(row: Row): SourceLine {
  const cleanContent = stripHtml(row.content)
  return {
    lineId: Number(row.lineId ?? row.id ?? 0),
    bookId: Number(row.bookId ?? 0),
    bookTitle: safe(row.bookTitle ?? row.title),
    heRef: row.heRef == null ? null : safe(row.heRef),
    lineIndex: Number(row.lineIndex ?? 0),
    content: safe(row.content),
    cleanContent,
    noNikudContent: stripHebrewMarks(cleanContent),
    rank: row.rank == null ? undefined : Number(row.rank)
  }
}

export function formatToolJson(title: string, payload: any): string {
  return `${title}\n\n` + JSON.stringify(payload, null, 2)
}

async function exists(path: string): Promise<boolean> {
  try {
    if (!FileManagerAPI) return false
    if (typeof FileManagerAPI.exists === "function") return await FileManagerAPI.exists(path)
    if (typeof FileManagerAPI.existsSync === "function") return FileManagerAPI.existsSync(path)
    return false
  } catch { return false }
}

async function ensureICloudDownloaded(path: string) {
  try {
    if (!FileManagerAPI || typeof FileManagerAPI.isFileStoredIniCloud !== "function") return
    if (!FileManagerAPI.isFileStoredIniCloud(path)) return
    if (typeof FileManagerAPI.isiCloudFileDownloaded === "function" && FileManagerAPI.isiCloudFileDownloaded(path)) return
    if (typeof FileManagerAPI.downloadFileFromiCloud === "function") {
      report("מוריד את קובץ מסד הנתונים מ־iCloud...", "db-download")
      await FileManagerAPI.downloadFileFromiCloud(path)
    }
  } catch {}
}

export async function findDatabasePath(explicitPath?: string): Promise<string> {
  if (!FileManagerAPI) throw new Error("FileManager global is not available.")
  if (!SQLiteAPI) throw new Error("SQLite global is not available.")

  const candidates: string[] = []
  if (explicitPath) candidates.push(explicitPath)

  try {
    if (FileManagerAPI.isiCloudEnabled && FileManagerAPI.iCloudDocumentsDirectory) {
      candidates.push(joinPath(FileManagerAPI.iCloudDocumentsDirectory, "seforim.db"))
      candidates.push(joinPath(FileManagerAPI.iCloudDocumentsDirectory, "seforim.dp"))
    }
  } catch {}

  try {
    if (FileManagerAPI.documentsDirectory) {
      candidates.push(joinPath(FileManagerAPI.documentsDirectory, "seforim.db"))
      candidates.push(joinPath(FileManagerAPI.documentsDirectory, "seforim.dp"))
    }
  } catch {}

  try {
    if (FileManagerAPI.appGroupDocumentsDirectory) {
      candidates.push(joinPath(FileManagerAPI.appGroupDocumentsDirectory, "seforim.db"))
      candidates.push(joinPath(FileManagerAPI.appGroupDocumentsDirectory, "seforim.dp"))
    }
  } catch {}

  for (const p of Array.from(new Set(candidates.filter(Boolean)))) {
    if (await exists(p)) {
      await ensureICloudDownloaded(p)
      return p
    }
  }

  throw new Error(
    "לא נמצא seforim.db / seforim.dp. שים את הקובץ בתיקיית Documents של Scripting או העבר dbPath מפורש לכלי."
  )
}

export async function openDatabase(params: DbParams = {}): Promise<{ db: any; dbPath: string }> {
  const dbPath = await findDatabasePath(params.dbPath)
  const db = SQLiteAPI.open(dbPath, {
    readonly: true,
    foreignKeysEnabled: false,
    journalMode: "default",
    busyMode: "immediateError",
    maximumReaderCount: 1,
    label: "otzaria-torah-assistant"
  })
  return { db, dbPath }
}

export async function closeDatabase(db: any) {
  try {
    if (db && typeof db.close === "function") await db.close()
    else if (db && typeof db.dispose === "function") db.dispose()
  } catch {}
}

export async function all(db: any, sql: string, args?: any): Promise<Row[]> {
  if (args === undefined) return await db.fetchAll(sql)
  return await db.fetchAll(sql, args)
}

export async function one(db: any, sql: string, args?: any): Promise<Row | null> {
  try {
    if (args === undefined) return await db.fetchOne(sql)
    return await db.fetchOne(sql, args)
  } catch { return null }
}

function hasFtsSyntax(query: string): boolean {
  return /\bAND\b|\bOR\b|\bNOT\b|["*()+\-:^]/.test(query)
}

function quoteFtsPhrase(query: string): string {
  return `"${query.replaceAll(`"`, `""`)}"`
}

function tokenParts(query: string): string[] {
  return normalizeHebrewForSearch(query)
    .split(/\s+/)
    .map(t => t.trim())
    .filter(t => t.length > 1)
}

export function buildFtsAttempts(query: string): { label: string; match: string }[] {
  const raw = safe(query).trim()
  const normalized = normalizeHebrewForSearch(raw)
  const tokens = tokenParts(raw)
  const attempts: { label: string; match: string }[] = []

  if (raw) attempts.push({ label: "raw", match: raw })
  if (normalized && normalized !== raw) attempts.push({ label: "normalized", match: normalized })

  if (!hasFtsSyntax(raw) && tokens.length > 1) {
    attempts.push({ label: "and", match: tokens.join(" AND ") })
    attempts.push({ label: "phrase", match: quoteFtsPhrase(tokens.join(" ")) })
  }

  if (!hasFtsSyntax(raw) && tokens.length === 1 && tokens[0].length >= 3) {
    attempts.push({ label: "prefix", match: `${tokens[0]}*` })
  }

  const seen = new Set<string>()
  return attempts.filter(a => {
    if (!a.match || seen.has(a.match)) return false
    seen.add(a.match)
    return true
  }).slice(0, 5)
}

export async function sqliteSearch(params: SearchParams): Promise<{
  provider: "sqlite"
  dbPath: string
  attempts: { label: string; match: string; returned: number; error?: string }[]
  results: SourceLine[]
}> {
  const limit = clampInt(params.limit, 10, 1, 40)
  const heRefOnly = params.heRefOnly !== false
  const { db, dbPath } = await openDatabase(params)
  const results: SourceLine[] = []
  const seen = new Set<number>()
  const attemptReports: { label: string; match: string; returned: number; error?: string }[] = []

  try {
    const attempts = buildFtsAttempts(params.query)
    for (const attempt of attempts) {
      if (results.length >= limit) break
      report(`מחפש: ${attempt.match}`, `search-${attempt.label}`)
      const remaining = Math.max(limit - results.length, 1)
      const sql = [
        "SELECT",
        "  line.id AS lineId,",
        "  line.heRef AS heRef,",
        "  line.content AS content,",
        "  line.lineIndex AS lineIndex,",
        "  book.id AS bookId,",
        "  book.title AS bookTitle,",
        "  line_fts.rank AS rank",
        "FROM line_fts",
        "JOIN line ON line.id = line_fts.rowid",
        "JOIN book ON book.id = line.bookId",
        "WHERE line_fts MATCH ?",
        heRefOnly ? "  AND line.heRef IS NOT NULL" : "",
        "ORDER BY line_fts.rank",
        `LIMIT ${remaining}`
      ].filter(Boolean).join("\n")

      try {
        const rows = await all(db, sql, [attempt.match])
        attemptReports.push({ label: attempt.label, match: attempt.match, returned: rows.length })
        for (const row of rows) {
          const line = toLine(row)
          if (!line.lineId || seen.has(line.lineId)) continue
          seen.add(line.lineId)
          results.push(line)
        }
      } catch (error) {
        attemptReports.push({ label: attempt.label, match: attempt.match, returned: 0, error: String(error) })
      }
    }

    return { provider: "sqlite", dbPath, attempts: attemptReports, results }
  } finally {
    await closeDatabase(db)
  }
}

export async function remoteTantivySearch(params: SearchParams): Promise<any> {
  if (!params.tantivyEndpoint) throw new Error("tantivyEndpoint חסר.")
  const limit = clampInt(params.limit, 10, 1, 40)
  report("מחפש דרך Tantivy/MCP endpoint...", "tantivy")
  const response = await fetch(params.tantivyEndpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query: params.query, num_results: limit, limit })
  })
  const contentType = response.headers.get("content-type") || ""
  if (contentType.includes("application/json")) return await response.json()
  return { text: await response.text() }
}

export function compactLines(lines: SourceLine[], maxText = 700) {
  return lines.map(line => ({
    lineId: line.lineId,
    bookId: line.bookId,
    bookTitle: line.bookTitle,
    heRef: line.heRef,
    lineIndex: line.lineIndex,
    text: truncate(line.cleanContent, maxText),
    rank: line.rank
  }))
}
