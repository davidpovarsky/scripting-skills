# AssistantTool installation note

Scripting AssistantTools are not automatically callable just because `assistant_tool.json` exists inside a Skill subfolder.

The Scripting documentation says AssistantTools are created from two files:

- `assistant_tool.json`
- `assistant_tool.tsx`

The JSON declares metadata, parameters, and routing id; the TSX file registers execution logic with `AssistantTool.registerExecuteTool` or approval variants.

In practice, the Assistant tool registry scans installed script projects, not arbitrary nested skill resource folders. Therefore this package includes:

```text
assistant-tool-otzaria/
```

Install this folder as a Scripting script project. Its tool id is:

```text
otzaria_torah
```

The old nested `tools/*` folders are kept as modular source/reference, but the reliable callable tool is the standalone all-in-one `otzaria_torah` tool.
