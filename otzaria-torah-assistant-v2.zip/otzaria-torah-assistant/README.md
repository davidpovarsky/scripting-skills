# Otzaria Torah Assistant for Scripting

This package contains a Scripting Skill plus a separately installable AssistantTool for searching and reading the local Otzaria/Seforim `seforim.db` database.

## Why there are two parts

A Scripting Skill gives the Assistant reusable instructions and UI/reference files.

A Scripting AssistantTool must be installed as a script project whose root contains:

```text
assistant_tool.json
assistant_tool.tsx
```

Therefore the callable tool is bundled separately in:

```text
assistant-tool-otzaria/
```

The tool id is:

```text
otzaria_torah
```

## Install

1. Copy/extract the whole folder to:

```text
Scripting/Documents/scripting-skills/otzaria-torah-assistant
```

2. Run:

```text
scripts/install-assistant-tool.tsx
```

This copies the standalone AssistantTool to:

```text
FileManager.scriptsDirectory/otzaria_torah
```

3. Restart/open a new Assistant conversation if the tool does not appear immediately.

4. Test the database directly:

```text
scripts/test-local-search.tsx
```

5. Test in Agent chat by asking it to call AssistantTool `otzaria_torah`:

```json
{ "action": "search", "query": "שבת חולה", "limit": 5 }
```

## Main tool actions

`otzaria_torah` supports:

- `search`
- `read_ref`
- `read_context`
- `find_book`
- `get_links`
- `get_toc`

## Expected database location

The tool looks for:

```text
Scripting Documents/seforim.db
Scripting Documents/seforim.dp
```

It checks both iCloud Documents and local Documents when available.

## Notes

- The direct test script proves the SQLite DB and FTS query work.
- If `call_assistant_tool` returns `Unknown Assistant Tool`, the standalone AssistantTool was not installed into the scripts directory or the conversation/tool registry has not refreshed.
