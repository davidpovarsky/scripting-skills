import { List, Section, Text } from "scripting"

type Result = {
  bookTitle?: string
  heRef?: string | null
  text?: string
  lineId?: number
  rank?: number
}

type Config = {
  query?: string
  provider?: string
  results?: Result[]
}

function safe(value: any): string {
  if (value == null) return ""
  try { return String(value) } catch { return "" }
}

function clip(value: any, max = 360): string {
  const text = safe(value).replace(/\s+/g, " ").trim()
  return text.length > max ? text.slice(0, max) + "…" : text
}

export default function SearchResultsView({ config }: { config: Config }) {
  const results = config?.results || []
  return (
    <List navigationTitle="Otzaria Search" navigationBarTitleDisplayMode="inline" listSectionSpacing="compact">
      <Section header={<Text textCase={null}>חיפוש</Text>}>
        <Text>{safe(config?.query)}</Text>
        <Text>provider: {safe(config?.provider || "sqlite")}</Text>
        <Text>results: {results.length}</Text>
      </Section>
      <Section header={<Text textCase={null}>תוצאות</Text>}>
        {results.map((r, i) => (
          <Text>
            {i + 1}. {[r.bookTitle, r.heRef].filter(Boolean).join(" — ")}
            {r.lineId ? ` · lineId ${r.lineId}` : ""}
            {typeof r.rank === "number" ? ` · rank ${r.rank}` : ""}
            {r.text ? `\n${clip(r.text)}` : ""}
          </Text>
        ))}
      </Section>
    </List>
  )
}
