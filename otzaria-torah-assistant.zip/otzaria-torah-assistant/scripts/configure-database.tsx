import { Script } from "scripting"

const DocumentPickerAPI = (globalThis as any).DocumentPicker
const FileManagerAPI = (globalThis as any).FileManager
const PathAPI = (globalThis as any).Path

function log(msg: string) { console.log(msg) }

async function run() {
  if (!DocumentPickerAPI) throw new Error("DocumentPicker is not available")
  log("בחר את seforim.db / seforim.dp מתוך Files...")
  const selected = await DocumentPickerAPI.pickFiles({
    allowsMultipleSelection: false,
    shouldShowFileExtensions: true
  })
  if (!selected || !selected.length) {
    log("לא נבחר קובץ.")
    Script.exit()
    return
  }
  const src = selected[0]
  const targetName = src.endsWith(".dp") ? "seforim.dp" : "seforim.db"
  const dest = PathAPI.join(FileManagerAPI.documentsDirectory, targetName)
  log(`נבחר: ${src}`)
  log(`מעתיק אל: ${dest}`)
  if (typeof FileManagerAPI.copy === "function") await FileManagerAPI.copy(src, dest)
  else if (typeof FileManagerAPI.copySync === "function") FileManagerAPI.copySync(src, dest)
  else log("אין copy API זמין; אם הקובץ כבר בתיקיית Documents של Scripting אין צורך להעתיק.")
  log("הסתיים.")
  try { DocumentPickerAPI.stopAcessingSecurityScopedResources() } catch {}
  Script.exit()
}

run().catch(e => {
  log(String(e))
  Script.exit()
})
