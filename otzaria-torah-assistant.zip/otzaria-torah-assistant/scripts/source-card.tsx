import { List, Section, Text } from "scripting"

type Source = {
  bookTitle?: string
  heRef?: string | null
  text?: string
  lineId?: number
  bookId?: number
  lineIndex?: number
}

function safe(value: any): string {
  if (value == null) return ""
  try { return String(value) } catch { return "" }
}

function clip(value: any, max = 900): string {
  const text = safe(value).replace(/\s+/g, " ").trim()
  return text.length > max ? text.slice(0, max) + "…" : text
}

export default function SourceCard({ source }: { source: Source }) {
  const title = [source.bookTitle, source.heRef].filter(Boolean).join(" — ")
  return (
    <List navigationTitle="Source" navigationBarTitleDisplayMode="inline">
      <Section header={<Text textCase={null}>מקור</Text>}>
        <Text>{title || "מקור מאוצריא"}</Text>
        {source.lineId ? <Text>lineId: {source.lineId}</Text> : null}
        {source.bookId ? <Text>bookId: {source.bookId}</Text> : null}
        {typeof source.lineIndex === "number" ? <Text>lineIndex: {source.lineIndex}</Text> : null}
      </Section>
      <Section header={<Text textCase={null}>טקסט</Text>}>
        <Text>{clip(source.text)}</Text>
      </Section>
    </List>
  )
}
