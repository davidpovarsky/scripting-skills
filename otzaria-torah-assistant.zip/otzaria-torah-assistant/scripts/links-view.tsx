import { List, Section, Text } from "scripting"

type LinkItem = {
  direction?: string
  connectionType?: string
  source?: { bookTitle?: string; heRef?: string | null; text?: string; lineId?: number }
  target?: { bookTitle?: string; heRef?: string | null; text?: string; lineId?: number }
}

type Config = {
  lineId?: number
  links?: LinkItem[]
}

function safe(value: any): string {
  if (value == null) return ""
  try { return String(value) } catch { return "" }
}

function clip(value: any, max = 420): string {
  const text = safe(value).replace(/\s+/g, " ").trim()
  return text.length > max ? text.slice(0, max) + "…" : text
}

export default function LinksView({ config }: { config: Config }) {
  const links = config?.links || []
  return (
    <List navigationTitle="Otzaria Links" navigationBarTitleDisplayMode="inline" listSectionSpacing="compact">
      <Section header={<Text textCase={null}>קישורים</Text>}>
        <Text>lineId: {safe(config?.lineId)}</Text>
        <Text>count: {links.length}</Text>
      </Section>
      <Section header={<Text textCase={null}>פריטים</Text>}>
        {links.map((link, index) => (
          <Text>
            {index + 1}. {[link.connectionType, link.direction].filter(Boolean).join(" · ")}
            {link.source ? `\nfrom: ${[link.source.bookTitle, link.source.heRef].filter(Boolean).join(" — ")}` : ""}
            {link.target ? `\nto: ${[link.target.bookTitle, link.target.heRef].filter(Boolean).join(" — ")}` : ""}
            {link.target?.text ? `\n${clip(link.target.text)}` : ""}
          </Text>
        ))}
      </Section>
    </List>
  )
}
