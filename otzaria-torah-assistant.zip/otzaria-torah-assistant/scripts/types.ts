export type WorkflowState = "pending" | "running" | "complete" | "warning" | "failed"

export type WorkflowStep = {
  title: string
  detail?: string
  state?: WorkflowState
}

export type WorkflowSearch = {
  query: string
  provider?: "sqlite" | "tantivy" | string
  resultCount?: number
  attempts?: string[]
}

export type WorkflowSource = {
  bookTitle?: string
  heRef?: string | null
  text?: string
  lineId?: number
  bookId?: number
  lineIndex?: number
}

export type WorkflowLink = {
  connectionType?: string
  direction?: string
  sourceBookTitle?: string
  sourceHeRef?: string | null
  targetBookTitle?: string
  targetHeRef?: string | null
  text?: string
}

export type WorkflowConfig = {
  question?: string
  status?: WorkflowState
  steps?: WorkflowStep[]
  searches?: WorkflowSearch[]
  sources?: WorkflowSource[]
  links?: WorkflowLink[]
  answerSummary?: string
  notes?: string[]
}
