import { Script } from "scripting"

const SQLiteAPI = (globalThis as any).SQLite
const FileManagerAPI = (globalThis as any).FileManager
const PathAPI = (globalThis as any).Path

function log(msg: string) { console.log(msg) }
function stripHtml(s: any) { return String(s ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim() }

async function exists(path: string) {
  try { return await FileManagerAPI.exists(path) } catch { return false }
}

async function findDb() {
  const candidates = []
  if (FileManagerAPI.isiCloudEnabled) {
    candidates.push(PathAPI.join(FileManagerAPI.iCloudDocumentsDirectory, "seforim.db"))
    candidates.push(PathAPI.join(FileManagerAPI.iCloudDocumentsDirectory, "seforim.dp"))
  }
  candidates.push(PathAPI.join(FileManagerAPI.documentsDirectory, "seforim.db"))
  candidates.push(PathAPI.join(FileManagerAPI.documentsDirectory, "seforim.dp"))
  for (const p of candidates) if (await exists(p)) return p
  throw new Error("seforim.db not found")
}

async function run() {
  const dbPath = await findDb()
  log(`DB: ${dbPath}`)
  const db = SQLiteAPI.open(dbPath, {
    readonly: true,
    foreignKeysEnabled: false,
    journalMode: "default",
    busyMode: "immediateError",
    maximumReaderCount: 1,
    label: "otzaria-test-local-search"
  })

  const queries = ["בראשית", "שבת חולה", "אמר רב", "ואהבת"]
  for (const query of queries) {
    log(`\n=== ${query} ===`)
    const rows = await db.fetchAll([
      "SELECT line.id AS lineId, line.heRef, line.content, line.lineIndex, book.title AS bookTitle, line_fts.rank AS rank",
      "FROM line_fts",
      "JOIN line ON line.id = line_fts.rowid",
      "JOIN book ON book.id = line.bookId",
      "WHERE line_fts MATCH ? AND line.heRef IS NOT NULL",
      "ORDER BY line_fts.rank",
      "LIMIT 5"
    ].join("\n"), [query])
    for (const row of rows) {
      log(`${row.bookTitle} — ${row.heRef} · lineId=${row.lineId}`)
      log(stripHtml(row.content).slice(0, 280))
    }
  }

  try { if (typeof db.close === "function") await db.close() } catch {}
  Script.exit()
}

run().catch(e => {
  log(String(e))
  Script.exit()
})
