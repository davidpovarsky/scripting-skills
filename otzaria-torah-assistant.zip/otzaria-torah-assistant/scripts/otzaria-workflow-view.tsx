import { List, Section, Text } from "scripting"
import { WorkflowConfig, WorkflowStep, WorkflowSource, WorkflowSearch, WorkflowLink } from "./types"

function safe(value: any): string {
  if (value == null) return ""
  try { return String(value) } catch { return "" }
}

function clip(value: any, max = 460): string {
  const text = safe(value).replace(/\s+/g, " ").trim()
  return text.length > max ? text.slice(0, max) + "…" : text
}

function stateIcon(state?: string): string {
  switch (state) {
    case "complete": return "✓"
    case "running": return "…"
    case "warning": return "!"
    case "failed": return "×"
    default: return "·"
  }
}

function StepRow({ step, index }: { step: WorkflowStep; index: number }) {
  return (
    <Text>
      {stateIcon(step.state)} {index + 1}. {safe(step.title)}{step.detail ? `\n${clip(step.detail, 220)}` : ""}
    </Text>
  )
}

function SearchRow({ search }: { search: WorkflowSearch }) {
  const details = [
    search.provider ? `provider: ${search.provider}` : "",
    typeof search.resultCount === "number" ? `results: ${search.resultCount}` : "",
    search.attempts && search.attempts.length ? `attempts: ${search.attempts.join(" | ")}` : ""
  ].filter(Boolean).join(" · ")

  return <Text>🔎 {safe(search.query)}{details ? `\n${details}` : ""}</Text>
}

function SourceRow({ source, index }: { source: WorkflowSource; index: number }) {
  const title = [source.bookTitle, source.heRef].filter(Boolean).join(" — ")
  return (
    <Text>
      {index + 1}. {title || "מקור"}
      {source.lineId ? ` · lineId ${source.lineId}` : ""}
      {source.text ? `\n${clip(source.text)}` : ""}
    </Text>
  )
}

function LinkRow({ link, index }: { link: WorkflowLink; index: number }) {
  const title = [link.connectionType, link.direction].filter(Boolean).join(" · ")
  const source = [link.sourceBookTitle, link.sourceHeRef].filter(Boolean).join(" — ")
  const target = [link.targetBookTitle, link.targetHeRef].filter(Boolean).join(" — ")
  return (
    <Text>
      {index + 1}. {title || "קישור"}
      {source ? `\nfrom: ${source}` : ""}
      {target ? `\nto: ${target}` : ""}
      {link.text ? `\n${clip(link.text, 260)}` : ""}
    </Text>
  )
}

export default function OtzariaWorkflowView({ workflow }: { workflow: WorkflowConfig }) {
  const steps = workflow?.steps || []
  const searches = workflow?.searches || []
  const sources = workflow?.sources || []
  const links = workflow?.links || []
  const notes = workflow?.notes || []

  return (
    <List
      navigationTitle="Otzaria Workflow"
      navigationBarTitleDisplayMode="inline"
      listSectionSpacing="compact"
    >
      <Section header={<Text textCase={null}>שאלה</Text>}>
        <Text>{clip(workflow?.question || "תהליך חיפוש מקורות באוצריא", 360)}</Text>
        <Text>סטטוס: {safe(workflow?.status || "complete")}</Text>
      </Section>

      {steps.length ? (
        <Section header={<Text textCase={null}>תהליך עבודה</Text>}>
          {steps.map((step, index) => <StepRow step={step} index={index} />)}
        </Section>
      ) : null}

      {searches.length ? (
        <Section header={<Text textCase={null}>חיפושים</Text>}>
          {searches.map(search => <SearchRow search={search} />)}
        </Section>
      ) : null}

      {sources.length ? (
        <Section header={<Text textCase={null}>מקורות שנבחרו</Text>}>
          {sources.map((source, index) => <SourceRow source={source} index={index} />)}
        </Section>
      ) : null}

      {links.length ? (
        <Section header={<Text textCase={null}>מפרשים / תרגומים / קישורים</Text>}>
          {links.map((link, index) => <LinkRow link={link} index={index} />)}
        </Section>
      ) : null}

      {workflow?.answerSummary ? (
        <Section header={<Text textCase={null}>סיכום תשובה</Text>}>
          <Text>{clip(workflow.answerSummary, 900)}</Text>
        </Section>
      ) : null}

      {notes.length ? (
        <Section header={<Text textCase={null}>הערות</Text>}>
          {notes.map(note => <Text>{clip(note, 300)}</Text>)}
        </Section>
      ) : null}
    </List>
  )
}
