---
name: otzaria-torah-assistant
description: Use this Scripting skill whenever the user asks Torah/Jewish-text questions, wants sources from a local Otzaria/Seforim SQLite database, asks to find seforim, read a reference, inspect commentaries/targum/sources/parallel references, or wants a source-grounded Hebrew answer. The skill uses local Scripting AssistantTools over seforim.db by default and can later switch the search provider to a remote Tantivy/MCP endpoint.
metadata:
  display_name: "Otzaria Torah Assistant"
  intent_patterns: "אוצריא, ספרים, מקור, מקורות, חיפוש תורני, מפרשים, תרגום, שאלה תורנית, פסוק, גמרא, הלכה, תנך, מדרש, שו״ע, רמב״ם, Seforim, Otzaria"
---

# Otzaria Torah Assistant

Use this skill to answer Torah/Jewish-text questions with sources from the user's local `seforim.db` database.

## Core rule

Do not answer substantive Torah questions from memory alone. First use the local Otzaria tools to find/read sources, then answer from the sources found. If no relevant source is found, say so and adjust the search terms.

## Available tools

Use these AssistantTools when available:

| Tool | Purpose |
|---|---|
| `otzaria_search` | Search text lines using local SQLite FTS5, with optional future remote Tantivy provider. |
| `otzaria_read_ref` | Read exact Hebrew references such as `בראשית א, א`, `שמות כ, ב`, or prefix refs like `בראשית א`. |
| `otzaria_read_context` | Read nearby lines around a selected line by `lineId` or `bookId + lineIndex`. |
| `otzaria_find_book` | Find books by title or acronym (`book.title` + `book_acronym.term`). |
| `otzaria_get_links` | Get COMMENTARY, SOURCE, TARGUM, REFERENCE, or OTHER links around a line. |
| `otzaria_get_toc` | Get a book's table of contents from `tocEntry + tocText`. |

## Database assumptions

Default database path candidates:

1. `FileManager.iCloudDocumentsDirectory + "/seforim.db"`
2. `FileManager.iCloudDocumentsDirectory + "/seforim.dp"`
3. `FileManager.documentsDirectory + "/seforim.db"`
4. `FileManager.documentsDirectory + "/seforim.dp"`

The database schema is summarized in `references/database-schema.md`.

## Decision workflow

### If the user gives an exact reference

Examples: `בראשית א, א`, `שמות כ, ב`, `דברים ו, ה`, `שבת לא`, `ברכות ב`.

1. Call `otzaria_read_ref` first.
2. If the result is too narrow or too broad, call `otzaria_read_context` around the selected line.
3. For commentaries or related material, call `otzaria_get_links` with `direction: "incoming"` and `connectionType: "COMMENTARY"`.
4. For targum, call `otzaria_get_links` with `direction: "outgoing"` and `connectionType: "TARGUM"`.

### If the user asks a general Torah question

1. Reformulate the question into ancient Hebrew / rabbinic Hebrew / Aramaic terms.
2. Call `otzaria_search` with 5-12 results.
3. If results are weak, retry with:
   - fewer words
   - phrase form
   - classical terms instead of modern terms
   - Hebrew/Aramaic alternatives
4. Read context around promising results with `otzaria_read_context`.
5. Use `otzaria_get_links` when commentaries, sources, targum, or parallels are needed.
6. Answer only from the sources actually found.

### If the user asks for a book

1. Call `otzaria_find_book`.
2. If a book is found and the user wants structure, call `otzaria_get_toc`.
3. For a section, use `lineId` / `lineIndex` from TOC and read context.

## Search behavior notes

SQLite FTS5 is the default local provider. It is reliable and works fully offline, but it is not identical to Otzaria's Rust/Tantivy search engine. The local FTS index does not fully normalize Hebrew nikud/taamim. For exact Tanach verses, prefer `otzaria_read_ref` by `heRef` over content search.

When using `otzaria_search`, prefer concise query terms. For example:

- Good: `שבת חולה`
- Good: `אמר רב`
- Good: `ואהבת`
- Good: `בראשית ברא`
- Less ideal: long modern Hebrew sentence

The tool itself tries multiple FTS variants and merges results.

## Source-answer format

When answering, use this pattern:

1. Short conclusion.
2. Sources section with each source as `ספר — מראה מקום`.
3. Explanation based on the sources.
4. If evidence is partial, say it is partial.

Never invent a `heRef`, book title, commentary, or connection type.

## UI workflow display

For substantial answers, render a workflow card using:

```scripting-file
{
  "path": "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-skills/otzaria-torah-assistant/scripts/otzaria-workflow-view.tsx",
  "props": {
    "workflow": {
      "question": "...",
      "status": "complete",
      "steps": [
        { "title": "חיפוש", "detail": "otzaria_search: שבת חולה", "state": "complete" },
        { "title": "מקורות", "detail": "נבחרו 3 מקורות", "state": "complete" }
      ],
      "searches": [
        { "query": "שבת חולה", "provider": "sqlite", "resultCount": 8 }
      ],
      "sources": [
        { "bookTitle": "...", "heRef": "...", "text": "..." }
      ],
      "links": [],
      "answerSummary": "..."
    }
  }
}
```

Keep UI data compact: source text snippets should usually be under 500 characters.

## Future Tantivy/MCP provider

The tools are designed so search can later be routed to a remote Tantivy/MCP HTTP endpoint while reading/context/links still use local SQLite. See `references/tantivy-provider-plan.md`.
