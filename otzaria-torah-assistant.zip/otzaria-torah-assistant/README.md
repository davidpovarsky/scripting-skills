# Otzaria Torah Assistant for Scripting

A Scripting skill + AssistantTools project for source-grounded Torah answers from a local Otzaria/Seforim SQLite database.

## What is included

- `SKILL.md` — assistant behavior and rendering instructions.
- `skill.json` — Scripting skill metadata.
- `tools/` — AssistantTools for search, reading references, context, books, links, and TOC.
- `scripts/` — UI renderers and helper scripts.
- `references/` — schema, workflow, Tantivy future plan, and UI format notes.

## Required database

Put one of these files in Scripting Documents:

- `seforim.db`
- `seforim.dp`

The tools search in this order:

1. explicit `dbPath`
2. iCloud Documents: `seforim.db`, `seforim.dp`
3. local Documents: `seforim.db`, `seforim.dp`
4. app group Documents: `seforim.db`, `seforim.dp`

Your current known path is:

`/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/seforim.db`

## First test

Run `scripts/test-local-search.tsx` inside Scripting. It should print sample results for:

- בראשית
- שבת חולה
- אמר רב
- ואהבת

## Assistant tool names

- `otzaria_search`
- `otzaria_read_ref`
- `otzaria_read_context`
- `otzaria_find_book`
- `otzaria_get_links`
- `otzaria_get_toc`

## UI

The skill can render a clean workflow view using:

`scripts/otzaria-workflow-view.tsx`

The UI intentionally uses native Scripting components (`List`, `Section`, `Text`) and avoids custom web UI.

## Note about Tantivy

This first version uses SQLite FTS5 for local search. It is designed so a later `tantivyEndpoint` can be added for higher-quality remote search while keeping local SQLite for reading context, links, and TOC.
