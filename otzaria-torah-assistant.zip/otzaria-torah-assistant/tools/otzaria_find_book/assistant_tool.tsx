import { openDatabase, closeDatabase, all, formatToolJson, clampInt, safe, truncate, report } from "../_shared/otzaria-db"

type Params = { query: string; limit?: number; dbPath?: string }
const AssistantToolAPI = (globalThis as any).AssistantTool

async function execute(params: Params) {
  let db: any = null
  try {
    if (!params.query || !String(params.query).trim()) return { success: false, message: "חסר query." }
    const limit = clampInt(params.limit, 20, 1, 80)
    const query = safe(params.query).trim()
    report(`מחפש ספר: ${query}`, "find-book")
    const opened = await openDatabase(params)
    db = opened.db

    const rows = await all(db, [
      "SELECT DISTINCT",
      "  book.id AS bookId,",
      "  book.title AS bookTitle,",
      "  book.heShortDesc,",
      "  book.totalLines,",
      "  book.isBaseBook,",
      "  book.hasTargumConnection,",
      "  book.hasReferenceConnection,",
      "  book.hasSourceConnection,",
      "  book.hasCommentaryConnection,",
      "  book.hasAltStructures,",
      "  book.filePath,",
      "  book.fileType,",
      "  book.volume,",
      "  category.title AS categoryTitle,",
      "  source.name AS sourceName,",
      "  book_acronym.term AS matchedAcronym",
      "FROM book",
      "JOIN category ON category.id = book.categoryId",
      "JOIN source ON source.id = book.sourceId",
      "LEFT JOIN book_acronym ON book_acronym.bookId = book.id",
      "WHERE book.title LIKE '%' || ? || '%'",
      "   OR book_acronym.term LIKE '%' || ? || '%'",
      "ORDER BY book.title",
      `LIMIT ${limit}`
    ].join("\n"), [query, query])

    return {
      success: true,
      message: formatToolJson("Otzaria book search results", {
        tool: "otzaria_find_book",
        query,
        dbPath: opened.dbPath,
        resultCount: rows.length,
        results: rows.map(r => ({
          bookId: Number(r.bookId),
          bookTitle: safe(r.bookTitle),
          categoryTitle: safe(r.categoryTitle),
          sourceName: safe(r.sourceName),
          totalLines: Number(r.totalLines || 0),
          matchedAcronym: safe(r.matchedAcronym),
          heShortDesc: truncate(r.heShortDesc, 250),
          flags: {
            isBaseBook: Boolean(r.isBaseBook),
            hasTargumConnection: Boolean(r.hasTargumConnection),
            hasReferenceConnection: Boolean(r.hasReferenceConnection),
            hasSourceConnection: Boolean(r.hasSourceConnection),
            hasCommentaryConnection: Boolean(r.hasCommentaryConnection),
            hasAltStructures: Boolean(r.hasAltStructures)
          },
          filePath: safe(r.filePath),
          fileType: safe(r.fileType),
          volume: safe(r.volume)
        }))
      })
    }
  } catch (error) {
    return { success: false, message: `otzaria_find_book failed: ${String(error)}` }
  } finally {
    if (db) await closeDatabase(db)
  }
}

AssistantToolAPI.registerExecuteTool(execute)
