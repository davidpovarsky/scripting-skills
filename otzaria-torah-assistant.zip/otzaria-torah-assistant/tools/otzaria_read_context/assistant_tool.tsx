import { openDatabase, closeDatabase, all, one, toLine, compactLines, formatToolJson, clampInt, report } from "../_shared/otzaria-db"

type Params = { lineId?: number; bookId?: number; lineIndex?: number; radius?: number; dbPath?: string }
const AssistantToolAPI = (globalThis as any).AssistantTool

async function execute(params: Params) {
  let db: any = null
  try {
    const radius = clampInt(params.radius, 3, 0, 20)
    const opened = await openDatabase(params)
    db = opened.db

    let bookId = Number(params.bookId || 0)
    let lineIndex = Number(params.lineIndex || 0)
    let anchor: any = null

    if (params.lineId) {
      report(`מאתר שורה לפי lineId ${params.lineId}`, "anchor")
      anchor = await one(db, [
        "SELECT line.id AS lineId, line.bookId, line.lineIndex, line.heRef, line.content, book.title AS bookTitle",
        "FROM line JOIN book ON book.id = line.bookId",
        "WHERE line.id = ?",
        "LIMIT 1"
      ].join("\n"), [Number(params.lineId)])
      if (!anchor) return { success: false, message: `לא נמצאה שורה lineId=${params.lineId}` }
      bookId = Number(anchor.bookId)
      lineIndex = Number(anchor.lineIndex)
    }

    if (!bookId || !Number.isFinite(lineIndex)) return { success: false, message: "צריך lineId או bookId + lineIndex." }

    const fromIndex = Math.max(0, lineIndex - radius)
    const toIndex = lineIndex + radius
    report(`קורא הקשר: bookId ${bookId}, שורות ${fromIndex}-${toIndex}`, "context")

    const rows = await all(db, [
      "SELECT",
      "  line.id AS lineId, line.heRef, line.content, line.lineIndex,",
      "  book.id AS bookId, book.title AS bookTitle",
      "FROM line",
      "JOIN book ON book.id = line.bookId",
      "WHERE line.bookId = ? AND line.lineIndex BETWEEN ? AND ?",
      "ORDER BY line.lineIndex"
    ].join("\n"), [bookId, fromIndex, toIndex])

    const lines = rows.map(toLine)
    return {
      success: true,
      message: formatToolJson("Otzaria context results", {
        tool: "otzaria_read_context",
        dbPath: opened.dbPath,
        anchor: anchor ? compactLines([toLine(anchor)], 1200)[0] : { bookId, lineIndex },
        radius,
        fromIndex,
        toIndex,
        resultCount: lines.length,
        results: compactLines(lines, 1200)
      })
    }
  } catch (error) {
    return { success: false, message: `otzaria_read_context failed: ${String(error)}` }
  } finally {
    if (db) await closeDatabase(db)
  }
}

AssistantToolAPI.registerExecuteTool(execute)
