import { openDatabase, closeDatabase, all, one, toLine, formatToolJson, clampInt, safe, truncate, report, LinkDirection, ConnectionType } from "../_shared/otzaria-db"

type Params = {
  lineId: number
  direction?: LinkDirection
  connectionType?: ConnectionType
  limit?: number
  dbPath?: string
}
const AssistantToolAPI = (globalThis as any).AssistantTool

function normalizeDirection(value: any): LinkDirection {
  return value === "incoming" || value === "outgoing" || value === "both" ? value : "both"
}

function normalizeConnectionType(value: any): string | null {
  const s = safe(value).toUpperCase().trim()
  return ["OTHER", "COMMENTARY", "SOURCE", "TARGUM", "REFERENCE"].includes(s) ? s : null
}

function mapLink(row: any, direction: "incoming" | "outgoing") {
  return {
    direction,
    linkId: Number(row.linkId),
    connectionType: safe(row.connectionType),
    source: {
      bookTitle: safe(row.sourceBookTitle),
      lineId: Number(row.sourceLineId),
      heRef: safe(row.sourceHeRef),
      text: truncate(row.sourceContent, 800)
    },
    target: {
      bookTitle: safe(row.targetBookTitle),
      lineId: Number(row.targetLineId),
      heRef: safe(row.targetHeRef),
      text: truncate(row.targetContent, 800)
    }
  }
}

async function fetchLinks(db: any, lineId: number, direction: "incoming" | "outgoing", connectionType: string | null, limit: number) {
  const whereLine = direction === "incoming" ? "link.targetLineId = ?" : "link.sourceLineId = ?"
  const args: any[] = [lineId]
  let typeClause = ""
  if (connectionType) {
    typeClause = " AND ct.name = ?"
    args.push(connectionType)
  }
  const sql = [
    "SELECT",
    "  link.id AS linkId,",
    "  ct.name AS connectionType,",
    "  sourceBook.title AS sourceBookTitle,",
    "  sourceLine.id AS sourceLineId,",
    "  sourceLine.heRef AS sourceHeRef,",
    "  sourceLine.content AS sourceContent,",
    "  targetBook.title AS targetBookTitle,",
    "  targetLine.id AS targetLineId,",
    "  targetLine.heRef AS targetHeRef,",
    "  targetLine.content AS targetContent",
    "FROM link",
    "JOIN connection_type ct ON ct.id = link.connectionTypeId",
    "JOIN book sourceBook ON sourceBook.id = link.sourceBookId",
    "JOIN book targetBook ON targetBook.id = link.targetBookId",
    "JOIN line sourceLine ON sourceLine.id = link.sourceLineId",
    "JOIN line targetLine ON targetLine.id = link.targetLineId",
    `WHERE ${whereLine}${typeClause}`,
    "ORDER BY ct.name, sourceBook.title, targetBook.title",
    `LIMIT ${limit}`
  ].join("\n")
  const rows = await all(db, sql, args)
  return rows.map(r => mapLink(r, direction))
}

async function execute(params: Params) {
  let db: any = null
  try {
    const lineId = Number(params.lineId)
    if (!lineId) return { success: false, message: "חסר lineId." }
    const direction = normalizeDirection(params.direction)
    const connectionType = normalizeConnectionType(params.connectionType)
    const limit = clampInt(params.limit, 20, 1, 80)
    report(`מביא קישורים סביב lineId ${lineId}`, "links")
    const opened = await openDatabase(params)
    db = opened.db

    const anchor = await one(db, [
      "SELECT line.id AS lineId, line.bookId, line.lineIndex, line.heRef, line.content, book.title AS bookTitle",
      "FROM line JOIN book ON book.id = line.bookId",
      "WHERE line.id = ? LIMIT 1"
    ].join("\n"), [lineId])

    const links: any[] = []
    if (direction === "incoming" || direction === "both") {
      links.push(...await fetchLinks(db, lineId, "incoming", connectionType, limit))
    }
    if (direction === "outgoing" || direction === "both") {
      links.push(...await fetchLinks(db, lineId, "outgoing", connectionType, limit))
    }

    return {
      success: true,
      message: formatToolJson("Otzaria link results", {
        tool: "otzaria_get_links",
        dbPath: opened.dbPath,
        lineId,
        direction,
        connectionType,
        anchor: anchor ? {
          lineId: Number(anchor.lineId),
          bookTitle: safe(anchor.bookTitle),
          heRef: safe(anchor.heRef),
          text: truncate(anchor.content, 800)
        } : null,
        resultCount: links.length,
        results: links
      })
    }
  } catch (error) {
    return { success: false, message: `otzaria_get_links failed: ${String(error)}` }
  } finally {
    if (db) await closeDatabase(db)
  }
}

AssistantToolAPI.registerExecuteTool(execute)
