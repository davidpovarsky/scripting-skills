import { openDatabase, closeDatabase, all, one, formatToolJson, clampInt, safe, report } from "../_shared/otzaria-db"

type Params = { bookId?: number; bookTitle?: string; limit?: number; dbPath?: string }
const AssistantToolAPI = (globalThis as any).AssistantTool

async function execute(params: Params) {
  let db: any = null
  try {
    const limit = clampInt(params.limit, 100, 1, 500)
    const opened = await openDatabase(params)
    db = opened.db
    let bookId = Number(params.bookId || 0)
    let book: any = null

    if (bookId) {
      book = await one(db, "SELECT id AS bookId, title AS bookTitle, totalLines FROM book WHERE id = ? LIMIT 1", [bookId])
    } else if (params.bookTitle && String(params.bookTitle).trim()) {
      const title = safe(params.bookTitle).trim()
      book = await one(db, [
        "SELECT id AS bookId, title AS bookTitle, totalLines",
        "FROM book",
        "WHERE title = ? OR title LIKE '%' || ? || '%'",
        "ORDER BY CASE WHEN title = ? THEN 0 ELSE 1 END, title",
        "LIMIT 1"
      ].join("\n"), [title, title, title])
      if (book) bookId = Number(book.bookId)
    }

    if (!bookId || !book) return { success: false, message: "צריך bookId או bookTitle שנמצא במסד." }
    report(`קורא תוכן עניינים: ${safe(book.bookTitle)}`, "toc")

    const rows = await all(db, [
      "SELECT",
      "  tocEntry.id,",
      "  tocEntry.parentId,",
      "  tocEntry.level,",
      "  tocEntry.lineId,",
      "  tocEntry.lineIndex,",
      "  tocEntry.hasChildren,",
      "  tocText.text",
      "FROM tocEntry",
      "JOIN tocText ON tocText.id = tocEntry.textId",
      "WHERE tocEntry.bookId = ?",
      "ORDER BY COALESCE(tocEntry.lineIndex, 999999999), tocEntry.level, tocEntry.id",
      `LIMIT ${limit}`
    ].join("\n"), [bookId])

    return {
      success: true,
      message: formatToolJson("Otzaria TOC results", {
        tool: "otzaria_get_toc",
        dbPath: opened.dbPath,
        book: {
          bookId: Number(book.bookId),
          bookTitle: safe(book.bookTitle),
          totalLines: Number(book.totalLines || 0)
        },
        resultCount: rows.length,
        results: rows.map(r => ({
          id: Number(r.id),
          parentId: r.parentId == null ? null : Number(r.parentId),
          level: Number(r.level),
          lineId: r.lineId == null ? null : Number(r.lineId),
          lineIndex: r.lineIndex == null ? null : Number(r.lineIndex),
          hasChildren: Boolean(r.hasChildren),
          text: safe(r.text)
        }))
      })
    }
  } catch (error) {
    return { success: false, message: `otzaria_get_toc failed: ${String(error)}` }
  } finally {
    if (db) await closeDatabase(db)
  }
}

AssistantToolAPI.registerExecuteTool(execute)
