import { openDatabase, closeDatabase, all, toLine, compactLines, formatToolJson, clampInt, safe, report } from "../_shared/otzaria-db"

type Params = { reference: string; limit?: number; dbPath?: string }
const AssistantToolAPI = (globalThis as any).AssistantTool

async function execute(params: Params) {
  let db: any = null
  try {
    if (!params.reference || !String(params.reference).trim()) return { success: false, message: "חסר reference." }
    const limit = clampInt(params.limit, 20, 1, 80)
    const reference = safe(params.reference).trim()
    report(`קורא מראה מקום: ${reference}`, "read-ref")
    const opened = await openDatabase(params)
    db = opened.db

    const rows = await all(db, [
      "SELECT",
      "  line.id AS lineId, line.heRef, line.content, line.lineIndex,",
      "  book.id AS bookId, book.title AS bookTitle",
      "FROM line",
      "JOIN book ON book.id = line.bookId",
      "WHERE line.heRef = ? OR line.heRef LIKE ?",
      "ORDER BY book.title, line.lineIndex",
      `LIMIT ${limit}`
    ].join("\n"), [reference, reference + "%"])

    const lines = rows.map(toLine)
    return {
      success: true,
      message: formatToolJson("Otzaria reference results", {
        tool: "otzaria_read_ref",
        reference,
        dbPath: opened.dbPath,
        resultCount: lines.length,
        results: compactLines(lines, 1200)
      })
    }
  } catch (error) {
    return { success: false, message: `otzaria_read_ref failed: ${String(error)}` }
  } finally {
    if (db) await closeDatabase(db)
  }
}

AssistantToolAPI.registerExecuteTool(execute)
