import { sqliteSearch, remoteTantivySearch, formatToolJson, compactLines, clampInt, report } from "../_shared/otzaria-db"

type Params = {
  query: string
  limit?: number
  heRefOnly?: boolean
  dbPath?: string
  searchProvider?: "sqlite" | "tantivy"
  tantivyEndpoint?: string
}

const AssistantToolAPI = (globalThis as any).AssistantTool

async function execute(params: Params) {
  try {
    if (!params.query || !String(params.query).trim()) {
      return { success: false, message: "חסר query לחיפוש." }
    }

    const provider = params.searchProvider || "sqlite"
    const limit = clampInt(params.limit, 10, 1, 40)
    report(`מתחיל חיפוש ${provider}: ${params.query}`, "start")

    if (provider === "tantivy") {
      const data = await remoteTantivySearch({ ...params, limit })
      return {
        success: true,
        message: formatToolJson("Otzaria Tantivy search results", {
          tool: "otzaria_search",
          provider: "tantivy",
          query: params.query,
          limit,
          result: data
        })
      }
    }

    const result = await sqliteSearch({ ...params, limit })
    return {
      success: true,
      message: formatToolJson("Otzaria SQLite search results", {
        tool: "otzaria_search",
        provider: result.provider,
        query: params.query,
        limit,
        dbPath: result.dbPath,
        attempts: result.attempts,
        resultCount: result.results.length,
        results: compactLines(result.results)
      })
    }
  } catch (error) {
    return { success: false, message: `otzaria_search failed: ${String(error)}` }
  }
}

AssistantToolAPI.registerExecuteTool(execute)
