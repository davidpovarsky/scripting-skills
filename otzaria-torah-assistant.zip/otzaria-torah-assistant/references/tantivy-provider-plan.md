# Future Tantivy / MCP provider plan

The first version uses local SQLite FTS5 because it works directly inside Scripting on iPad.

The MCP/Ituria project uses a different backend:

- Python MCP server
- Tantivy index folder named `index`
- One tool: `full_text_search`
- Result shape: Reference + Text

Otzaria app's own search engine is more advanced:

- Rust/Tantivy via `otzaria_search_engine`
- exact/fuzzy/advanced search modes
- Hebrew normalization
- regex phrase query
- slop
- facets
- highlighting
- future magic dictionary / morphology features

## Recommended migration path

Keep SQLite as the local source of truth for reading/context/links/TOC. Add a remote search provider only for search ranking/recall.

Expected remote HTTP shape:

```http
POST /search
Content-Type: application/json

{
  "query": "שבת חולה",
  "num_results": 10
}
```

Accepted response shapes:

1. JSON list of results
2. JSON object with `results`
3. Plain text in MCP style

The current `otzaria_search` tool already accepts:

```json
{
  "searchProvider": "tantivy",
  "tantivyEndpoint": "https://.../search"
}
```

Do not remove SQLite reading tools even after adding Tantivy. Tantivy search may identify sources, but local SQLite provides structured `lineId`, `bookId`, context, links, and TOC.
