# Otzaria `seforim.db` schema summary

This skill was built against the user's inspected SQLite database.

## Key counts from inspection

- `book`: 7,030 books
- `line`: 6,058,210 text lines
- `line_fts`: 6,058,210 FTS rows
- `link`: 7,752,211 links
- `tocEntry`: 1,291,514 TOC entries
- `tocText`: 110,200 TOC texts
- `connection_type`: 5 types

## Core tables

### `line`

```sql
CREATE TABLE line (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bookId INTEGER NOT NULL,
  lineIndex INTEGER NOT NULL,
  content TEXT NOT NULL,
  heRef TEXT,
  tocEntryId INTEGER
)
```

Use `line` to read actual text. Rows with `heRef IS NULL` are often headings (`<h1>`, `<h2>`) and should usually be filtered out for source results.

### `line_fts`

```sql
CREATE VIRTUAL TABLE line_fts USING fts5(
  content,
  content='line',
  content_rowid='id',
  tokenize='unicode61'
)
```

Use `line_fts.rowid = line.id`.

### `book`

Important columns: `id`, `title`, `categoryId`, `sourceId`, `heShortDesc`, `totalLines`, connection flags.

### `link`

```sql
CREATE TABLE link (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sourceBookId INTEGER NOT NULL,
  targetBookId INTEGER NOT NULL,
  sourceLineId INTEGER NOT NULL,
  targetLineId INTEGER NOT NULL,
  connectionTypeId INTEGER NOT NULL
)
```

`connection_type` values:

1. `OTHER`
2. `COMMENTARY`
3. `SOURCE`
4. `TARGUM`
5. `REFERENCE`

Observed direction conventions:

- For `COMMENTARY`, often `source` is the commentary and `target` is the base text. To get commentaries on a base line, use incoming links: `link.targetLineId = ? AND ct.name = 'COMMENTARY'`.
- For `TARGUM`, often `source` is the base verse and `target` is the targum. To get targum for a line, use outgoing links: `link.sourceLineId = ? AND ct.name = 'TARGUM'`.

### `tocEntry` + `tocText`

Use for table of contents:

```sql
SELECT tocEntry.id, tocEntry.parentId, tocEntry.level,
       tocEntry.lineId, tocEntry.lineIndex, tocEntry.hasChildren,
       tocText.text
FROM tocEntry
JOIN tocText ON tocText.id = tocEntry.textId
WHERE tocEntry.bookId = ?
ORDER BY COALESCE(tocEntry.lineIndex, 999999999), tocEntry.level, tocEntry.id;
```

## Golden SQL

### Search

```sql
SELECT line.id AS lineId, line.heRef, line.content, line.lineIndex,
       book.id AS bookId, book.title AS bookTitle, line_fts.rank AS rank
FROM line_fts
JOIN line ON line.id = line_fts.rowid
JOIN book ON book.id = line.bookId
WHERE line_fts MATCH ?
  AND line.heRef IS NOT NULL
ORDER BY line_fts.rank
LIMIT ?;
```

### Read reference

```sql
SELECT line.id AS lineId, line.heRef, line.content, line.lineIndex,
       book.id AS bookId, book.title AS bookTitle
FROM line
JOIN book ON book.id = line.bookId
WHERE line.heRef = ? OR line.heRef LIKE ?
ORDER BY book.title, line.lineIndex
LIMIT ?;
```

### Context

```sql
SELECT line.id AS lineId, line.heRef, line.content, line.lineIndex,
       book.id AS bookId, book.title AS bookTitle
FROM line
JOIN book ON book.id = line.bookId
WHERE line.bookId = ?
  AND line.lineIndex BETWEEN ? AND ?
ORDER BY line.lineIndex;
```
