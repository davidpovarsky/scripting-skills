# Agent workflow

This skill follows the useful behavior of Ituria without copying its Python/LangGraph runtime.

## Principles

1. Search before answering.
2. Prefer classical Hebrew/Aramaic terms over modern paraphrase.
3. If a direct reference is present, use `otzaria_read_ref` before full-text search.
4. If search results are ambiguous, read context.
5. If the user asks for commentary, targum, sources, or parallels, inspect `link` via `otzaria_get_links`.
6. Cite `bookTitle` and `heRef` for every source-based claim.
7. If the database does not contain a relevant result, say so clearly.

## Query refinement

Try in this order:

1. Direct query as asked.
2. Shorter classical terms.
3. Phrase query for exact language.
4. Aramaic or rabbinic alternatives.
5. Book-constrained approach: find book, then read TOC or ref.

## Good tool sequences

### General question

`otzaria_search` → `otzaria_read_context` → optional `otzaria_get_links` → answer.

### Exact verse/source

`otzaria_read_ref` → `otzaria_read_context` → optional `otzaria_get_links`.

### Commentary request

`otzaria_read_ref` or `otzaria_search` → choose base `lineId` → `otzaria_get_links` with `direction: incoming`, `connectionType: COMMENTARY`.

### Targum request

`otzaria_read_ref` → choose base `lineId` → `otzaria_get_links` with `direction: outgoing`, `connectionType: TARGUM`.
