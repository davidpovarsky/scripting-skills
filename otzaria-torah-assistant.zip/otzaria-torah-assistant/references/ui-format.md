# UI rendering format

For rich inline display in Scripting Assistant, output a `scripting-file` block pointing to:

`/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-skills/otzaria-torah-assistant/scripts/otzaria-workflow-view.tsx`

## Minimal workflow object

```json
{
  "question": "מה הדין בחולה בשבת?",
  "status": "complete",
  "steps": [
    { "title": "חיפוש", "detail": "otzaria_search: שבת חולה", "state": "complete" },
    { "title": "קריאת הקשר", "detail": "otzaria_read_context סביב lineId ...", "state": "complete" }
  ],
  "searches": [
    { "query": "שבת חולה", "provider": "sqlite", "resultCount": 8 }
  ],
  "sources": [
    { "bookTitle": "...", "heRef": "...", "lineId": 123, "text": "..." }
  ],
  "links": [
    { "connectionType": "COMMENTARY", "direction": "incoming", "sourceBookTitle": "...", "sourceHeRef": "...", "targetBookTitle": "...", "targetHeRef": "..." }
  ],
  "answerSummary": "..."
}
```

Keep snippets short. The user can ask for full context if needed.
