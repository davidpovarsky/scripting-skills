# OpenBus API endpoints used by this skill

Adapted from `openbus-mcp` in `skills-il/mcps`.

Base URL:

```text
https://open-bus-stride-api.hasadna.org.il
```

Endpoints:

| View | Endpoint | Main Parameters |
|---|---|---|
| stop-arrivals-by-search | `/gtfs_stops/list` then `/gtfs_ride_stops/list` | First searches candidate stops by `city`/`code` and client-side `query`; then calls planned upcoming stop times with selected stop `id` as `gtfs_stop_ids`. |
| stop-search | `/gtfs_stops/list` | API-side: `code`, `city`, `date_from`, `date_to`, `limit`, `offset`; client-side: `query`, `name`, `searchLimit`. |
| stop-arrivals | `/gtfs_ride_stops/list` | `gtfs_stop_ids`, `arrival_time_from`, `arrival_time_to`, `order_by`, `limit`, `offset` |
| route-search | `/gtfs_routes/list` | `route_short_name`, `route_long_name_contains`, `agency_name`, `line_refs`, `operator_refs`, `route_type`, `route_direction`, `date_from`, `date_to`, `limit`, `offset` |
| vehicle-locations | `/siri_vehicle_locations/list` | `lat_min`, `lat_max`, `lon_min`, `lon_max`, `recorded_at_time_from`, `recorded_at_time_to`, `siri_routes__line_ref`, `siri_routes__operator_ref`, `limit`, `offset` |
| route-timetable | `/route_timetable/list` | `planned_start_time_date_from`, `planned_start_time_date_to`, `line_refs`, `limit`, `offset` |
| ride-performance | `/rides_execution/list` | `date_from`, `date_to`, `operator_ref`, `line_ref`, `limit`, `offset` |
| agencies | `/gtfs_agencies/list` | `date_from`, `date_to`, `limit`, `offset` |

Notes:

- No authentication is required.
- The original MCP project applies client-side rate limiting of 1 request per second; this skill keeps a similar simple limiter in `scripts/openbus-api.ts`.
- The OpenBus stop endpoint does not provide official full-text stop-name search in the original MCP schema. This skill therefore performs client-side fuzzy filtering for stop `query`/`name` after fetching candidate rows, preferably constrained by `city`.
- API field names can vary by endpoint, so the renderer uses defensive extraction and fallback labels.
