---
name: openbus-israel
metadata:
  display_name: "OpenBus Israel"
  intent_patterns: "bus, buses, public transport, transit, israel, stop arrivals, bus stop, route, timetable, vehicle location, תחבורה ציבורית, אוטובוס, קו, תחנה, זמני הגעה, איפה האוטובוס"
description: Show Israeli public-transport data from the open Open Bus Stride API in rich inline Scripting UIs. Use proactively when the user asks about buses, stops, routes, planned arrival times, route schedules, live vehicle positions, transit agencies, or ride performance in Israel. Prefer rendering an interactive visual card/map via ```scripting-file``` instead of only plain text.
---

# Purpose

Use this skill when the user asks about Israeli public transportation: buses, stops, route numbers, planned arrivals, schedules, vehicle locations, transit agencies, or planned vs actual ride performance.

The skill renders compact native Scripting UI in chat using a `scripting-file` fenced block. The renderer fetches live/public data directly from the Open Bus Stride API:

`https://open-bus-stride-api.hasadna.org.il`

No API key is required.

# Critical Usage Rule

For normal user requests, **do not run this renderer with `scripting-ts run`, `scripting-ts preview_ui`, shell commands, curl, or `--props`**.

Instead, answer with a `scripting-file` block only. Scripting will pass the `props` from that block into the renderer.

`--props` is valid for some preview/debug flows only; it is **not** a valid `scripting-ts run` option. Avoid CLI execution unless the user explicitly asks you to debug the skill implementation.

# How to Render

Output a `scripting-file` block pointing to the renderer:

````markdown
```scripting-file
{
  "path": "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-skills/openbus-israel/scripts/openbus-renderer.tsx",
  "props": {
    "config": {
      "type": "stop-arrivals-by-search",
      "query": "צומת רמות גולדה",
      "city": "ירושלים",
      "limit": 8,
      "arrivalsLimit": 30
    }
  }
}
```
````

# Supported Views

| Type | Use Case |
|---|---|
| `stop-arrivals-by-search` | Best default for natural-language requests like “find this stop and show arrivals”. Searches candidate stops by name/city, shows them on a map, then loads upcoming planned GTFS stop times for the selected candidate. |
| `stop-search` | Find stops by stop code, city, or natural-language `query`; shows map markers + horizontal cards. |
| `stop-arrivals` | Show upcoming planned GTFS stop times for a known internal `gtfs_stop_id`. |
| `route-search` | Search planned GTFS routes by line number, agency, direction, or long-name text. |
| `vehicle-locations` | Show live vehicle positions on a map, optionally filtered by bounding box, line, or operator. |
| `route-timetable` | Show planned departures / timetables for route line refs and date filters. |
| `ride-performance` | Compare planned vs actual rides for operator + line over a date range. |
| `agencies` | List Israeli transit agencies/operators. |
| `dashboard` | A combined view with several sections in segmented tabs. |

# Decision Rules

- If the user gives a **station/place/street name and asks for arrivals**, use `stop-arrivals-by-search`. This shows planned upcoming stop times from `/gtfs_ride_stops/list`, not guaranteed live realtime predictions.
- If the user gives a **station/place/street name but only wants to find the stop**, use `stop-search` with `query` and preferably `city`.
- If the user gives a **public stop code** such as the number printed at the stop, use `stop-search` with `code` first; then use `stop-arrivals` with the returned internal `id` if you need arrivals.
- If the user gives a known **internal OpenBus/GTFS stop id**, use `stop-arrivals` with `gtfs_stop_id`.
- If the user asks “where are buses now?” or wants a visual map, render `vehicle-locations`.
- If the user gives a **line number** like 480, render `route-search` unless they specifically asked for a timetable.
- If the user asks about delays, reliability, or how a line performed, render `ride-performance`.
- Prefer Hebrew labels in user-facing titles when the conversation is Hebrew.
- Keep views compact for chat: default map height is 210–240pt.

# Important Arrival Data Limitation

Do **not** use `/stop_arrivals/list` for next-bus UI. In the current Stride API it returns historical/actual arrival rows and may return only `actual_arrival_time` such as old 2023 data when filtered by public stop `code`. For upcoming stop times, this skill uses `/gtfs_ride_stops/list` with:

- `gtfs_stop_ids` = the internal stop `id` from `/gtfs_stops/list`
- `arrival_time_from` = now
- `arrival_time_to` = now + `windowHours`
- `order_by` = `arrival_time asc`

These are planned GTFS times. Realtime vehicle locations are available separately through `vehicle-locations`, but the API does not provide a clean realtime prediction endpoint for “next buses at stop” in this skill.

# Important OpenBus Stop Search Limitation

The original `openbus-mcp` stop tool only supports `code`, `city`, dates, limit, and offset for `/gtfs_stops/list`; it does not provide official full-text stop-name search. This Scripting skill therefore implements client-side fuzzy filtering for `query`/`name` after fetching candidate stops, usually by city.

For best results, include `city` whenever the user supplies a stop name.

# Config Examples

## Find a Stop and Show Arrivals

Use this for questions like “תחפש תחנה בשם צומת רמות גולדה ותראה זמני הגעה”.

```json
{
  "type": "stop-arrivals-by-search",
  "title": "צומת רמות גולדה — זמני הגעה קרובים",
  "query": "צומת רמות גולדה",
  "city": "ירושלים",
  "limit": 8,
  "searchLimit": 1000,
  "arrivalsLimit": 30,
  "windowHours": 6,
  "height": 210
}
```

## Find Stops by Name and City

```json
{
  "type": "stop-search",
  "title": "חיפוש תחנה",
  "query": "רמות גולדה",
  "city": "ירושלים",
  "limit": 10,
  "searchLimit": 1000,
  "height": 220
}
```

## Find Stops by City Only

```json
{
  "type": "stop-search",
  "title": "תחנות בירושלים",
  "city": "ירושלים",
  "limit": 30,
  "height": 220
}
```

## Find a Stop by Public Code

```json
{
  "type": "stop-search",
  "title": "חיפוש תחנה",
  "code": 12345,
  "limit": 10
}
```

## Planned Stop Times by Internal GTFS/OpenBus Stop ID

```json
{
  "type": "stop-arrivals",
  "title": "זמני הגעה מתוכננים לתחנה",
  "gtfs_stop_id": 46429885,
  "limit": 30,
  "windowHours": 6
}
```

## Route Search

```json
{
  "type": "route-search",
  "title": "חיפוש קו 480",
  "route_short_name": "480",
  "limit": 30
}
```

## Vehicle Locations on a Map

```json
{
  "type": "vehicle-locations",
  "title": "אוטובוסים באזור ירושלים",
  "lat_min": 31.72,
  "lat_max": 31.84,
  "lon_min": 35.14,
  "lon_max": 35.26,
  "limit": 50,
  "height": 240
}
```

## Route Timetable

```json
{
  "type": "route-timetable",
  "title": "לו״ז מתוכנן",
  "line_refs": "480",
  "planned_start_time_date_from": "2026-07-08",
  "planned_start_time_date_to": "2026-07-08",
  "limit": 40
}
```

## Ride Performance

```json
{
  "type": "ride-performance",
  "title": "ביצועי קו",
  "date_from": "2026-07-01",
  "date_to": "2026-07-08",
  "operator_ref": 3,
  "line_ref": 480,
  "limit": 30
}
```

## Agencies

```json
{
  "type": "agencies",
  "title": "מפעילי תחבורה בישראל",
  "limit": 50
}
```

## Dashboard

```json
{
  "type": "dashboard",
  "title": "תחבורה ציבורית בישראל",
  "sections": [
    { "type": "stop-arrivals-by-search", "query": "צומת רמות גולדה", "city": "ירושלים", "limit": 8 },
    { "type": "route-search", "route_short_name": "480", "limit": 20 },
    { "type": "vehicle-locations", "lat_min": 31.72, "lat_max": 31.84, "lon_min": 35.14, "lon_max": 35.26, "limit": 30 }
  ]
}
```

# Data and API Notes

This skill is adapted from the `openbus-mcp` project, which wraps these Open Bus Stride API endpoints:

- `/gtfs_ride_stops/list` for upcoming planned stop times
- `/stop_arrivals/list` for historical/actual arrival samples only; avoid for next-bus UI
- `/rides_execution/list`
- `/gtfs_routes/list`
- `/gtfs_stops/list`
- `/route_timetable/list`
- `/siri_vehicle_locations/list`
- `/gtfs_agencies/list`

The API field names may vary by endpoint and date. The renderer uses defensive field extraction and shows raw fallback fields when a preferred label is missing.

# Output Notes

- Always include only one primary `scripting-file` block unless the user explicitly asks for multiple separate views.
- After the block, optionally add one short sentence.
- Do not dump large raw JSON in chat; let the UI display compact results.
- For questions requiring exact current data, let the renderer fetch live data at display time.
