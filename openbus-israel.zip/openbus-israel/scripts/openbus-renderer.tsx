import { ScrollView, VStack, HStack, Text, Picker, useEffect, useState } from "scripting"
import { RendererProps, OpenBusConfig, DashboardConfig, TransitItem, StopArrivalsBySearchConfig } from "./types"
import { fetchOpenBus, fetchRowsForConfig, mapItems, valueFrom } from "./openbus-api"
import { LoadingView, ErrorView, EmptyView, SectionHeader, ItemsMap, TransitCards, TransitCard, RawDetails } from "./openbus-components"

function useOpenBus(config: OpenBusConfig) {
  const [items, setItems] = useState<TransitItem[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    setItems(null)
    setError(null)

    const run = async () => {
      try {
        const rows = await fetchRowsForConfig(config)
        if (!cancelled) setItems(mapItems(rows, config.type))
      } catch (e) {
        if (!cancelled) setError(String(e))
      }
    }

    run()
    return () => { cancelled = true }
  }, [JSON.stringify(config)])

  return { items, error }
}


function StopArrivalsBySearchView({ config }: { config: StopArrivalsBySearchConfig }) {
  const [stops, setStops] = useState<TransitItem[] | null>(null)
  const [arrivals, setArrivals] = useState<TransitItem[] | null>(null)
  const [selectedIndex, setSelectedIndex] = useState(0)
  const [error, setError] = useState<string | null>(null)

  const queryKey = JSON.stringify({ query: config.query, city: config.city, code: config.code, searchLimit: config.searchLimit, limit: config.limit })

  useEffect(() => {
    let cancelled = false
    setStops(null)
    setArrivals(null)
    setError(null)
    setSelectedIndex(0)

    const run = async () => {
      try {
        const rows = await fetchRowsForConfig({
          type: "stop-search",
          query: config.query,
          city: config.city,
          code: config.code,
          limit: config.limit ?? 8,
          searchLimit: config.searchLimit ?? 1000,
        })
        if (!cancelled) setStops(mapItems(rows, "stop-search"))
      } catch (e) {
        if (!cancelled) setError(String(e))
      }
    }

    run()
    return () => { cancelled = true }
  }, [queryKey])

  const selectedStop = stops?.[Math.min(selectedIndex, Math.max((stops?.length ?? 1) - 1, 0))]
  const stopId = selectedStop ? valueFrom(selectedStop.raw || {}, ["id", "gtfs_stop_id"]) : null

  useEffect(() => {
    if (!stopId) return
    let cancelled = false
    setArrivals(null)

    const run = async () => {
      try {
        const range = upcomingRange(config.windowHours ?? 6)
        const rows = await fetchOpenBus("/gtfs_ride_stops/list", {
          gtfs_stop_ids: stopId,
          arrival_time_from: range.from,
          arrival_time_to: range.to,
          order_by: "arrival_time asc",
          limit: config.arrivalsLimit ?? 30,
          offset: 0,
        })
        if (!cancelled) setArrivals(mapItems(rows, "stop-arrivals"))
      } catch (e) {
        if (!cancelled) setError(String(e))
      }
    }

    run()
    return () => { cancelled = true }
  }, [String(stopId || ""), String(config.arrivalsLimit ?? 30), String(config.windowHours ?? 6)])

  if (error) return <ErrorView title={config.title || "חיפוש תחנה וזמני הגעה"} message={error} />
  if (stops === null) return <LoadingView title={config.title || "מחפש תחנה..."} />
  if (stops.length === 0) {
    return <EmptyView title="לא נמצאה תחנה מתאימה" message="נסה להוסיף עיר, להשתמש בשם רחוב רשמי, או להזין קוד תחנה." />
  }

  return (
    <VStack spacing={0} alignment="leading">
      <SectionHeader
        title={config.title || "תחנה וזמני הגעה"}
        subtitle={[config.city, config.query].filter(Boolean).join(" · ")}
        count={stops.length}
        systemImage="bus.fill"
      />
      <ItemsMap items={stops} height={config.height || 210} />
      <ScrollView axes="horizontal" padding={{ horizontal: 16, top: 2, bottom: 12 }}>
        <HStack spacing={8}>
          {stops.map((stop, index) => (
            <TransitCard
              key={stop.id || index}
              item={stop}
              selected={index === selectedIndex}
              width={165}
              onTap={() => setSelectedIndex(index)}
            />
          ))}
        </HStack>
      </ScrollView>
      {arrivals === null ? (
        <LoadingView title="טוען לו״ז מתוכנן לתחנה שנבחרה..." />
      ) : arrivals.length === 0 ? (
        <EmptyView title="אין זמני הגעה קרובים" message="OpenBus לא החזיר לו״ז מתוכנן לתחנה שנבחרה בטווח הזמן הקרוב." />
      ) : (
        <TransitCards
          items={arrivals}
          title="זמני הגעה קרובים"
          subtitle={selectedStop?.title}
          systemImage="clock.fill"
        />
      )}
    </VStack>
  )
}

function SingleOpenBusView({ config }: { config: OpenBusConfig }) {
  if (config.type === "stop-arrivals-by-search") {
    return <StopArrivalsBySearchView config={config as StopArrivalsBySearchConfig} />
  }

  const { items, error } = useOpenBus(config)

  if (error) return <ErrorView title={config.title} message={error} />
  if (items === null) return <LoadingView title={config.title} />
  if (items.length === 0) return <EmptyView title={config.title || "לא נמצאו תוצאות"} message="נסה לשנות פרמטרים או להרחיב את החיפוש." />

  const title = config.title || defaultTitle(config.type)
  const subtitle = config.subtitle || subtitleFor(config)

  switch (config.type) {
    case "stop-search":
      return (
        <VStack spacing={0} alignment="leading">
          <SectionHeader title={title} subtitle={subtitle} count={items.length} systemImage="mappin.and.ellipse" />
          <ItemsMap items={items} height={config.height || 220} />
        </VStack>
      )

    case "vehicle-locations":
      return (
        <VStack spacing={0} alignment="leading">
          <SectionHeader title={title} subtitle={subtitle} count={items.length} systemImage="bus.doubledecker.fill" />
          <ItemsMap items={items} height={config.height || 240} />
        </VStack>
      )

    case "stop-arrivals":
      return (
        <VStack spacing={0} alignment="leading">
          <TransitCards items={items} title={title} subtitle={subtitle} systemImage="clock.fill" />
          {items[0] ? <RawDetails item={items[0]} /> : null}
        </VStack>
      )

    case "route-search":
      return <TransitCards items={items} title={title} subtitle={subtitle} systemImage="arrow.triangle.branch" />

    case "route-timetable":
      return <TransitCards items={items} title={title} subtitle={subtitle} systemImage="calendar.badge.clock" />

    case "ride-performance":
      return <TransitCards items={items} title={title} subtitle={subtitle} systemImage="chart.line.uptrend.xyaxis" />

    case "agencies":
      return <TransitCards items={items} title={title} subtitle={subtitle} systemImage="building.2.fill" />

    default:
      return <TransitCards items={items} title={title} subtitle={subtitle} />
  }
}

function DashboardView({ config }: { config: DashboardConfig }) {
  const sections = config.sections || []
  const [active, setActive] = useState(0)

  if (sections.length === 0) {
    return <EmptyView title={config.title || "לוח תחבורה"} message="לא הוגדרו מקטעים להצגה." />
  }

  const activeSection = sections[Math.min(active, sections.length - 1)]

  return (
    <VStack spacing={0} alignment="leading">
      <SectionHeader
        title={config.title || "תחבורה ציבורית בישראל"}
        subtitle={config.subtitle || "OpenBus"}
        systemImage="bus.fill"
      />
      {sections.length > 1 ? (
        <VStack padding={{ horizontal: 16, bottom: 8 }}>
          <Picker
            title="סוג תצוגה"
            value={String(active)}
            onChanged={(value: string) => setActive(Number(value))}
            pickerStyle="segmented"
          >
            {sections.map((section, index) => (
              <Text key={index} tag={String(index)}>{shortTab(section.type)}</Text>
            ))}
          </Picker>
        </VStack>
      ) : null}
      <SingleOpenBusView config={activeSection} />
    </VStack>
  )
}

function OpenBusRendererInner({ config }: RendererProps) {
  if (!config || !config.type) {
    return <ErrorView title="OpenBus" message="Missing config.type" />
  }

  if (config.type === "dashboard") {
    return <DashboardView config={config as DashboardConfig} />
  }

  return <SingleOpenBusView config={config} />
}

export default function OpenBusRenderer({ config }: RendererProps) {
  return (
    <ScrollView>
      <OpenBusRendererInner config={config} />
    </ScrollView>
  )
}

export * from "./types"


function upcomingRange(hoursAhead: number): { from: string; to: string } {
  const now = new Date()
  const to = new Date(now.getTime() + Math.max(1, hoursAhead) * 60 * 60 * 1000)
  return {
    from: toIsoWithUtcOffset(now),
    to: toIsoWithUtcOffset(to),
  }
}

function toIsoWithUtcOffset(date: Date): string {
  return date.toISOString().replace(/\.\d{3}Z$/, "+00:00")
}


function defaultTitle(type: OpenBusConfig["type"]): string {
  switch (type) {
    case "stop-search": return "חיפוש תחנות"
    case "stop-arrivals": return "זמני הגעה מתוכננים"
    case "stop-arrivals-by-search": return "חיפוש תחנה וזמני הגעה"
    case "route-search": return "חיפוש קווים"
    case "vehicle-locations": return "מיקומי רכבים בזמן אמת"
    case "route-timetable": return "לו״ז מתוכנן"
    case "ride-performance": return "ביצועי נסיעות"
    case "agencies": return "מפעילי תחבורה"
    case "dashboard": return "תחבורה ציבורית בישראל"
    default: return "OpenBus"
  }
}

function shortTab(type: OpenBusConfig["type"]): string {
  switch (type) {
    case "stop-search": return "תחנות"
    case "stop-arrivals": return "הגעות"
    case "stop-arrivals-by-search": return "תחנה+הגעות"
    case "route-search": return "קווים"
    case "vehicle-locations": return "מפה"
    case "route-timetable": return "לו״ז"
    case "ride-performance": return "ביצוע"
    case "agencies": return "מפעילים"
    default: return "נתונים"
  }
}

function subtitleFor(config: OpenBusConfig): string {
  switch (config.type) {
    case "stop-search": return compact([config.city, (config as any).query || (config as any).name, config.code ? `קוד ${config.code}` : ""])
    case "stop-arrivals-by-search": return compact([config.city, config.query])
    case "stop-arrivals": return `תחנה ${config.gtfs_stop_id}`
    case "route-search": return compact([config.route_short_name ? `קו ${config.route_short_name}` : "", config.agency_name])
    case "vehicle-locations": return compact([config.siri_routes__line_ref ? `קו ${config.siri_routes__line_ref}` : "", config.siri_routes__operator_ref ? `מפעיל ${config.siri_routes__operator_ref}` : ""])
    case "route-timetable": return compact([config.line_refs ? `line_refs ${config.line_refs}` : "", config.planned_start_time_date_from])
    case "ride-performance": return compact([`operator ${config.operator_ref}`, `line ${config.line_ref}`])
    case "agencies": return compact([config.date_from, config.date_to])
    default: return ""
  }
}

function compact(parts: any[]): string {
  return parts.filter((part) => part !== undefined && part !== null && String(part).trim() !== "").join(" · ")
}
