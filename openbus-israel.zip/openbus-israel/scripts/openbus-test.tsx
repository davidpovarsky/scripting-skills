import OpenBusRenderer from "./openbus-renderer"

export default function TestOpenBus() {
  return (
    <OpenBusRenderer
      config={{
        type: "dashboard",
        title: "בדיקת OpenBus",
        sections: [
          { type: "stop-arrivals-by-search", query: "צומת רמות גולדה", city: "ירושלים", limit: 8, arrivalsLimit: 30 },
          { type: "route-search", route_short_name: "480", limit: 10 },
          {
            type: "vehicle-locations",
            lat_min: 31.72,
            lat_max: 31.84,
            lon_min: 35.14,
            lon_max: 35.26,
            limit: 20,
          },
        ],
      }}
    />
  )
}
