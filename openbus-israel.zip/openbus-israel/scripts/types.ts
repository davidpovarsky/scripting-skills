export interface Coordinate {
  latitude: number
  longitude: number
}

export interface Span {
  latitudeDelta: number
  longitudeDelta: number
}

export type OpenBusViewType =
  | "stop-search"
  | "stop-arrivals"
  | "stop-arrivals-by-search"
  | "route-search"
  | "vehicle-locations"
  | "route-timetable"
  | "ride-performance"
  | "agencies"
  | "dashboard"

export interface BaseConfig {
  type: OpenBusViewType
  title?: string
  subtitle?: string
  height?: number
  limit?: number
  offset?: number
  date_from?: string
  date_to?: string
}

export interface StopSearchConfig extends BaseConfig {
  type: "stop-search"
  /** Natural language station/street/place query. Filtered client-side because OpenBus find_stops supports city/code, not name search. */
  query?: string
  /** Alias for query, useful when the Agent writes name-style configs. */
  name?: string
  /** GTFS stop code, not the internal gtfs_stop_id. */
  code?: number | string
  city?: string
  /** How many raw stop rows to scan before client-side filtering. Default is 1000 when query/name is present. */
  searchLimit?: number
}

export interface StopArrivalsConfig extends BaseConfig {
  type: "stop-arrivals"
  /** Internal OpenBus/GTFS stop id returned as `id` from /gtfs_stops/list. */
  gtfs_stop_id: number | string
  /** Hours ahead to search in the planned GTFS timetable. Default 6. */
  windowHours?: number
}

export interface StopArrivalsBySearchConfig extends BaseConfig {
  type: "stop-arrivals-by-search"
  /** Station/street/place query, e.g. "צומת רמות גולדה". */
  query: string
  city?: string
  code?: number | string
  /** Candidate stops to scan before filtering. */
  searchLimit?: number
  /** Number of schedule rows to request for the selected stop. */
  arrivalsLimit?: number
  /** Hours ahead to search in the planned GTFS timetable. Default 6. */
  windowHours?: number
}

export interface RouteSearchConfig extends BaseConfig {
  type: "route-search"
  line_refs?: string
  operator_refs?: string
  route_short_name?: string
  route_long_name_contains?: string
  agency_name?: string
  route_type?: number
  route_direction?: number
  order_by?: string
}

export interface VehicleLocationsConfig extends BaseConfig {
  type: "vehicle-locations"
  lat_min?: number
  lat_max?: number
  lon_min?: number
  lon_max?: number
  recorded_at_time_from?: string
  recorded_at_time_to?: string
  siri_routes__line_ref?: number | string
  siri_routes__operator_ref?: number | string
}

export interface RouteTimetableConfig extends BaseConfig {
  type: "route-timetable"
  planned_start_time_date_from?: string
  planned_start_time_date_to?: string
  line_refs?: string
}

export interface RidePerformanceConfig extends BaseConfig {
  type: "ride-performance"
  operator_ref: number | string
  line_ref: number | string
}

export interface AgenciesConfig extends BaseConfig {
  type: "agencies"
}

export interface DashboardConfig extends BaseConfig {
  type: "dashboard"
  sections: OpenBusConfig[]
}

export type OpenBusConfig =
  | StopSearchConfig
  | StopArrivalsConfig
  | StopArrivalsBySearchConfig
  | RouteSearchConfig
  | VehicleLocationsConfig
  | RouteTimetableConfig
  | RidePerformanceConfig
  | AgenciesConfig
  | DashboardConfig

export interface RendererProps {
  config: OpenBusConfig
}

export interface TransitItem {
  id: string
  title: string
  subtitle?: string
  detail?: string
  meta?: string
  coordinate?: Coordinate
  systemImage?: string
  color?: string
  raw?: Record<string, any>
}
