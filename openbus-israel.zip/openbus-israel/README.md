# OpenBus Israel Scripting Skill

A Scripting skill for rendering Israeli public-transport data from OpenBus in rich inline chat UI.

Install by copying the `openbus-israel` folder into:

```text
Scripting Documents/scripting-skills/
```

The main renderer is:

```text
openbus-israel/scripts/openbus-renderer.tsx
```

Use it from the Assistant with a `scripting-file` block as described in `SKILL.md`.

## Important

Do not run this renderer with `scripting-ts run --props`. Normal use is via a `scripting-file` block. The `props` object belongs inside the block and is passed by Scripting to the renderer.

## Best default for natural-language stop questions

```json
{
  "type": "stop-arrivals-by-search",
  "query": "צומת רמות גולדה",
  "city": "ירושלים",
  "limit": 8,
  "arrivalsLimit": 30
}
```
